<?php
/**
* @version  1.0
* @package  digalu
*
* Websites: https://themeforest.net/user/validthemes/portfolio
*
*/

/**************************************
* Creating About Us Widget
***************************************/

class digalu_aboutus_widget extends WP_Widget {

        function __construct() {

            parent::__construct(
                // Base ID of your widget
                'digalu_aboutus_widget',

                // Widget name will appear in UI
                esc_html__( 'Digalu :: About Us Widget', 'digalu' ),

                // Widget description
                array(
                    'customize_selective_refresh'   => true,
                    'description'                   => esc_html__( 'Add About Us Widget', 'digalu' ),
                    'classname'		                => 'no-class',
                )
            );

        }

        // This is where the action happens
        public function widget( $args, $instance ) {

			$about_us 	= apply_filters( 'widget_about_us', $instance['about_us'] );
            if ( isset( $instance[ 'aboutus_img_url' ] ) ) {
                $aboutus_img_url = $instance[ 'aboutus_img_url' ];
            }else {
                $aboutus_img_url = '#';
            }
            $facebook         = apply_filters( 'widget_facebook', $instance['facebook'] );
            $twitter         = apply_filters( 'widget_twitter', $instance['twitter'] );
            $linkedin         = apply_filters( 'widget_linkedin', $instance['linkedin'] );
            $youtube         = apply_filters( 'widget_youtube', $instance['youtube'] );
            

            //before and after widget arguments are defined by themes
            echo $args['before_widget'];

            echo '<div class="f-item about">';
                if ( isset( $instance[ 'aboutus_img_url' ] ) ) {
                    $aboutus_img_url = $instance[ 'aboutus_img_url' ];
                    echo digalu_img_tag( array(
                        'url'   => esc_url( $aboutus_img_url ),
                        'class' => 'logo'
                    ) );
                }
                if( !empty( $about_us ) ){
                    echo '<p>'.wp_kses_post( $about_us ).'</p>';
                }
                echo '<ul class="footer-social">';
                    if( !empty( $facebook ) ){
                        echo '<li><a href="'.esc_url($facebook).'"><i class="fab fa-facebook-f"></i></a></li>';
                    }
                    if( !empty( $twitter ) ){
                        echo '<li><a href="'.esc_url($twitter).'"><i class="fab fa-twitter"></i></a></li>';
                    }
                    if( !empty( $linkedin ) ){
                        echo '<li><a href="'.esc_url($linkedin).'"><i class="fab fa-linkedin-in"></i></a></li>';
                    }
                    if( !empty( $youtube ) ){
                        echo '<li><a href="'.esc_url($youtube).'"><i class="fab fa-youtube"></i></a></li>';
                    }
                echo '</ul>';
            echo '</div>';
            echo $args['after_widget'];
        }

        // Widget Backend
        public function form( $instance ) {

            //Image Url
            if ( isset( $instance[ 'aboutus_img_url' ] ) ) {
                $aboutus_img_url = $instance[ 'aboutus_img_url' ];
            }else {
                $aboutus_img_url = '';
            }
			
			if ( isset( $instance[ 'about_us' ] ) ) {
				$about_us = $instance[ 'about_us' ];
			}else {
				$about_us = '';
			}

            
            if ( isset( $instance[ 'facebook' ] ) ) {
                $facebook = $instance[ 'facebook' ];
            }else {
                $facebook = '';
            }
            

            if ( isset( $instance[ 'twitter' ] ) ) {
                $twitter = $instance[ 'twitter' ];
            }else {
                $twitter = '';
            }

            if ( isset( $instance[ 'linkedin' ] ) ) {
                $linkedin = $instance[ 'linkedin' ];
            }else {
                $linkedin = '';
            }


            if ( isset( $instance[ 'youtube' ] ) ) {
                $youtube = $instance[ 'youtube' ];
            }else {
                $youtube = '';
            }
            
			
            // Widget admin form
            ?>
            <p>
                <label for="<?php echo $this->get_field_id( 'aboutus_img_url' ); ?>"><?php _e( 'Image URL:' ,'digalu'); ?></label>
                <input class="widefat" id="<?php echo $this->get_field_id( 'aboutus_img_url' ); ?>" name="<?php echo $this->get_field_name( 'aboutus_img_url' ); ?>" type="text" value="<?php echo esc_attr( $aboutus_img_url ); ?>" />
            </p>
			<p>
				<label for="<?php echo $this->get_field_id( 'about_us' ); ?>">
					<?php
						_e( 'About Us:' ,'dvpn');
					?>
				</label>
		        <textarea class="widefat" id="<?php echo $this->get_field_id( 'about_us' ); ?>" name="<?php echo $this->get_field_name( 'about_us' ); ?>" rows="8" cols="80"><?php echo esc_html( $about_us ); ?></textarea>
			</p>

            <p>
                <label for="<?php echo $this->get_field_id( 'facebook' ); ?>">
                    <?php
                        _e( 'Facebook Url :' ,'digalu');
                    ?>
                </label>
                <input class="widefat" id="<?php echo $this->get_field_id( 'facebook' ); ?>" name="<?php echo $this->get_field_name( 'facebook' ); ?>" type="text" value="<?php echo esc_attr( $facebook ); ?>" />
            </p>



            <p>
                <label for="<?php echo $this->get_field_id( 'twitter' ); ?>">
                    <?php
                        _e( 'Twitter Url :' ,'digalu');
                    ?>
                </label>
                <input class="widefat" id="<?php echo $this->get_field_id( 'twitter' ); ?>" name="<?php echo $this->get_field_name( 'twitter' ); ?>" type="text" value="<?php echo esc_attr( $twitter ); ?>" />
            </p>

            <p>
                <label for="<?php echo $this->get_field_id( 'linkedin' ); ?>">
                    <?php
                        _e( 'Linkedin Url :' ,'digalu');
                    ?>
                </label>
                <input class="widefat" id="<?php echo $this->get_field_id( 'linkedin' ); ?>" name="<?php echo $this->get_field_name( 'linkedin' ); ?>" type="text" value="<?php echo esc_attr( $linkedin ); ?>" />
            </p>


            <p>
                <label for="<?php echo $this->get_field_id( 'youtube' ); ?>">
                    <?php
                        _e( 'Youtube Url :' ,'digalu');
                    ?>
                </label>
                <input class="widefat" id="<?php echo $this->get_field_id( 'youtube' ); ?>" name="<?php echo $this->get_field_name( 'youtube' ); ?>" type="text" value="<?php echo esc_attr( $youtube ); ?>" />
            </p>
            
            <?php
        }


         // Updating widget replacing old instances with new
         public function update( $new_instance, $old_instance ) {

            $instance = array();
            $instance['aboutus_img_url'] 	= ( ! empty( $new_instance['aboutus_img_url'] ) ) ? strip_tags( $new_instance['aboutus_img_url'] ) : '';
            $instance['about_us'] 			= ( ! empty( $new_instance['about_us'] ) ) ? strip_tags( $new_instance['about_us'] ) : '';
            $instance['facebook']      = ( ! empty( $new_instance['facebook'] ) ) ? strip_tags( $new_instance['facebook'] ) : '';
            $instance['twitter']      = ( ! empty( $new_instance['twitter'] ) ) ? strip_tags( $new_instance['twitter'] ) : '';
            $instance['linkedin']      = ( ! empty( $new_instance['linkedin'] ) ) ? strip_tags( $new_instance['linkedin'] ) : '';
            $instance['youtube']      = ( ! empty( $new_instance['youtube'] ) ) ? strip_tags( $new_instance['youtube'] ) : '';

			return $instance;
        }
    } // Class digalu_aboutus_widget ends here


    // Register and load the widget
    function digalu_aboutus_load_widget() {
        register_widget( 'digalu_aboutus_widget' );
    }
    add_action( 'widgets_init', 'digalu_aboutus_load_widget' );