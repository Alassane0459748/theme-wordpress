<?php
    /**
     * Class For Builder
     */
    class DigaluBuilder{

        function __construct(){
            // register admin menus
        	add_action( 'admin_menu', [$this, 'register_settings_menus'] );

            // Custom Footer Builder With Post Type
			add_action( 'init',[ $this,'post_type' ],0 );

 		    add_action( 'elementor/frontend/after_enqueue_scripts', [ $this,'widget_scripts'] );

			add_filter( 'single_template', [ $this, 'load_canvas_template' ] );

            add_action( 'elementor/element/wp-page/document_settings/after_section_end', [ $this,'digalu_add_elementor_page_settings_controls' ],10,2 );

		}

		public function widget_scripts( ) {
			wp_enqueue_script( 'digalu-core',DIGALU_PLUGDIRURI.'assets/js/digalu-core.js',array( 'jquery' ),'1.0',true );
		}


        public function digalu_add_elementor_page_settings_controls( \Elementor\Core\DocumentTypes\Page $page ){

			$page->start_controls_section(
                'digalu_header_option',
                [
                    'label'     => __( 'Header Option', 'digalu' ),
                    'tab'       => \Elementor\Controls_Manager::TAB_SETTINGS,
                ]
            );


            $page->add_control(
                'digalu_header_style',
                [
                    'label'     => __( 'Header Option', 'digalu' ),
                    'type'      => \Elementor\Controls_Manager::SELECT,
                    'options'   => [
    					'prebuilt'             => __( 'Pre Built', 'digalu' ),
    					'header_builder'       => __( 'Header Builder', 'digalu' ),
    				],
                    'default'   => 'prebuilt',
                ]
			);

            $page->add_control(
                'digalu_header_builder_option',
                [
                    'label'     => __( 'Header Name', 'digalu' ),
                    'type'      => \Elementor\Controls_Manager::SELECT,
                    'options'   => $this->digalu_header_choose_option(),
                    'condition' => [ 'digalu_header_style' => 'header_builder'],
                    'default'	=> ''
                ]
            );

            $page->end_controls_section();

            $page->start_controls_section(
                'digalu_footer_option',
                [
                    'label'     => __( 'Footer Option', 'digalu' ),
                    'tab'       => \Elementor\Controls_Manager::TAB_SETTINGS,
                ]
            );
            $page->add_control(
    			'digalu_footer_choice',
    			[
    				'label'         => __( 'Enable Footer?', 'digalu' ),
    				'type'          => \Elementor\Controls_Manager::SWITCHER,
    				'label_on'      => __( 'Yes', 'digalu' ),
    				'label_off'     => __( 'No', 'digalu' ),
    				'return_value'  => 'yes',
    				'default'       => 'yes',
    			]
    		);
            $page->add_control(
                'digalu_footer_style',
                [
                    'label'     => __( 'Footer Style', 'digalu' ),
                    'type'      => \Elementor\Controls_Manager::SELECT,
                    'options'   => [
    					'prebuilt'             => __( 'Pre Built', 'digalu' ),
    					'footer_builder'       => __( 'Footer Builder', 'digalu' ),
    				],
                    'default'   => 'prebuilt',
                    'condition' => [ 'digalu_footer_choice' => 'yes' ],
                ]
            );
            $page->add_control(
                'digalu_footer_builder_option',
                [
                    'label'     => __( 'Footer Name', 'digalu' ),
                    'type'      => \Elementor\Controls_Manager::SELECT,
                    'options'   => $this->digalu_footer_choose_option(),
                    'condition' => [ 'digalu_footer_style' => 'footer_builder','digalu_footer_choice' => 'yes' ],
                    'default'	=> ''
                ]
            );

			$page->end_controls_section();

        }

		public function register_settings_menus(){
			add_menu_page(
				esc_html__( 'Digalu Builder', 'digalu' ),
            	esc_html__( 'Digalu Builder', 'digalu' ),
				'manage_options',
				'digalu',
				[$this,'register_settings_contents__settings'],
				'dashicons-admin-site',
				2
			);

			add_submenu_page('digalu', esc_html__('Footer Builder', 'digalu'), esc_html__('Footer Builder', 'digalu'), 'manage_options', 'edit.php?post_type=digalu_footer');
			add_submenu_page('digalu', esc_html__('Header Builder', 'digalu'), esc_html__('Header Builder', 'digalu'), 'manage_options', 'edit.php?post_type=digalu_header');
            add_submenu_page('digalu', esc_html__('Tab Builder', 'digalu'), esc_html__('Tab Builder', 'digalu'), 'manage_options', 'edit.php?post_type=digalu_tab_builder');
		}

		// Callback Function
		public function register_settings_contents__settings(){
            echo '<h2>';
			    echo esc_html__( 'Welcome To Header And Footer Builder Of This Theme','digalu' );
            echo '</h2>';
		}

		public function post_type() {

			$labels = array(
				'name'               => __( 'Footer', 'digalu' ),
				'singular_name'      => __( 'Footer', 'digalu' ),
				'menu_name'          => __( 'Digalu Footer Builder', 'digalu' ),
				'name_admin_bar'     => __( 'Footer', 'digalu' ),
				'add_new'            => __( 'Add New', 'digalu' ),
				'add_new_item'       => __( 'Add New Footer', 'digalu' ),
				'new_item'           => __( 'New Footer', 'digalu' ),
				'edit_item'          => __( 'Edit Footer', 'digalu' ),
				'view_item'          => __( 'View Footer', 'digalu' ),
				'all_items'          => __( 'All Footer', 'digalu' ),
				'search_items'       => __( 'Search Footer', 'digalu' ),
				'parent_item_colon'  => __( 'Parent Footer:', 'digalu' ),
				'not_found'          => __( 'No Footer found.', 'digalu' ),
				'not_found_in_trash' => __( 'No Footer found in Trash.', 'digalu' ),
			);

			$args = array(
				'labels'              => $labels,
				'public'              => true,
				'rewrite'             => false,
				'show_ui'             => true,
				'show_in_menu'        => false,
				'show_in_nav_menus'   => false,
				'exclude_from_search' => true,
				'capability_type'     => 'post',
				'hierarchical'        => false,
				'supports'            => array( 'title', 'elementor' ),
			);

			register_post_type( 'digalu_footer', $args );

			$labels = array(
				'name'               => __( 'Header', 'digalu' ),
				'singular_name'      => __( 'Header', 'digalu' ),
				'menu_name'          => __( 'Digalu Header Builder', 'digalu' ),
				'name_admin_bar'     => __( 'Header', 'digalu' ),
				'add_new'            => __( 'Add New', 'digalu' ),
				'add_new_item'       => __( 'Add New Header', 'digalu' ),
				'new_item'           => __( 'New Header', 'digalu' ),
				'edit_item'          => __( 'Edit Header', 'digalu' ),
				'view_item'          => __( 'View Header', 'digalu' ),
				'all_items'          => __( 'All Header', 'digalu' ),
				'search_items'       => __( 'Search Header', 'digalu' ),
				'parent_item_colon'  => __( 'Parent Header:', 'digalu' ),
				'not_found'          => __( 'No Header found.', 'digalu' ),
				'not_found_in_trash' => __( 'No Header found in Trash.', 'digalu' ),
			);

			$args = array(
				'labels'              => $labels,
				'public'              => true,
				'rewrite'             => false,
				'show_ui'             => true,
				'show_in_menu'        => false,
				'show_in_nav_menus'   => false,
				'exclude_from_search' => true,
				'capability_type'     => 'post',
				'hierarchical'        => false,
				'supports'            => array( 'title', 'elementor' ),
			);

			register_post_type( 'digalu_header', $args );

            $labels = array(
				'name'               => __( 'Tab Builder', 'digalu' ),
				'singular_name'      => __( 'Tab Builder', 'digalu' ),
				'menu_name'          => __( 'Digalu Tab Builder', 'digalu' ),
				'name_admin_bar'     => __( 'Tab Builder', 'digalu' ),
				'add_new'            => __( 'Add New', 'digalu' ),
				'add_new_item'       => __( 'Add New Tab Builder', 'digalu' ),
				'new_item'           => __( 'New Tab Builder', 'digalu' ),
				'edit_item'          => __( 'Edit Tab Builder', 'digalu' ),
				'view_item'          => __( 'View Tab Builder', 'digalu' ),
				'all_items'          => __( 'All Tab Builder', 'digalu' ),
				'search_items'       => __( 'Search Tab Builder', 'digalu' ),
				'parent_item_colon'  => __( 'Parent Tab Builder:', 'digalu' ),
				'not_found'          => __( 'No Tab Builder found.', 'digalu' ),
				'not_found_in_trash' => __( 'No Tab Builder found in Trash.', 'digalu' ),
			);

			$args = array(
				'labels'              => $labels,
				'public'              => true,
				'rewrite'             => false,
				'show_ui'             => true,
				'show_in_menu'        => false,
				'show_in_nav_menus'   => false,
				'exclude_from_search' => true,
				'capability_type'     => 'post',
				'hierarchical'        => false,
				'supports'            => array( 'title', 'elementor' ),
			);

			register_post_type( 'digalu_tab_builder', $args );

		}

		function load_canvas_template( $single_template ) {

			global $post;

			if ( 'digalu_footer' == $post->post_type || 'digalu_header' == $post->post_type || 'digalu_tab_builder' == $post->post_type ) {

				$elementor_2_0_canvas = ELEMENTOR_PATH . '/modules/page-templates/templates/canvas.php';

				if ( file_exists( $elementor_2_0_canvas ) ) {
					return $elementor_2_0_canvas;
				} else {
					return ELEMENTOR_PATH . '/includes/page-templates/canvas.php';
				}
			}

			return $single_template;
		}

        public function digalu_footer_choose_option(){

			$digalu_post_query = new WP_Query( array(
				'post_type'			=> 'digalu_footer',
				'posts_per_page'	    => -1,
			) );

			$digalu_builder_post_title = array();
			$digalu_builder_post_title[''] = __('Select a Footer','Digalu');

			while( $digalu_post_query->have_posts() ) {
				$digalu_post_query->the_post();
				$digalu_builder_post_title[ get_the_ID() ] =  get_the_title();
			}
			wp_reset_postdata();

			return $digalu_builder_post_title;

		}

		public function digalu_header_choose_option(){

			$digalu_post_query = new WP_Query( array(
				'post_type'			=> 'digalu_header',
				'posts_per_page'	    => -1,
			) );

			$digalu_builder_post_title = array();
			$digalu_builder_post_title[''] = __('Select a Header','Digalu');

			while( $digalu_post_query->have_posts() ) {
				$digalu_post_query->the_post();
				$digalu_builder_post_title[ get_the_ID() ] =  get_the_title();
			}
			wp_reset_postdata();

			return $digalu_builder_post_title;

        }

    }

    $builder_execute = new DigaluBuilder();