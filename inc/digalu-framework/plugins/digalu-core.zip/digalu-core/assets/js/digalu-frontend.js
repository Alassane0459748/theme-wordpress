;(function($) {

    'use strict';

    $(window).on( 'elementor/frontend/init', function() {

        // Features

        elementorFrontend.hooks.addAction('frontend/element_ready/digalufeaturebox.default',function($scope) {

            let featureSlider   = $scope.find('.features-carousel');
            let desktopData     = featureSlider.data('slide-show');
            let laptopData      = featureSlider.data('lg-slide-show');
            let tabletData      = featureSlider.data('md-slide-show');
            let mobiletData     = featureSlider.data('sm-slide-show');

            const featureCarousel = new Swiper(".features-carousel", {
                // Optional parameters
                loop: true,
                slidesPerView: mobiletData ? mobiletData : 1,
                spaceBetween: 24,
                autoplay: true,
                pagination: {
                    el: ".swiper-pagination",
                    clickable: true,
                },
                // Navigation arrows
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev"
                },
                breakpoints: {
                    768: {
                        slidesPerView: tabletData ? tabletData : 2,
                    },
                    1024: {
                        slidesPerView: laptopData ? laptopData : 3,
                        spaceBetween: 30,
                    },
                    1400: {
                        slidesPerView: desktopData ? desktopData : 4,
                        spaceBetween: 30,
                    }
                },
            });
        });

        // Service

        elementorFrontend.hooks.addAction('frontend/element_ready/digaluservices.default',function($scope) {

            let serviceeSlider   = $scope.find('.service-carousel');
            let desktopData     = serviceeSlider.data('slide-show');
            let laptopData      = serviceeSlider.data('lg-slide-show');
            let tabletData      = serviceeSlider.data('md-slide-show');
            let mobiletData     = serviceeSlider.data('sm-slide-show');

            const serviceCarousel = new Swiper(".service-carousel", {
                // Optional parameters
                loop: true,
                slidesPerView: mobiletData ? mobiletData : 2,
                spaceBetween: 24,
                autoplay: true,
                pagination: {
                    el: ".swiper-pagination",
                    clickable: true,
                },
                // Navigation arrows
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev"
                },
                breakpoints: {
                    768: {
                        slidesPerView: tabletData ? tabletData : 2,
                    },
                    1024: {
                        slidesPerView: laptopData ? laptopData : 3,
                        spaceBetween: 30,
                    },
                    1400: {
                        slidesPerView: desktopData ? desktopData : 4,
                        spaceBetween: 30,
                    }
                },
            });
        });

        // Progressbar

        elementorFrontend.hooks.addAction('frontend/element_ready/digalupcircleprogressbar.default',function($scope) {

            function animateElements() {
                $('.progressbar').each(function() {
                    var elementPos = $(this).offset().top;
                    var topOfWindow = $(window).scrollTop();
                    var percent = $(this).find('.circle').attr('data-percent');
                    var animate = $(this).data('animate');
                    if (elementPos < topOfWindow + $(window).height() - 30 && !animate) {
                        $(this).data('animate', true);
                        $(this).find('.circle').circleProgress({
                            // startAngle: -Math.PI / 2,
                            value: percent / 100,
                            size: 90,
                            thickness: 3,
                            lineCap: 'round',
                            emptyFill: '#f1f1f1',
                            fill: {
                                gradient: ['#6222cc', '#a200be ']
                            }
                        }).on('circle-animation-progress', function(event, progress, stepValue) {
                            $(this).find('strong').text((stepValue * 100).toFixed(0) + "%");
                        }).stop();
                    }
                });

                $('.progressbar-hard').each(function() {
                    var elementPos = $(this).offset().top;
                    var topOfWindow = $(window).scrollTop();
                    var percent = $(this).find('.circle').attr('data-percent');
                    var animate = $(this).data('animate');
                    if (elementPos < topOfWindow + $(window).height() - 30 && !animate) {
                        $(this).data('animate', true);
                        $(this).find('.circle').circleProgress({
                            // startAngle: -Math.PI / 2,
                            value: percent / 100,
                            size: 110,
                            thickness: 10,
                            lineCap: 'round',
                            emptyFill: '#f1f1f1',
                            fill: {
                                gradient: ['#6222cc', '#a200be ']
                            }
                        }).on('circle-animation-progress', function(event, progress, stepValue) {
                            $(this).find('strong').text((stepValue * 100).toFixed(0) + "%");
                        }).stop();
                    }
                });
            }
            
            animateElements();
            $(window).scroll(animateElements);
            
            });


        // client

        elementorFrontend.hooks.addAction('frontend/element_ready/digaluclientlogo.default',function($scope) {

            let brandSlider   = $scope.find('.brand3col');
            let desktopData     = brandSlider.data('slide-show');
            let laptopData      = brandSlider.data('lg-slide-show');
            let tabletData      = brandSlider.data('md-slide-show');
            let mobiletData     = brandSlider.data('sm-slide-show');

            const brandCarousel = new Swiper(".brand3col", {
                // Optional parameters
                loop: true,
                slidesPerView: mobiletData ? mobiletData : 2,
                spaceBetween: 24,
                autoplay: true,
                pagination: {
                    el: ".swiper-pagination",
                    clickable: true,
                },
                // Navigation arrows
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev"
                },
                breakpoints: {
                    768: {
                        slidesPerView: tabletData ? tabletData : 3,
                    },
                    1024: {
                        slidesPerView: laptopData ? laptopData : 3,
                        spaceBetween: 30,
                    },
                    1400: {
                        slidesPerView: desktopData ? desktopData : 3,
                        spaceBetween: 30,
                    }
                },
            });
        });

        // fun fact

        elementorFrontend.hooks.addAction('frontend/element_ready/digalucounterup.default',function($scope) {

            $('.timer').countTo();
            $('.fun-fact').appear(function() {
                $('.timer').countTo();
            }, {
                accY: -100
            });
        });

        // fun fact

        elementorFrontend.hooks.addAction('frontend/element_ready/digalubannerv2.default',function($scope) {

             const bannerFade = new Swiper(".banner-fade", {
                // Optional parameters
                direction: "horizontal",
                loop: true,
                autoplay: true,
                effect: "fade",
                fadeEffect: {
                    crossFade: true
                },
                speed: 3000,
                autoplay: {
                    delay: 5000,
                    disableOnInteraction: false,
                },
                // If we need pagination
                // pagination: {
                //     el: '.swiper-pagination',
                //     type: 'bullets',
                //     clickable: true,
                // },

                // Navigation arrows
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev"
                }

                // And if we need scrollbar
                /*scrollbar: {
                el: '.swiper-scrollbar',
              },*/
            });
        });


        // Project

        elementorFrontend.hooks.addAction('frontend/element_ready/digaluprojects.default',function($scope) {

            let projectSlider   = $scope.find('.project-carousel');
            let desktopData     = projectSlider.data('slide-show');
            let laptopData      = projectSlider.data('lg-slide-show');
            let tabletData      = projectSlider.data('md-slide-show');
            let mobiletData     = projectSlider.data('sm-slide-show');

            const projectCarousel = new Swiper(".project-carousel", {
                // Optional parameters
                loop: true,
                slidesPerView: mobiletData ? mobiletData : 1,
                spaceBetween: 24,
                autoplay: true,
                pagination: {
                    el: ".swiper-pagination",
                    clickable: true,
                },
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                    type: 'fraction'
                },
                // Navigation arrows
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev"
                },
                breakpoints: {
                    768: {
                        slidesPerView: tabletData ? tabletData : 2,
                    },
                    1024: {
                        slidesPerView: laptopData ? laptopData : 3,
                        spaceBetween: 30,
                    },
                    1400: {
                        slidesPerView: desktopData ? desktopData : 3,
                        spaceBetween: 30,
                    }
                },
            });
        });

        // Testimonials

        elementorFrontend.hooks.addAction('frontend/element_ready/digalutestimonials.default',function($scope) {

            let testimonialsSlider   = $scope.find('.testimonial-style-one-carousel');
            const testimonialsCarousel = new Swiper(".testimonial-style-one-carousel", {
                // Optional parameters
                loop: true,
                slidesPerView: 1,
                spaceBetween: 30,
                autoplay: true,
                pagination: {
                    el: ".swiper-pagination",
                    clickable: true,
                },
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                    type: 'fraction'
                },
                // Navigation arrows
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev"
                },
                breakpoints: {
                    768: {
                        slidesPerView: 1,
                    },
                    1200: {
                        slidesPerView: 2,
                    }
                },
            });
        });

        // Blog

        elementorFrontend.hooks.addAction('frontend/element_ready/digalublogpost.default',function($scope) {

            let blogSlider      = $scope.find('.blog-carousel');
            let desktopData     = blogSlider.data('slide-show');
            let laptopData      = blogSlider.data('lg-slide-show');
            let tabletData      = blogSlider.data('md-slide-show');
            let mobiletData     = blogSlider.data('sm-slide-show');

            const blogCarousel = new Swiper(".blog-carousel", {
                // Optional parameters
                loop: true,
                slidesPerView: mobiletData ? mobiletData : 1,
                spaceBetween: 24,
                autoplay: true,
                pagination: {
                    el: ".swiper-pagination",
                    clickable: true,
                },
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                    type: 'fraction'
                },
                // Navigation arrows
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev"
                },
                breakpoints: {
                    768: {
                        slidesPerView: tabletData ? tabletData : 2,
                    },
                    1024: {
                        slidesPerView: laptopData ? laptopData : 3,
                        spaceBetween: 30,
                    },
                    1400: {
                        slidesPerView: desktopData ? desktopData : 3,
                        spaceBetween: 30,
                    }
                },
            });
        });

        // seo

        elementorFrontend.hooks.addAction('frontend/element_ready/digaluseolist.default',function($scope) {

            const seoCarousel = new Swiper(".seo-carousel", {
                // Optional parameters
                loop: true,
                slidesPerView: 1,
                spaceBetween: 30,
                autoplay: true,
                pagination: {
                    el: ".swiper-pagination",
                    clickable: true,
                },
                // Navigation arrows
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev"
                },
                breakpoints: {
                    768: {
                        slidesPerView: 2,
                    },
                    992: {
                        slidesPerView: 3,
                        spaceBetween: 40,
                    }
                },
            });
        });

        elementorFrontend.hooks.addAction('frontend/element_ready/digaluproject2.default',function($scope) {

            const stageCarousel = new Swiper(".stage-carousel", {
                // Optional parameters
                loop: true,
                freeMode: true,
                grabCursor: true,
                slidesPerView: 1,
                spaceBetween: 30,
                autoplay: true,
                // If we need pagination
                pagination: {
                    el: '.stage-pagination',
                    type: 'bullets',
                    clickable: true,
                },
                // Navigation arrows
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev"
                },
                breakpoints: {
                    768: {
                        slidesPerView: 2,
                        spaceBetween: 50,
                    },
                    1400: {
                        slidesPerView: 2.5,
                        spaceBetween: 60,
                    },

                    1800: {
                        spaceBetween: 60,
                        slidesPerView: 2.8,
                    },
                },
            });
        });


        // location
        elementorFrontend.hooks.addAction('frontend/element_ready/digaluclientlocation.default',function($scope) {

            if ($(".clients-map")) {    
                $(".clients-map").closest('.elementor-widget').css('position', 'absolute');      
            }
        });

    });

}(jQuery));