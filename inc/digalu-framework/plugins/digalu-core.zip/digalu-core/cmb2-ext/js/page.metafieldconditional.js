(function($){
    "use strict";
    
    let $digalu_page_breadcrumb_area      = $("#_digalu_page_breadcrumb_area");
    let $digalu_page_settings             = $("#_digalu_page_breadcrumb_settings");
    let $digalu_page_breadcrumb_image     = $("#_digalu_breadcumb_image");
    let $digalu_page_title                = $("#_digalu_page_title");
    let $digalu_page_title_settings       = $("#_digalu_page_title_settings");

    if( $digalu_page_breadcrumb_area.val() == '1' ) {
        $(".cmb2-id--digalu-page-breadcrumb-settings").show();
        if( $digalu_page_settings.val() == 'global' ) {
            $(".cmb2-id--digalu-breadcumb-image").hide();
            $(".cmb2-id--digalu-page-title").hide();
            $(".cmb2-id--digalu-page-title-settings").hide();
            $(".cmb2-id--digalu-custom-page-title").hide();
            $(".cmb2-id--digalu-page-breadcrumb-trigger").hide();
        } else {
            $(".cmb2-id--digalu-breadcumb-image").show();
            $(".cmb2-id--digalu-page-title").show();
            $(".cmb2-id--digalu-page-breadcrumb-trigger").show();
    
            if( $digalu_page_title.val() == '1' ) {
                $(".cmb2-id--digalu-page-title-settings").show();
                if( $digalu_page_title_settings.val() == 'default' ) {
                    $(".cmb2-id--digalu-custom-page-title").hide();
                } else {
                    $(".cmb2-id--digalu-custom-page-title").show();
                }
            } else {
                $(".cmb2-id--digalu-page-title-settings").hide();
                $(".cmb2-id--digalu-custom-page-title").hide();
    
            }
        }
    } else {
        $digalu_page_breadcrumb_area.parents('.cmb2-id--digalu-page-breadcrumb-area').siblings().hide();
    }


    // breadcrumb area
    $digalu_page_breadcrumb_area.on("change",function(){
        if( $(this).val() == '1' ) {
            $(".cmb2-id--digalu-page-breadcrumb-settings").show();
            if( $digalu_page_settings.val() == 'global' ) {
                $(".cmb2-id--digalu-breadcumb-image").hide();
                $(".cmb2-id--digalu-page-title").hide();
                $(".cmb2-id--digalu-page-title-settings").hide();
                $(".cmb2-id--digalu-custom-page-title").hide();
                $(".cmb2-id--digalu-page-breadcrumb-trigger").hide();
            } else {
                $(".cmb2-id--digalu-breadcumb-image").show();
                $(".cmb2-id--digalu-page-title").show();
                $(".cmb2-id--digalu-page-breadcrumb-trigger").show();
        
                if( $digalu_page_title.val() == '1' ) {
                    $(".cmb2-id--digalu-page-title-settings").show();
                    if( $digalu_page_title_settings.val() == 'default' ) {
                        $(".cmb2-id--digalu-custom-page-title").hide();
                    } else {
                        $(".cmb2-id--digalu-custom-page-title").show();
                    }
                } else {
                    $(".cmb2-id--digalu-page-title-settings").hide();
                    $(".cmb2-id--digalu-custom-page-title").hide();
        
                }
            }
        } else {
            $(this).parents('.cmb2-id--digalu-page-breadcrumb-area').siblings().hide();
        }
    });

    // page title
    $digalu_page_title.on("change",function(){
        if( $(this).val() == '1' ) {
            $(".cmb2-id--digalu-page-title-settings").show();
            if( $digalu_page_title_settings.val() == 'default' ) {
                $(".cmb2-id--digalu-custom-page-title").hide();
            } else {
                $(".cmb2-id--digalu-custom-page-title").show();
            }
        } else {
            $(".cmb2-id--digalu-page-title-settings").hide();
            $(".cmb2-id--digalu-custom-page-title").hide();

        }
    });

    //page settings
    $digalu_page_settings.on("change",function(){
        if( $(this).val() == 'global' ) {
            $(".cmb2-id--digalu-breadcumb-image").hide();
            $(".cmb2-id--digalu-page-title").hide();
            $(".cmb2-id--digalu-page-title-settings").hide();
            $(".cmb2-id--digalu-custom-page-title").hide();
            $(".cmb2-id--digalu-page-breadcrumb-trigger").hide();
        } else {
            $(".cmb2-id--digalu-breadcumb-image").show();
            $(".cmb2-id--digalu-page-title").show();
            $(".cmb2-id--digalu-page-breadcrumb-trigger").show();
    
            if( $digalu_page_title.val() == '1' ) {
                $(".cmb2-id--digalu-page-title-settings").show();
                if( $digalu_page_title_settings.val() == 'default' ) {
                    $(".cmb2-id--digalu-custom-page-title").hide();
                } else {
                    $(".cmb2-id--digalu-custom-page-title").show();
                }
            } else {
                $(".cmb2-id--digalu-page-title-settings").hide();
                $(".cmb2-id--digalu-custom-page-title").hide();
    
            }
        }
    });

    // page title settings
    $digalu_page_title_settings.on("change",function(){
        if( $(this).val() == 'default' ) {
            $(".cmb2-id--digalu-custom-page-title").hide();
        } else {
            $(".cmb2-id--digalu-custom-page-title").show();
        }
    });
    
})(jQuery);