<?php

// Blocking direct access
if( ! defined( 'ABSPATH' ) ) {
   exit();
}

/**
 * Plugin Name: Digalu Core
 * Description: This is a helper plugin of digalu theme
 * Version:     1.0
 * Author:      Validthemes
 * Author URI:  https://themeforest.net/user/validthemes/portfolio
 * License:     GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Domain Path: /languages
 * Text Domain: digalu
 */

// Define Constant
define( 'DIGALU_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'DIGALU_PLUGIN_INC_PATH', plugin_dir_path( __FILE__ ) . 'inc/' );
define( 'DIGALU_PLUGIN_CMB2EXT_PATH', plugin_dir_path( __FILE__ ) . 'cmb2-ext/' );
define( 'DIGALU_PLUGIN_WIDGET_PATH', plugin_dir_path( __FILE__ ) . 'inc/widgets/' );
define( 'DIGALU_PLUGDIRURI', plugin_dir_url( __FILE__ ) );
define( 'DIGALU_ADDONS', plugin_dir_path( __FILE__ ) .'addons/' );
define( 'DIGALU_CORE_PLUGIN_TEMP', plugin_dir_path( __FILE__ ) .'digalu-template/' );

// load textdomain
load_plugin_textdomain( 'digalu', false, basename( dirname( __FILE__ ) ) . '/languages' );

//include file.
require_once DIGALU_PLUGIN_INC_PATH .'digalucore-functions.php';
require_once DIGALU_PLUGIN_INC_PATH . 'MCAPI.class.php';
require_once DIGALU_PLUGIN_INC_PATH .'digaluajax.php';
require_once DIGALU_PLUGIN_INC_PATH .'builder/builder.php';

require_once DIGALU_PLUGIN_CMB2EXT_PATH . 'cmb2ext-init.php';

//Widget
require_once DIGALU_PLUGIN_WIDGET_PATH . 'recent-post-widget.php';
require_once DIGALU_PLUGIN_WIDGET_PATH . 'gallery-widget.php';
require_once DIGALU_PLUGIN_WIDGET_PATH . 'digalu-about-widget.php';
require_once DIGALU_PLUGIN_WIDGET_PATH . 'digalu-cta-widget.php';
require_once DIGALU_PLUGIN_WIDGET_PATH . 'digalu-contact-widget.php';
require_once DIGALU_PLUGIN_WIDGET_PATH . 'social-media-widgets.php';
require_once DIGALU_PLUGIN_WIDGET_PATH . 'digalu-service-cta.php';
require_once DIGALU_PLUGIN_WIDGET_PATH . 'digalu-download-button-widget.php';
require_once DIGALU_PLUGIN_WIDGET_PATH . 'digalu-contact-info-footer.php';

//addons
require_once DIGALU_ADDONS . 'addons.php';

// Register widget styles
add_action( 'elementor/editor/before_enqueue_styles', 'widget_styles' );


function widget_styles() {

    wp_register_style( 'editor-style-1', plugins_url( 'assets/css/editor.css', __FILE__ ) );
    wp_enqueue_style( 'editor-style-1' );

}