<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Group_Control_Border;
/**
 *
 * Tab Builder Widget .
 *
 */
class Digalu_Tab_Builder extends Widget_Base {

	public function get_name() {
		return 'digalutabbuilder';
	}

	public function get_title() {
		return __( 'Tab Builder', 'digalu' );
	}

	public function get_icon() {
		return 'vt-icon';
    }

	protected function register_controls() {

		$this->start_controls_section(
			'tab_builder_section',
			[
				'label' 	=> __( 'Tab Builder', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );
		$repeater = new Repeater();

        $repeater->add_control(
			'tab_builder_heading',
			[
				'label' 	=> __( 'Tab Heading', 'digalu' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'default'  	=> __( 'Ut fermentum massa justo', 'digalu' )
			]
        );
        $repeater->add_control(
			'tab_builder_text',
			[
				'label' 	=> __( 'Tab Builder Title', 'digalu' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'default'  	=> __( 'Ut fermentum massa justo', 'digalu' )
			]
        );

		$repeater->add_control(
			'digalu_tab_builder_option',
			[
				'label'     => __( 'Tab Name', 'digalu' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => $this->digalu_tab_builder_choose_option(),
				'default'	=> ''
			]
		);

        $repeater->add_control(
			'make_it_active',
			[
				'label' 		=> __( 'Make It Active?', 'digalu' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Yes', 'digalu' ),
				'label_off' 	=> __( 'No', 'digalu' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);
		$repeater->add_control(
			'chose_icon_style',
			[
				'label' 		=> __( 'Icon Type', 'digalu' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'class',
				'options' 		=> [
					'class'  	=> __( 'Class', 'digalu' ),
					'img' 		=> __( 'Image', 'digalu' ),
				],
			]
		);
        $repeater->add_control(
			'icon_class', [
				'label' 		=> __( 'Icon Class', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( '<i class="flaticon-bullhorn"></i>' , 'digalu' ),
				'label_block' 	=> true,
				'condition'		=> [ 'chose_icon_style' => [ 'class' ] ],
			]
        );
        $repeater->add_control(
			'icon_image',
			[
				'label' 		=> __( 'Image', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
				'condition'		=> [ 'chose_icon_style' => [ 'img' ] ],
			]
		);

		$this->add_control(
			'tab_builder_repeater',
			[
				'label' 		=> __( 'Tab', 'digalu' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'tab_builder_text'    => __( 'Analytics', 'digalu' ),
					],
					[
						'tab_builder_text'    => __( 'Marketing', 'digalu' ),
					],
					[
						'tab_builder_text'    => __( 'Ppc', 'digalu' ),
					],
				],
				'title_field' 	=> '{{{ tab_builder_text }}}',
			]
		);

        $this->end_controls_section();

        /*-----------------------------------------features styling------------------------------------*/

		$this->start_controls_section(
			'tab_section',
			[
				'label' 	=> __( 'General', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
        );
        $this->add_control(
			'box_color',
			[
				'label' 		=> __( 'Box Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .services-tab-navs .nav-tabs'	=> '--white: {{VALUE}}!important;',
				],
			]
        );
        $this->end_controls_section();

        /*-----------------------------------------section Content styling------------------------------------*/

		$this->start_controls_section(
			'section_con_styling',
			[
				'label' 	=> __( 'Tab Control', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
        );
        $this->start_controls_tabs(
			'style_tabs1'
		);


		$this->start_controls_tab(
			'style_normal_tab1',
			[
				'label' => esc_html__( 'heading', 'digalu' ),
			]
		);
        $this->add_control(
			's_title_color',
			[
				'label' 		=> __( 'Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} span'	=> 'color: {{VALUE}}!important;',
				],
			]
        );
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 's_title_typography',
		 		'label' 		=> __( 'Typography', 'digalu' ),
		 		'selector' 	=> '{{WRAPPER}} span',
			]
		);

        $this->add_responsive_control(
			's_title_margin',
			[
				'label' 		=> __( 'Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
        );

        $this->add_responsive_control(
			's_title_padding',
			[
				'label' 		=> __( 'Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'

				],
			]
        );
		$this->end_controls_tab();

		//--------------------secound--------------------//

		$this->start_controls_tab(
			'style_hover_tab2',
			[
				'label' => esc_html__( 'Title', 'digalu' ),
			]
		);
		$this->add_control(
			's_content_color',
			[
				'label' 		=> __( 'Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .services-tab-navs .nav-tabs .nav-link'	=> 'color: {{VALUE}}!important;',
				]
			]
        );
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 's_content_typography',
		 		'label' 		=> __( 'Typography', 'digalu' ),
		 		'selector' 	=> '{{WRAPPER}} .services-tab-navs .nav-tabs .nav-link',
			]
		);

        $this->add_responsive_control(
			's_content_margin',
			[
				'label' 		=> __( 'Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .services-tab-navs .nav-tabs .nav-link' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ],
			]
        );

        $this->add_responsive_control(
			's_content_padding',
			[
				'label' 		=> __( 'Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .services-tab-navs .nav-tabs .nav-link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ],
			]
        );

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();


    }

	public function digalu_tab_builder_choose_option(){

		$digalu_post_query = new WP_Query( array(
			'post_type'				=> 'digalu_tab_builder',
			'posts_per_page'	    => -1,
		) );

		$digalu_tab_builder_title = array();
		$digalu_tab_builder_title[''] = __( 'Select a Tab','digalu');

		while( $digalu_post_query->have_posts() ) {
			$digalu_post_query->the_post();
			$digalu_tab_builder_title[ get_the_ID() ] =  get_the_title();
		}
		wp_reset_postdata();

		return $digalu_tab_builder_title;

	}

	protected function render() {

        $settings = $this->get_settings_for_display();


        echo '<div class="services-style-one-area">';
	        echo '<div class="container">';
	            echo '<div class="services-style-one-box">';
	                echo '<div class="row">';
	                    echo '<div class="col-xl-4 col-lg-5">';
	                        echo '<div class="services-tab-navs">';
	                            echo '<div class="nav nav-tabs" id="nav-tab" role="tablist">';

	                            	foreach( $settings['tab_builder_repeater'] as $single_menu ){
					            		$title			= $single_menu['tab_builder_text'];
										$replace 		= array(' ',' - ');
										$with 			= array('-','-');
										$tabid 			= strtolower( str_replace( $replace, $with, $title ) );
										$active = $single_menu['make_it_active'] == 'yes' ? 'active':'';
										$area = $single_menu['make_it_active'] == 'yes' ? 'true':'false';

		                                echo '<button class="nav-link '.esc_attr($active).'" id="nav-id-'.$tabid.'" data-bs-toggle="tab" data-bs-target="#tab'.$tabid.'" type="button" role="tab" aria-controls="tab'.$tabid.'" aria-selected="'.esc_attr($area).'">';
		                                    if($single_menu['chose_icon_style'] == 'class' ){
		                                    	echo '<div class="icon">';
		                                    		echo wp_kses_post($single_menu['icon_class']);
		                                    	echo '</div>';
		                                    }else{
		                                    	echo '<div class="icon">';
			                                    	echo digalu_img_tag( array(
														'url'	=> esc_url( $single_menu['icon_image']['url'] ),
													) );
												echo '</div>';
		                                    }
		                                    echo '<div class="info">';
		                                        echo '<b>'.esc_html($single_menu['tab_builder_heading']).'</b>';
		                                        echo esc_html($title);
		                                    echo '</div>';
		                                echo '</button>';
		                            }
	                                
	                              echo '</div>';
	                        echo '</div>';
	                    echo '</div>';
	                    echo '<div class="col-xl-8 col-lg-7 pl-60 pl-md-15 pl-xs-15 default-padding-top">';
	                        echo '<div class="services-style-one">';
	                            echo '<div class="tab-content" id="nav-tabContent">';
	                                
	                                foreach( $settings['tab_builder_repeater'] as $single_menu ){
					            		$title			= $single_menu['tab_builder_text'];
										$replace 		= array(' ',' - ');
										$with 			= array('-','-');
										$tabid 			= strtolower( str_replace( $replace, $with, $title ) );
										$active = $single_menu['make_it_active'] == 'yes' ? 'show active':'';
										
		                                echo '<div class="tab-pane fade '.esc_attr($active).'" id="tab'.$tabid.'" role="tabpanel" aria-labelledby="nav-id-'.$tabid.'">';
		                                    echo '<div class="row align-center">';
		                                        $elementor = \Elementor\Plugin::instance();
						                        if( ! empty( $single_menu['digalu_tab_builder_option'] ) ){
						                            echo $elementor->frontend->get_builder_content_for_display( $single_menu['digalu_tab_builder_option'] );
						                        }
		                                    echo '</div>';
		                                echo '</div>';
		                                echo '<!-- End Single Item -->';
		                            }
	                            echo '</div>';
	                        echo '</div>';
	                    echo '</div>';
	                echo '</div>';
	            echo '</div>';
	        echo '</div>';
	    echo '</div>';
	}
}