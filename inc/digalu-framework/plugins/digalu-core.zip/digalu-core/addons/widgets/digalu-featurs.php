<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Feature Box Widget .
 *
 */
class Digalu_Feature_Box extends Widget_Base {

	public function get_name() {
		return 'digalufeaturebox';
	}

	public function get_title() {
		return __( 'Digalu Feature', 'digalu' );
	}


	public function get_icon() {
		return 'vt-icon';
    }


	public function get_categories() {
		return [ 'digalu' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'feature_section',
			[
				'label' 	=> __( 'Feature', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'feature_style',
			[
				'label' 	=> __( 'Feature Style', 'digalu' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '1',
				'options' 	=> [
					'1'  		=> __( 'Style One', 'digalu' ),
					'2' 		=> __( 'Style Two', 'digalu' ),
					'3' 		=> __( 'Style Three', 'digalu' ),
				],
			]
		);
		$this->add_control(
			'show_heading',
			[
				'label' 		=> __( 'Show Section Heading?', 'digalu' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Show', 'digalu' ),
				'label_off' 	=> __( 'Hide', 'digalu' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
				'condition'		=> [ 'feature_style' => ['1','2' ] ],
			]
		);
		$this->add_control(
			'subtitle',
			[
				'label'     => __( 'Subtitle', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'condition'		=> [ 'show_heading' => ['yes' ] ],
			]
        );
        $this->add_control(
			'title',
			[
				'label'     => __( 'Title', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'condition'		=> [ 'show_heading' => ['yes' ] ],
			]
        );

        $repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'     => __( 'Title', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
			]
        );
        $repeater->add_control(
			'desc',
			[
				'label'     => __( 'Content', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
			]
        );
        $repeater->add_control(
			'chose_icon_style',
			[
				'label' 		=> __( 'Icon Type', 'digalu' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'class',
				'options' 		=> [
					'class'  	=> __( 'Class', 'digalu' ),
					'img' 		=> __( 'Image', 'digalu' ),
				],
			]
		);
        $repeater->add_control(
			'icon_class', [
				'label' 		=> __( 'Icon Class', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( '<i class="flaticon-bullhorn"></i>' , 'digalu' ),
				'label_block' 	=> true,
				'condition'		=> [ 'chose_icon_style' => [ 'class' ] ],
			]
        );
        $repeater->add_control(
			'icon_image',
			[
				'label' 		=> __( 'Image', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
				'condition'		=> [ 'chose_icon_style' => [ 'img' ] ],
			]
		);
        $repeater->add_control(
			'details_page', [
				'label' 		=> __( 'Details Page URL', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( '#' , 'digalu' ),
				'label_block' 	=> true,
			]
        );
        $repeater->add_control(
			'read_more_text', [
				'label' 		=> __( 'Button Text', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Read More' , 'digalu' ),
				'label_block' 	=> true,
			]
        );
        $this->add_control(
			'features_one',
			[
				'label' 		=> __( 'Steps', 'digalu' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 		=> __( 'title', 'digalu' ),
					],
				],
				'title_field' 	=> '{{{ title }}}',
			]
		);
        $this->end_controls_section();

        //------------------------------------feature Control------------------------------------//

		$this->start_controls_section(
			'features_control',
			[
				'label'     => __( 'Features Control', 'digalu' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'make_slider',
			[
				'label' 		=> __( 'Use it as slider ?', 'digalu' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Show', 'digalu' ),
				'label_off' 	=> __( 'Hide', 'digalu' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);
		$this->add_control(
			'desktop_items',
			[
				'label' 		=> __( 'Items To Show', 'digalu' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ '%' ],
				'range' 		=> [
					'%' 	=> [
						'min' 		=> 0,
						'step' 		=> 1,
						'max' 		=> 10,
					],
				],
				'default' 		=> [
					'unit' 			=> '%',
					'size' 			=> 5,
				],
				'condition'		=> [ 'make_slider' => [ 'yes' ] ],
			]
		);
		$this->add_control(
			'laptop_items',
			[
				'label' 		=> __( 'Laptop Items', 'digalu' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ '%' ],
				'range' 		=> [
					'%' 	=> [
						'min' 	=> 0,
						'step' 	=> 1,
						'max' 	=> 10,
					],
				],
				'default' 	=> [
					'unit' 		=> '%',
					'size' 		=> 2,
				],
				'condition'		=> [ 'make_slider' => [ 'yes' ] ],
			]
		);

        $this->add_control(
			'tablet_items',
			[
				'label' 		=> __( 'Tablet Items', 'digalu' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ '%' ],
				'range' 		=> [
					'%' 	=> [
						'min' 	=> 0,
						'step' 	=> 1,
						'max' 	=> 10,
					],
				],
				'default' 	=> [
					'unit' 		=> '%',
					'size' 		=> 2,
				],
				'condition'		=> [ 'make_slider' => [ 'yes' ] ],
			]
		);

        $this->add_control(
			'mobile_items',
			[
				'label' 		=> __( 'Mobile Items', 'digalu' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ '%' ],
				'range' 		=> [
					'%' 	=> [
						'min' 	=> 0,
						'step' 	=> 1,
						'max' 	=> 10,
					],
				],
				'default' 	=> [
					'unit' 		=> '%',
					'size' 		=> 1,
				],
				'condition'		=> [ 'make_slider' => [ 'yes' ] ],
			]
		);
		$this->add_control(
			'colmn_items',
			[
				'label' 		=> __( 'Column View', 'digalu' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ '%' ],
				'range' 		=> [
					'%' 	=> [
						'min' 		=> 0,
						'step' 		=> 1,
						'max' 		=> 4,
					],
				],
				'default' 		=> [
					'unit' 			=> '%',
					'size' 			=> 4,
				],
				'condition'		=> [ 'make_slider!' =>  'yes' ],
			]
		);


        $this->end_controls_section();

        //-------------------------shape area ------------------------//

        $this->start_controls_section(
			'shape_section',
			[
				'label' 	=> __( 'Shape Area', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'shape',
			[
				'label' 		=> __( 'Shape Image For Item', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'shape_1',
			[
				'label' 		=> __( 'Shape Image', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
				'condition'		=> [ 'feature_style' => [ '2' ] ],
			]
		);
		$this->add_control(
			'shape_for_bg',
			[
				'label' 		=> __( 'Shape Image For BG', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->end_controls_section();

        /*-----------------------------------------features styling------------------------------------*/

		$this->start_controls_section(
			'button_style_section',
			[
				'label' 	=> __( 'Title Style', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
        );
		$this->add_control(
			'overview_content_color',
			[
				'label' 		=> __( 'Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} a'	=> 'color: {{VALUE}}!important;',
				],
			]
        );
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'overview_content_typography',
		 		'label' 		=> __( 'Typography', 'digalu' ),
		 		'selector' 	=> '{{WRAPPER}} a',
			]
		);

        $this->add_responsive_control(
			'overview_content_margin',
			[
				'label' 		=> __( 'Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'overview_content_padding',
			[
				'label' 		=> __( 'Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );
        $this->end_controls_section();

        /*-----------------------------------------features Content styling------------------------------------*/

		$this->start_controls_section(
			'con_style_section',
			[
				'label' 	=> __( 'Content Style', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
        );
		$this->add_control(
			'con_content_color',
			[
				'label' 		=> __( 'Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} p'	=> 'color: {{VALUE}}!important;',
				],
			]
        );
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'con_content_typography',
		 		'label' 		=> __( 'Typography', 'digalu' ),
		 		'selector' 	=> '{{WRAPPER}} p',
			]
		);

        $this->add_responsive_control(
			'con_content_margin',
			[
				'label' 		=> __( 'Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'con_content_padding',
			[
				'label' 		=> __( 'Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );
        $this->end_controls_section();

        /*-----------------------------------------section Content styling------------------------------------*/

		$this->start_controls_section(
			'section_con_styling',
			[
				'label' 	=> __( 'Section Heading', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
        );
        $this->start_controls_tabs(
			'style_tabs1'
		);


		$this->start_controls_tab(
			'style_normal_tab1',
			[
				'label' => esc_html__( 'Subtitle', 'digalu' ),
			]
		);
        $this->add_control(
			's_title_color',
			[
				'label' 		=> __( 'Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .sub-title'	=> '--white: {{VALUE}}!important;',
				],
			]
        );
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 's_title_typography',
		 		'label' 		=> __( 'Typography', 'digalu' ),
		 		'selector' 	=> '{{WRAPPER}} .sub-title',
			]
		);

        $this->add_responsive_control(
			's_title_margin',
			[
				'label' 		=> __( 'Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .sub-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
        );

        $this->add_responsive_control(
			's_title_padding',
			[
				'label' 		=> __( 'Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .sub-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'

				],
			]
        );
		$this->end_controls_tab();

		//--------------------secound--------------------//

		$this->start_controls_tab(
			'style_hover_tab2',
			[
				'label' => esc_html__( 'Title', 'digalu' ),
			]
		);
		$this->add_control(
			's_content_color',
			[
				'label' 		=> __( 'Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .title'	=> 'color: {{VALUE}}!important;',
				]
			]
        );
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 's_content_typography',
		 		'label' 		=> __( 'Typography', 'digalu' ),
		 		'selector' 	=> '{{WRAPPER}} .title',
			]
		);

        $this->add_responsive_control(
			's_content_margin',
			[
				'label' 		=> __( 'Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ],
			]
        );

        $this->add_responsive_control(
			's_content_padding',
			[
				'label' 		=> __( 'Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ],
			]
        );

		$this->end_controls_tab();

		$this->start_controls_tab(
			'style_normal_tab4',
			[
				'label' => esc_html__( 'Devider', 'digalu' ),
			]
		);
        $this->add_control(
			'devider_color',
			[
				'label' 		=> __( 'Devider Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .site-heading .devider::before,{{WRAPPER}} .site-heading .devider'	=> '--color-primary: {{VALUE}}!important;',
				],
			]
        );
        
		$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();
	}

	protected function render() {

        $settings = $this->get_settings_for_display();

        if( $settings['feature_style'] == '1' ){
        	if( $settings['make_slider'] == 'yes' ){
        		$this->add_render_attribute( 'wrapper', 'class', 'row features-carousel swiper' );
				$this->add_render_attribute( 'wrapper', 'data-slide-show', $settings['desktop_items']['size'] );
		        $this->add_render_attribute( 'wrapper', 'data-lg-slide-show', $settings['laptop_items']['size'] );
		        $this->add_render_attribute( 'wrapper', 'data-md-slide-show', $settings['tablet_items']['size'] );
		        $this->add_render_attribute( 'wrapper', 'data-sm-slide-show', $settings['mobile_items']['size'] );

			}else{
				$this->add_render_attribute( 'wrapper', 'class', 'row' );
				if( $settings['colmn_items']['size'] == 1 ){
					$colmn = 12;
				}elseif( $settings['colmn_items']['size'] == 2 ){
					$colmn = 6;
				}elseif( $settings['colmn_items']['size'] == 3 ){
					$colmn = 4;
				}else{
					$colmn = 3;
				}
			}

        	echo '<div class="shape-left-center">';
        		if(!empty($settings['shape_for_bg']['url']))
		        echo '<div class="shape-left-bottom" style="background-image: url('.esc_url($settings['shape_for_bg']['url']).');"></div>';
		        if( $settings['show_heading'] == 'yes' ) {
			        echo '<div class="container">';
			            echo '<div class="row">';
			                echo '<div class="col-lg-8 offset-lg-2">';
			                    echo '<div class="site-heading text-center">';
			                    	if(!empty($settings['subtitle'])){
				                        echo '<h4 class="sub-title">'.esc_html($settings['subtitle']).'</h4>';
				                    }
				                    if(!empty($settings['title'])){
				                        echo '<h2 class="title">'.esc_html($settings['title']).'</h2>';
				                    }
			                        echo '<div class="devider"></div>';
			                    echo '</div>';
			                echo '</div>';
			            echo '</div>';
			        echo '</div>';
			    }

		        echo '<div class="container">';
		            echo '<div class="relative">';
		                echo '<div '.$this->get_render_attribute_string('wrapper').'>';
		                	if( $settings['make_slider'] == 'yes' ){
			                    $div_class = '<div class="swiper-slide feature-style-one">';
			                }else{
			                	$div_class = '<div class="feature-style-one col-lg-'.$colmn.' col-md-6">';
			                }
			                if( $settings['make_slider'] == 'yes' ){
				                echo '<div class="swiper-wrapper">';
				            }
		                    foreach( $settings['features_one'] as $single_data ) { 
		                    	$url = $single_data['details_page'] ;
                        		if(!empty($url)){
                        			$url_start_tag 	= '<a href="'.esc_url($url).'">';
                        			$url_end_tag 	= '</a>';
                        		}else{
                        			$url_start_tag 	= '';
                        			$url_end_tag 	= '';
                        		}
                        		
			                    echo '<!-- Single Item -->';
			                    echo wp_kses_post($div_class);
			                        echo '<div class="item">';
			                            echo '<div class="bg" style="background-image: url('.esc_url($settings['shape']['url']).');"></div>';

			                            if($single_data['chose_icon_style'] == 'class' ){
	                                    	echo '<div class="icon">';
	                                    		echo wp_kses_post($single_data['icon_class']);
	                                    	echo '</div>';
	                                    }else{
	                                    	echo '<div class="icon">';
		                                    	echo digalu_img_tag( array(
													'url'	=> esc_url( $single_data['icon_image']['url'] ),
												) );
											echo '</div>';
	                                    }
			                            if(!empty($single_data['title'])){
			                              	echo '<h4>'.$url_start_tag.esc_html($single_data['title']).$url_end_tag.'</h4>';
			                            }
			                            if(!empty($single_data['desc'])){
			                               	echo '<p>'.esc_html($single_data['desc']).'</p>';
			                            }
			                        echo '</div>';
			                    echo '</div>';
			                    echo '<!-- End Single Item -->';
			                    
			                }
			                if( $settings['make_slider'] == 'yes' ){
				                echo '</div>';
				            } 
			                
		                echo '</div>';
		            echo '</div>';
		        echo '</div>';
		    echo '</div>';
	    }else{

	    	if( $settings['make_slider'] == 'yes' ){
        		$this->add_render_attribute( 'wrapper', 'class', 'row features-carousel swiper' );
				$this->add_render_attribute( 'wrapper', 'data-slide-show', $settings['desktop_items']['size'] );
		        $this->add_render_attribute( 'wrapper', 'data-lg-slide-show', $settings['laptop_items']['size'] );
		        $this->add_render_attribute( 'wrapper', 'data-md-slide-show', $settings['tablet_items']['size'] );
		        $this->add_render_attribute( 'wrapper', 'data-sm-slide-show', $settings['mobile_items']['size'] );

			}else{
				$this->add_render_attribute( 'wrapper', 'class', 'row' );
				if( $settings['colmn_items']['size'] == 1 ){
					$colmn = 12;
				}elseif( $settings['colmn_items']['size'] == 2 ){
					$colmn = 6;
				}elseif( $settings['colmn_items']['size'] == 3 ){
					$colmn = 4;
				}else{
					$colmn = 3;
				}
			}
	    	echo '<div class="services-style-two-area">';
		        if(!empty($settings['shape_1']['url'])){
			        echo '<div class="shape-animation-up-down updown-animation">';
			            echo digalu_img_tag( array(
							'url'	=> esc_url( $settings['shape_1']['url'] ),
						) );
			        echo '</div>';
			    }
		        if( $settings['show_heading'] == 'yes' ) {
			        echo '<div class="container">';
			            echo '<div class="row">';
			                echo '<div class="col-lg-8 offset-lg-2">';
			                    echo '<div class="site-heading text-light text-center">';
			                    	if(!empty($settings['subtitle'])){
				                        echo '<h4 class="sub-title">'.esc_html($settings['subtitle']).'</h4>';
				                    }
				                    if(!empty($settings['title'])){
				                        echo '<h2 class="title">'.esc_html($settings['title']).'</h2>';
				                    }
			                        echo '<div class="devider"></div>';
			                    echo '</div>';
			                echo '</div>';
			            echo '</div>';
			        echo '</div>';
			    }

		            echo '<div '.$this->get_render_attribute_string('wrapper').'>';
		            	if( $settings['make_slider'] == 'yes' ){
		                    $div_class = '<div class="swiper-slide services-style-two">';
		                }else{
		                	$div_class = '<div class="col-xl-'.$colmn.' col-lg-6 col-md-6 services-style-two">';
		                }
		                if( $settings['make_slider'] == 'yes' ){
			                echo '<div class="swiper-wrapper">';
			            }

		            	foreach( $settings['features_one'] as $single_data ) { 
	                    	$url = $single_data['details_page'] ;
                    		if(!empty($url)){
                    			$url_start_tag 	= '<a href="'.esc_url($url).'">';
                    			$url_end_tag 	= '</a>';
                    		}else{
                    			$url_start_tag 	= '';
                    			$url_end_tag 	= '';
                    		}
			                echo '<!-- Single Item -->';
			                echo wp_kses_post($div_class);
			                    echo '<div class="item">';
				                    if(!empty($settings['shape']['url'])){
				                        echo '<div class="shape">';
				                            echo digalu_img_tag( array(
												'url'	=> esc_url( $settings['shape']['url'] ),
											) );
				                        echo '</div>';
				                    }
			                        if($single_data['chose_icon_style'] == 'class' ){
                                    	echo wp_kses_post($single_data['icon_class']);
                                    }else{
                                    	echo '<div class="icon">';
	                                    	echo digalu_img_tag( array(
												'url'	=> esc_url( $single_data['icon_image']['url'] ),
											) );
										echo '</div>';
                                    }
			                        if(!empty($single_data['title'])){
		                              	echo '<h4>'.$url_start_tag.esc_html($single_data['title']).$url_end_tag.'</h4>';
		                            }
		                            if(!empty($single_data['desc'])){
		                               	echo '<p>'.esc_html($single_data['desc']).'</p>';
		                            }
		                            if(!empty($url)){
				                        echo '<a class="btn-icon" href="'.esc_url($url).'">'.esc_html($single_data['read_more_text']).'<i class="fas fa-arrow-right"></i></a>';
				                    }
			                    echo '</div>';
			                echo '</div>';
			                echo '<!-- Single Item -->';
			            }
			            if( $settings['make_slider'] == 'yes' ){
			                echo '</div>';
			            } 
		            echo '</div>';
		    echo '</div>';
	    }
	}
}