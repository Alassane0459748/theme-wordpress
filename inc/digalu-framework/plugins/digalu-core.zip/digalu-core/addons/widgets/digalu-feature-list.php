<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * process Widget .
 *
 */
class Digalu_Feature_List extends Widget_Base {

	public function get_name() {
		return 'digalufeaturelist';
	}

	public function get_title() {
		return __( 'Feature List', 'digalu' );
	}


	public function get_icon() {
		return 'vt-icon';
    }


	public function get_categories() {
		return [ 'digalu' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'feature_list_section',
			[
				'label' 	=> __( 'Feature List', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'feature_style',
			[
				'label' 	=> __( 'Feature Style', 'digalu' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '1',
				'options' 	=> [
					'1'  		=> __( 'Style One', 'digalu' ),
					'2' 		=> __( 'Style Two', 'digalu' ),
				],
			]
		);
        $repeater = new Repeater();

		$repeater->add_control(
			'process_title',
			[
				'label'     => __( 'Title', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default' 		=> __( 'Project Planning' , 'digalu' ),
			]
        );
        $repeater->add_control(
			'process_con',
			[
				'label'     => __( 'Content', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default' 		=> __( 'Share processes and data secure lona need to know basis Our team assured your web site is always.' , 'digalu' ),
			]
        );
        $this->add_control(
			'processs',
			[
				'label' 		=> __( 'Process', 'digalu' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 		=> __( 'title', 'digalu' ),
					],
				],
				'title_field' 	=> '{{{ process_title }}}',
				'condition'		=> [ 'feature_style' => [ '1' ]],
			]
		);

		$this->add_control(
			'image',
			[
				'label' 		=> __( 'Image', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
				'condition'		=> [ 'feature_style' => [ '2' ]],
			]
		);

		$this->add_control(
			'title', [
				'label' 		=> __( 'Title', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Rubaida Kanom' , 'digalu' ),
				'label_block' 	=> true,
				'condition'		=> [ 'feature_style' => [ '2' ]],
			]
        );
        $this->add_control(
			'content', [
				'label' 		=> __( 'Content', 'digalu' ),
				'type' 			=> Controls_Manager::WYSIWYG,
				'default' 		=> __( 'Rubaida Kanom' , 'digalu' ),
				'label_block' 	=> true,
				'condition'		=> [ 'feature_style' => [ '2' ]],
			]
        );
        $this->add_control(
			'details_page', [
				'label' 		=> __( 'Details Page URL', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( '#' , 'digalu' ),
				'label_block' 	=> true,
				'condition'		=> [ 'feature_style' => [ '2' ]],
			]
        );
        $this->add_control(
			'is_active',
			[
				'label' 		=> __( 'Is Active ?', 'digalu' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Show', 'digalu' ),
				'label_off' 	=> __( 'Hide', 'digalu' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
				'condition'		=> [ 'feature_style' => [ '2' ]],
			]
		);
        $this->end_controls_section();

        //---------------------------------------Title Style---------------------------------------//

		$this->start_controls_section(
			'title_style',
			[
				'label' 	=> __( 'Title Style', 'appku' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' 		=> __( 'Title Color', 'appku' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} h4' => 'color: {{VALUE}}',
                ],
			]
        );
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'title_typography',
				'label' 	=> __( 'Title Typography', 'appku' ),
                'selector' 	=> '{{WRAPPER}} h4',
			]
        );
        $this->add_responsive_control(
			'title_margin',
			[
				'label' 		=> __( 'Title Margin', 'appku' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
        );

        $this->add_responsive_control(
			'title_padding',
			[
				'label' 		=> __( 'Title Padding', 'appku' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} h4' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);
		$this->end_controls_section();

		//---------------------------------------Number Style---------------------------------------//

		$this->start_controls_section(
			'con_style',
			[
				'label' 	=> __( 'Description Style', 'appku' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'number_color',
			[
				'label' 		=> __( 'Color', 'appku' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} p' => 'color: {{VALUE}}',
                ],
			]
        );
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'number_typography',
				'label' 	=> __( 'Typography', 'appku' ),
                'selector' 	=> '{{WRAPPER}} p',
			]
        );
        $this->add_responsive_control(
			'number_margin',
			[
				'label' 		=> __( 'Margin', 'appku' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
        );

        $this->add_responsive_control(
			'number_padding',
			[
				'label' 		=> __( 'Padding', 'appku' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);
		$this->end_controls_section();


	}

	protected function render() {

        $settings = $this->get_settings_for_display();

        if( $settings['feature_style'] == '1' ){
	        echo '<div class="list-item-three-box text-light">';
	         	$i = 0;
	         	foreach( $settings['processs'] as $single_data ) {
	         		$i++;
			        $k = str_pad($i, 2, '0', STR_PAD_LEFT);
		            echo '<!-- Single Item -->';
		            echo '<div class="list-style-three">';
		                echo '<span>'.esc_attr($k).'</span>';
		                echo '<div class="content">';
		                    if(!empty($single_data['process_title'])){
				                echo '<h4>'.esc_html($single_data['process_title']).'</h4>';
				            }
				            if(!empty($single_data['process_con'])){
				                echo '<p>'.esc_html($single_data['process_con']).'</p>';
				            }
		                echo '</div>';
		            echo '</div>';
		            echo '<!-- End Single Item -->';
		        }
	        echo '</div>';
	    }else{
	    	$url = $settings['details_page'] ;
			if(!empty($url)){
				$url_start_tag 	= '<a href="'.esc_url($url).'">';
				$url_end_tag 	= '</a>';
			}else{
				$url_start_tag 	= '';
				$url_end_tag 	= '';
			}

			if( $settings['is_active'] == 'yes' ) {
				$active_class = 'active';
			}else{
				$active_class = '';
			}
	    	echo '<div class="services-style-four-area">';
		    	echo '<div class="services-style-four">';
		            echo '<div class="item '.esc_attr($active_class).'">';
		                if( ! empty( $settings['image']['url'] ) ){
				            echo '<div class="thumb">';
				                echo digalu_img_tag( array(
									'url'	=> esc_url( $settings['image']['url'] ),
								) );
				            echo '</div>';
				        }
		                echo '<div class="info">';
		                    if(!empty($settings['title'])){
				                echo '<h4>'.$url_start_tag.esc_html($settings['title']).$url_end_tag.'</h4>';
				            }
				            if(!empty($settings['content'])){
				                echo wp_kses_post($settings['content']);
				            } 
		                echo '</div>';
		            echo '</div>';
		        echo '</div>';
	        echo '</div>';
	    } 
	}
}