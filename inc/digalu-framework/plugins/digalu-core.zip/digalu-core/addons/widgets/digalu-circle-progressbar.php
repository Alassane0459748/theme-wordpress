<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * circle progressbar Widget .
 *
 */
class Digalu_Circle_Progressbar extends Widget_Base {

	public function get_name() {
		return 'digalupcircleprogressbar';
	}

	public function get_title() {
		return __( 'Digalu Circle Progressbar', 'digalu' );
	}


	public function get_icon() {
		return 'vt-icon';
    }


	public function get_categories() {
		return [ 'digalu' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'progressbar_section',
			[
				'label' 	=> __( 'Progressbar', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'progressbar_style',
			[
				'label' 	=> __( 'Progressbar Style', 'digalu' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '1',
				'options' 	=> [
					'1'  		=> __( 'Style One', 'digalu' ),
					'2' 		=> __( 'Style Two', 'digalu' ),
					'3' 		=> __( 'Style Three', 'digalu' ),
				],
			]
		);

        $this->add_control(
			'progressbar_text',
			[
				'label'     => __( 'Progressbar Text', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default' 		=> __('Business Growth','digalu'),
                'condition'		=> [ 'progressbar_style' => ['1'] ]
			]
        );
        $this->add_control(
			'progressbar_number',
			[
				'label'     => __( 'Progressbar Number', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default' 		=> __('Business Growth','digalu'),
                'condition'		=> [ 'progressbar_style' => ['1'] ]
			]
        );

        $repeater = new Repeater();

        $repeater->add_control(
			's_progressbar_text',
			[
				'label'     => __( 'Progressbar Text', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default' 		=> __('Business Growth','digalu'),
			]
        );
        $repeater->add_control(
			's_progressbar_number',
			[
				'label'     => __( 'Progressbar Number', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default' 		=> __('50','digalu'),
			]
        );

        $this->add_control(
			'progressbars',
			[
				'label' 		=> __( 'Progressbar', 'digalu' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'progressbar_text' 		=> __( 'title', 'digalu' ),
					],
				],
				'title_field' 	=> '{{{ s_progressbar_text }}}',
				'condition'		=> [ 'progressbar_style' => ['2', '3'] ]
			]
		);
        $this->end_controls_section();
        //-------------------------------video button styling------------------------------- //

		$this->start_controls_section(
			'circle_style_section',
			[
				'label' 	=> __( 'Bg Color', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_shadow',
				'label' => esc_html__( 'Box Shadow', 'appku' ),
				'selector' => '{{WRAPPER}} .choose-us-style-one .progressbar',
				'condition'		=> [ 'progressbar_style' => ['1'] ]
			]
		);
		$this->add_control(
			'bg_color',
			[
				'label' 		=> __( 'Background Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .choose-us-style-one .progressbar' => '--white: {{VALUE}}',
                ],
                'condition'		=> [ 'progressbar_style' => ['1'] ]
			]
        );
        $this->add_control(
			'txt_color',
			[
				'label' 		=> __( 'Text Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .choose-us-style-one,{{WRAPPER}} .circle-progress-items' => '--color-heading: {{VALUE}}',
                ],
			]
        );

		

		$this->end_controls_section();
	}

	protected function render() {

        $settings = $this->get_settings_for_display();

        if( $settings['progressbar_style'] == '1' ){
	        echo '<div class="choose-us-style-one">';
		        echo '<div class="progressbar">';
		        	if(!empty($settings['progressbar_number'])){
			            echo '<div class="circle" data-percent="'.esc_attr($settings['progressbar_number']).'"><strong></strong></div>';
			        }
			        if(!empty($settings['progressbar_text'])){
			            echo '<h4>'.esc_html($settings['progressbar_text']).'</h4>';
			        }
		        echo '</div>';
	        echo '</div>';
	    }elseif( $settings['progressbar_style'] == '2' ){
	    	echo '<div class="circle-progress-items">';
                foreach( $settings['progressbars'] as $single_data ) {        
		            echo '<div class="circle-progress-item">';
		                echo '<div class="progressbar-hard">';
		                	if(!empty($single_data['s_progressbar_number'])){
			                    echo '<div class="circle" data-percent="'.esc_attr($single_data['s_progressbar_number']).'">';
			                        echo '<strong></strong>';
			                    echo '</div>';
			                }
		                echo '</div>';
		                if(!empty($single_data['s_progressbar_text'])){
			                echo '<h4>'.esc_html($single_data['s_progressbar_text']).'</h4>';
			            }
		            echo '</div>';
		        }  
	        echo '</div>';
	    }else{
	    	echo '<div class="skill-items">';
	    		foreach( $settings['progressbars'] as $single_data ) {  
	                echo '<!-- Progress Bar Start -->';
	                echo '<div class="progress-box">';
	                    if(!empty($single_data['s_progressbar_text'])){
			                echo '<h5>'.esc_html($single_data['s_progressbar_text']).'</h5>';
			            }
			            if(!empty($single_data['s_progressbar_number'])){
		                    echo '<div class="progress">';
		                        echo '<div class="progress-bar" role="progressbar-2" data-width="'.esc_attr($single_data['s_progressbar_number']).'">';
		                             echo '<span>'.esc_attr($single_data['s_progressbar_number']).'%</span>';
		                        echo '</div>';
		                    echo '</div>';
		                }
	                echo '</div>';
	                echo '<!-- End Progressbar -->';
	            }

            echo '</div>';
	    }
	}

}