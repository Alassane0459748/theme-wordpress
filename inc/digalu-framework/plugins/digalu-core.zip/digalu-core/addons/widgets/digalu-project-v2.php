<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Project Box Widget .
 *
 */
class Digalu_Project_V2 extends Widget_Base {

	public function get_name() {
		return 'digaluproject2';
	}

	public function get_title() {
		return __( 'Digalu Project V2', 'digalu' );
	}


	public function get_icon() {
		return 'vt-icon';
    }


	public function get_categories() {
		return [ 'digalu' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'project_section',
			[
				'label' 	=> __( 'Project', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'style',
			[
				'label' 	=> __( 'Feature Style', 'digalu' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '1',
				'options' 	=> [
					'1'  		=> __( 'Style One', 'digalu' ),
					'2' 		=> __( 'Style Two', 'digalu' ),
				],
			]
		);

		$this->add_control(
			'section_title',
			[
				'label' 	=> __( 'Title', 'digalu' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'default'  	=> __( 'Section Title', 'digalu' ),
			]
        );
        $this->add_control(
			'section_subtitle',
			[
				'label' 	=> __( 'Subitle', 'digalu' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'default'  	=> __( 'Section Subitle', 'digalu' ),
			]
        );
		$this->add_control(
			'all_text', [
				'label' 		=> __( 'All filter label', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'All' , 'digalu' ),
				'rows' 			=> 2,
				'label_block' 	=> true,
				'condition'		=> [ 'style' => ['1' ] ],
			]
		);		
        $repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'     => __( 'Title', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default' 		=> __( 'Project Title' , 'digalu' ),
			]
        );
        $repeater->add_control(
			'cats',
			[
				'label'     => __( 'Category', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default' 		=> __( 'CONSTRUCTION' , 'digalu' ),
			]
        );
        $repeater->add_control(
			'tags',
			[
				'label'     => __( 'Categories', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default' 		=> __( 'Marketing, Sales' , 'digalu' ),
                'description' 		=> __( 'Use (,) for separate categories' , 'digalu' ),
			]
        );
        $repeater->add_control(
			'image',
			[
				'label' 		=> __( 'Choose Image', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'details_page',
			[
				'label'     => __( 'Single Page URL', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
			]
        );
        $this->add_control(
			'projects',
			[
				'label' 		=> __( 'Projects', 'digalu' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 		=> __( 'title', 'digalu' ),
					],
				],
			]
		);
		
        $this->end_controls_section();
	}

	protected function render() {

        $settings = $this->get_settings_for_display();
        if( $settings['style'] == '1' ){
	    	echo '<div class="portfolio-area default-padding bg-cover shadow light">';
		        echo '<div class="container">';
		            echo '<div class="row">';
		                echo '<div class="col-lg-4">';
		                    echo '<div class="portfolio-left-heading">';
		                    	if( ! empty( $settings['section_title'] ) ){
			                        echo '<h4 class="sub-title">' .esc_html( $settings['section_title'] ). '</h4>';
			                    }
			                    if( ! empty( $settings['section_subtitle'] ) ){
			                        echo '<h2 class="title">' .esc_html( $settings['section_subtitle'] ). '</h2>';
			                    }
		                        echo '<div class="mix-item-menu mt-30">';
		                        	$text = !empty( $settings['all_text'] ) ? $settings['all_text'] : esc_html__( 'All', 'digalu' );
				                	$filters = array();
					            	foreach( $settings['projects'] as $project ) {
					            		$temp_filters = explode (",", $project['cats']);
					            		foreach( $temp_filters as $temp_filter ) {
					            			$filters[strtolower(trim($temp_filter))] = $temp_filter;
					            		}
					            	}
		                            echo '<button class="active" data-filter="*">' .esc_html( $text ). '</button>';
		                            foreach( $filters as $filter ) {
					                    echo '<button data-filter=".'.esc_attr( strtolower($filter) ).'">'.esc_html( $filter ).'</button>';
					                }
		                        echo '</div>';
		                    echo '</div>';
		                echo '</div>';
		                echo '<div class="col-lg-8 pl-80 pl-md-15 pl-xs-15">';
		                    echo '<div class="magnific-mix-gallery masonary">';
		                        echo '<div id="portfolio-grid" class="portfolio-items colums-2">';
		                        	foreach( $settings['projects'] as $project ) {
				        				$filter_slug = strtolower(str_replace(',', ' ', $project['cats']));
			                            echo '<!-- Single Item -->';
			                            echo '<div class="pf-item '.esc_attr( $filter_slug ).'">';
			                                echo '<div class="thumb">';
			                                    if( ! empty( $project['image']['url'] ) ){
							                        echo digalu_img_tag( array(
														'url'   => esc_url( $project['image']['url'] ),
													) );
							                    }
			                                    echo '<a href="'.esc_url( $project['image']['url'] ).'" class="item popup-link"><i class="fa fa-plus"></i></a>';
			                                echo '</div>';
			                                echo '<div class="info">';
			                                	if( ! empty( $project['title'] ) ){
				                                    echo '<h4><a href="'.esc_url($project['details_page']).'">'.esc_html( $project['title'] ).'</a></h4>';
				                                }
			                                    echo '<div class="cat">';
			                                        $str = $project['tags'];
													$delimiter = ',';
													$words = explode($delimiter, $str);
								                    foreach ($words as $word) {
								                    	echo '<span>'.esc_html($word).'</span> ';
								                    }
			                                    echo '</div>';
			                                echo '</div>';
			                            echo '</div>';
			                            echo '<!-- End Single Item -->';
			                        }
		                        echo '</div>';
		                	echo '</div>';
		                echo '</div>';
		            echo '</div>';
		        echo '</div>';
		    echo '</div>';
		}else{
			echo '<div class="project-style-two-area overflow-hidden bg-gray default-padding">';
		        echo '<div class="container">';
		            echo '<div class="row">';
		                echo '<div class="col-lg-6">';
		                    echo '<div class="heading-left text-light">';
		                        if(!empty($settings['section_title'])){
			                        echo '<h4 class="sub-title">'.esc_html($settings['section_title']).'</h4>';
			                    }
			                    if(!empty($settings['section_subtitle'])){
			                        echo '<h2 class="title">'.esc_html($settings['section_subtitle']).'</h2>';
			                    }
		                    echo '</div>';
		                echo '</div>';
		            echo '</div>';
		        echo '</div>';

		        echo '<div class="container">';
		            echo '<div class="col-lg-12">';
		                echo '<!-- Navigation -->';
		                echo '<div class="project-two-swiper-nav">';
		                    echo '<!-- Pagination -->';
		                    echo '<div class="stage-pagination"></div>';
		                echo '</div>';
		            echo '</div>';
		        echo '</div>';

		        echo '<div class="container container-stage">';
		            echo '<div class="row">';
		                echo '<div class="col-lg-12">';
		                    echo '<div class="stage-carousel swiper">';
		                        echo '<!-- Additional required wrapper -->';
		                       	echo ' <div class="swiper-wrapper">';

		                       		foreach( $settings['projects'] as $project ) {
			                            echo '<!-- Single Item -->';
			                            echo '<div class="swiper-slide">';
			                                echo '<div class="project-style-two">';
			                                    echo '<div class="thumb">';
			                                        if( ! empty( $project['image']['url'] ) ){
								                        echo digalu_img_tag( array(
															'url'   => esc_url( $project['image']['url'] ),
														) );
								                    }
			                                        echo '<div class="content">';
			                                            if( ! empty( $project['title'] ) ){
						                                    echo '<h4><a href="'.esc_url($project['details_page']).'">'.esc_html( $project['title'] ).'</a></h4>';
						                                }
			                                            $str = $project['tags'];
									                    echo '<span>'.esc_html($str).'</span> ';
			                                        echo '</div>';
			                                   	echo '</div>';
			                                echo '</div>';
			                            echo '</div>';
			                            echo '<!-- End Single Item -->';
			                        }
		                            
		                        echo '</div>';
		                    echo '</div>';

		                echo '</div>';
		            echo '</div>';
		        echo '</div>';
		    echo '</div>';
		}
	}
}