<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * WCU Box Widget .
 *
 */
class Digalu_Services_V2 extends Widget_Base {

	public function get_name() {
		return 'digaluservicesv2';
	}

	public function get_title() {
		return __( 'Digslu Services V2', 'digalu' );
	}


	public function get_icon() {
		return 'vt-icon';
    }


	public function get_categories() {
		return [ 'digalu' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'services_section',
			[
				'label' 	=> __( 'Services', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'layout',
			[
				'label' 		=> __( 'Style', 'digalu' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> '1',
				'options'		=> [
					'1'  			=> __( 'Style One', 'digalu' ),
					'2' 			=> __( 'Style Two', 'digalu' ),
				],
			]
		);

		//-------------------------------------section heading start-------------------------------------//

		$this->add_control(
			'show_section_heading',
			[
				'label' 		=> __( 'Show SSection Header?', 'digalu' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Show', 'digalu' ),
				'label_off' 	=> __( 'Hide', 'digalu' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);

		$this->add_control(
			'title',
			[
				'label'     	=> __( 'Title', 'digalu' ),
                'type'      	=> Controls_Manager::TEXTAREA,
                'rows' 			=> 2,
                'default' 		=>  __( 'This is title area', 'digalu'),
                'condition'		=> [ 'show_section_heading' => 'yes'  ],
			]
        );
        $this->add_control(
			'subtitle',
			[
				'label'     	=> __( 'Subtitle', 'digalu' ),
                'type'      	=> Controls_Manager::TEXTAREA,
                'rows' 			=> 2,
                'default' 		=>  __( 'This is subtitle area', 'digalu'),
                'condition'		=> [ 'show_section_heading' => 'yes'  ],
			]
        );

		

		$repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'     => __( 'Title', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
			]
        );
        $repeater->add_control(
			'content',
			[
				'label'     => __( 'Content', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 4,
			]
        );
        $repeater->add_control(
			'btn_txt',
			[
				'label'     => __( 'Button Text', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
			]
        );
        $repeater->add_control(
			'url',
			[
				'label'     => __( 'Details Page', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
			]
        );
        $repeater->add_control(
			'icon_image',
			[
				'label' 		=> __( 'Image', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'make_active',
			[
				'label' 		=> __( 'Make it active?', 'digalu' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Show', 'digalu' ),
				'label_off' 	=> __( 'Hide', 'digalu' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);
        $this->add_control(
			'services_1',
			[
				'label' 		=> __( 'Services', 'digalu' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 		=> __( 'Marketing Strategy', 'digalu' ),
					],
				],
				'title_field' 	=> '{{{ title }}}',
				'condition'		=> [ 'layout' => '1'  ]
			]
		);

        //-------------------------------style 2-------------------------------//
		$repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'     => __( 'Title', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
			]
        );
        $repeater->add_control(
			'content',
			[
				'label'     => __( 'Content', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 4,
			]
        );
        $repeater->add_control(
			'url',
			[
				'label'     => __( 'Details Page', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
			]
        );
        $repeater->add_control(
			'icon_class',
			[
				'label'     => __( 'Icon Class', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
			]
		);
        $this->add_control(
			'services_2',
			[
				'label' 		=> __( 'Services', 'digalu' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 		=> __( 'Marketing Strategy', 'digalu' ),
					],
				],
				'title_field' 	=> '{{{ title }}}',
				'condition'		=> [ 'layout' => '2'  ]
			]
		);
		$this->add_control(
			'shape',
			[
				'label' 		=> __( 'Shape', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
			]
		);

        $this->end_controls_section();

        /*-------------------------------------------------------------Feedback styling--------------------------------------------------------*/

		$this->start_controls_section(
			'Section_header_styling',
			[
				'label' 	=> __( 'Header Style', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
				'condition'		=> [ 'show_section_heading' => 'yes'  ]
			]
        );
        $this->start_controls_tabs(
			'header_tabs1'
		);

		//--------------------first tab start--------------------//

		$this->start_controls_tab(
			'header_title',
			[
				'label' => esc_html__( 'Title', 'digalu' ),
			]
		);
        $this->add_control(
			'header_from_color',
			[
				'label' 		=> __( 'Gradient Color From', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .sub-title' => '--color-primary: {{VALUE}}!important;',
                ],
			]
        );
        $this->add_control(
			'header_to_color',
			[
				'label' 		=> __( 'Gradient Color To', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .sub-title' => '--color-secondary: {{VALUE}}!important;',
                ],
			]
        );
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'header_title_typography',
		 		'label' 		=> __( 'Typography', 'digalu' ),
		 		'selector' 	=> '{{WRAPPER}} .sub-title',
			]
		);

        $this->add_responsive_control(
			'header_title_margin',
			[
				'label' 		=> __( 'Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .sub-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'header_title_padding',
			[
				'label' 		=> __( 'Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .sub-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

		$this->end_controls_tab();

		//--------------------first tab end--------------------//


		//--------------------2nd tab start--------------------//

		$this->start_controls_tab(
			'header_tabs2',
			[
				'label' => esc_html__( 'subtitle', 'digalu' ),
			]
		);
		$this->add_control(
			'header_subtitle_color',
			[
				'label' 		=> __( 'Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} h2'	=> '--color-heading: {{VALUE}}!important;',
				],
			]
        );
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'header_subtitle_typography',
		 		'label' 		=> __( 'Typography', 'digalu' ),
		 		'selector' 	=> '{{WRAPPER}} h2',
			]
		);

        $this->add_responsive_control(
			'header_subtitle_margin',
			[
				'label' 		=> __( 'Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'header_subtitle_padding',
			[
				'label' 		=> __( 'Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );



		$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();




		/*-------------------------------------------------------------Feedback styling--------------------------------------------------------*/

		$this->start_controls_section(
			'service_styling',
			[
				'label' 	=> __( 'Service Style', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
        );
        $this->start_controls_tabs(
			'service_tabs1'
		);

		//--------------------first tab start--------------------//

		$this->start_controls_tab(
			'service_title',
			[
				'label' => esc_html__( 'Title', 'digalu' ),
			]
		);
        $this->add_control(
			'service_fcolor',
			[
				'label' 		=> __( 'Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} a' => '--color-heading: {{VALUE}}!important;',
                ],
			]
        );
        
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'service_title_typography',
		 		'label' 		=> __( 'Typography', 'digalu' ),
		 		'selector' 	=> '{{WRAPPER}} a',
			]
		);

        $this->add_responsive_control(
			'service_title_margin',
			[
				'label' 		=> __( 'Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'service_title_padding',
			[
				'label' 		=> __( 'Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

		$this->end_controls_tab();

		//--------------------first tab end--------------------//


		//--------------------2nd tab start--------------------//

		$this->start_controls_tab(
			'service_tabs2',
			[
				'label' => esc_html__( 'Content', 'digalu' ),
			]
		);
		$this->add_control(
			'service_subtitle_color',
			[
				'label' 		=> __( 'Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} p'	=> '--color-paragraph: {{VALUE}}!important;',
				],
			]
        );
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'service_subtitle_typography',
		 		'label' 		=> __( 'Typography', 'digalu' ),
		 		'selector' 	=> '{{WRAPPER}} p',
			]
		);

        $this->add_responsive_control(
			'service_subtitle_margin',
			[
				'label' 		=> __( 'Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'service_subtitle_padding',
			[
				'label' 		=> __( 'Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );



		$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();

		/*--------------------------------------------------------end Feedback styling---------------------------------------------------*/


	}

	protected function render() {

        $settings = $this->get_settings_for_display();

        if( $settings['layout'] == '1' ){

        	$shape = $settings['shape']['url'] ? $settings['shape']['url'] : '#';


        	echo '<div class="services-style-five-area text-center default-padding bottom-less bg-theme bg-cover shadow theme" style="background-image: url('.esc_url( $shape ).');">';

        		if( $settings['show_section_heading'] == 'yes' ) {
			        echo '<div class="container">';
			            echo '<div class="row">';
			                echo '<div class="col-lg-8 offset-lg-2">';
			                    echo '<div class="site-heading text-light text-center">';
			                        if( ! empty( $settings['title'] ) ){
				                        echo '<h5 class="sub-title">'.esc_html( $settings['title'] ).'</h5>';
				                    }
				                    if( ! empty( $settings['subtitle'] ) ){
				                        echo '<h2 class="title">'.wp_kses_post( $settings['subtitle'] ).'</h2>';
				                    }
			                        echo '<div class="devider"></div>';
			                    echo '</div>';
			                echo '</div>';
			           echo ' </div>';
			        echo '</div>';
			    }

		        echo '<div class="container">';
		            echo '<div class="row">';
		                foreach( $settings['services_1'] as $data ) {  

		                	if( $data['make_active'] == 'yes' ) {
		                		$class = 'active';
		                	}else{
		                		$class = '';
		                	}
			                echo '<!-- Single Item -->';
			                echo '<div class="col-xl-3 col-md-6 mb-30">';
			                    echo '<div class="services-style-five '.esc_attr( $class ).'">';
			                        echo '<div class="icon">';
			                            if( ! empty( $data['icon_image']['url'] ) ){
					                        echo digalu_img_tag( array(
												'url'	=> esc_url( $data['icon_image']['url'] ),
											) );
					                    }
			                        echo '</div>';
			                        if( ! empty( $data['title'] ) ){
				                        echo '<h4><a href="'.esc_url( $data['url'] ).'">'.esc_html( $data['title'] ).'</a></h4>';
				                    }
			                        if( ! empty( $data['content'] ) ){
				                        echo '<p>'.esc_html( $data['content'] ).'</p>';
				                    }
				                    if( ! empty( $data['btn_txt'] ) ){
				                        echo '<a href="'.esc_url( $data['url'] ).'" class="btn-service">'.esc_html( $data['btn_txt'] ).'</a>';
				                    }
			                    echo '</div>';
			                echo '</div>';
			                echo '<!-- End Single Item -->';
			            }
		                
		            echo '</div>';
		        echo '</div>';
		    echo '</div>';

	    }else{
	    	echo '<div class="services-style-six-area">';

		        echo '<div class="container">';
		            echo '<div class="row">';

		                if( $settings['show_section_heading'] == 'yes' ) {
		                	$shape = $settings['shape']['url'] ? $settings['shape']['url'] : '#';

			                echo '<div class="col-lg-5">';
			                    echo '<div class="service-six-heading text-light" style="background-image: url('.esc_url( $shape ).');">';
			                        if( ! empty( $settings['title'] ) ){
				                        echo '<h5 class="sub-title">'.esc_html( $settings['title'] ).'</h5>';
				                    }
			                        if( ! empty( $settings['subtitle'] ) ){
				                        echo '<h2 class="heading">'.wp_kses_post( $settings['subtitle'] ).'</h2>';
				                    }
			                        echo '<img src="'.DIGALU_PLUGDIRURI . 'assets/img/ba.png" alt="Image Not Found">';
			                    echo '</div>';
			                echo '</div>';
			            }
		             
		                
		                echo '<div class="col-lg-7 pl-50 pl-md-15 pl-xs-15 mt--30 mt-md-30 mt-xs-0">';
		                    echo '<div class="row">';

		                    	foreach( $settings['services_2'] as $data ) { 
			                        echo '<!-- Single Item -->';
			                        echo '<div class="col-lg-6 col-md-6">';
			                            echo '<div class="service-six-item">';
			                            	if( ! empty( $data['icon_class'] ) ){
				                                echo wp_kses_post( $data['icon_class'] );
				                            }
			                                if( ! empty( $data['title'] ) ){
						                        echo '<h4><a href="'.esc_url( $data['url'] ).'">'.esc_html( $data['title'] ).'</a></h4>';
						                    }
			                                if( ! empty( $data['content'] ) ){
						                        echo '<p>'.esc_html( $data['content'] ).'</p>';
						                    }
			                            echo '</div>';
			                        echo '</div>';
			                        echo '<!-- End Single Item -->';
			                    }
		                        
		                    echo '</div>';
		                echo '</div>';
		                
		            echo '</div>';
		        echo '</div>';
		    echo '</div>';
	    }
	}
}