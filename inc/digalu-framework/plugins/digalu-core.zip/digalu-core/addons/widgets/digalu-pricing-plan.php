<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * pricing Plan Widget .
 *
 */
class Digalu_Pricing_Plan extends Widget_Base {

	public function get_name() {
		return 'digalupricingplan';
	}

	public function get_title() {
		return __( 'Pricing Table', 'digalu' );
	}


	public function get_icon() {
		return 'vt-icon';
    }


	public function get_categories() {
		return [ 'digalu' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'pricing_section',
			[
				'label' 	=> __( 'Pricing Table', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'price_style',
			[
				'label' 	=> __( 'Pricing Style', 'digalu' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '1',
				'options' 	=> [
					'1'  		=> __( 'Style One', 'digalu' ),
					'2' 		=> __( 'Style Two', 'digalu' ),
				],
			]
		);
		$this->add_control(
			'package', [
				'label' 		=> __( 'Package', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Trial Version' , 'digalu' ),
				'label_block' 	=> true,
			]
        );
        $this->add_control(
			'offer_text', [
				'label' 		=> __( 'Savings Text', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Save 25%' , 'digalu' ),
				'label_block' 	=> true,
				'condition'		=> [ 'price_style' => [ '1' ] ],

			]
        );
        $this->add_control(
			'plan', [
				'label' 		=> __( 'Pricing Plan', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( '<sup>$</sup>0 <sub>/ Monthly</sub>' , 'digalu' ),
				'label_block' 	=> true,
			]
        );
        $this->add_control(
			'chose_icon_style',
			[
				'label' 		=> __( 'Icon Type', 'digalu' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'class',
				'options' 		=> [
					'class'  	=> __( 'Class', 'digalu' ),
					'img' 		=> __( 'Image', 'digalu' ),
				],
			]
		);
        $this->add_control(
			'icon_class', [
				'label' 		=> __( 'Icon Class', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( '<i class="fas fa-rocket"></i>' , 'digalu' ),
				'label_block' 	=> true,
				'condition'		=> [ 'chose_icon_style' => [ 'class' ] ],
			]
        );
        $this->add_control(
			'icon_image',
			[
				'label' 		=> __( 'Image', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
				'condition'		=> [ 'chose_icon_style' => [ 'img' ] ],
			]
		);
        
        $this->add_control(
			'features', [
				'label' 		=> __( 'Feedback', 'digalu' ),
				'type' 			=> Controls_Manager::WYSIWYG,
				'default' 		=> __( 'Rubaida Kanom' , 'digalu' ),
				'label_block' 	=> true,
			]
        );
        $this->add_control(
			'button_text',
			[
				'label' 	=> __( 'Button Text', 'digalu' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default'  	=> __( 'Button Text', 'digalu' )
			]
        );
        $this->add_control(
			'button_link',
			[
				'label' 		=> __( 'Link', 'digalu' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __( 'https://your-link.com', 'digalu' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
			]
		);
		$this->add_control(
			'make_it_active',
			[
				'label' 		=> __( 'Make it Active ?', 'digalu' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Show', 'digalu' ),
				'label_off' 	=> __( 'Hide', 'digalu' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);
		$this->add_control(
			'show_badge',
			[
				'label' 		=> __( 'Show Badge ?', 'digalu' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Show', 'digalu' ),
				'label_off' 	=> __( 'Hide', 'digalu' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);
		$this->add_control(
			'badge_title',
			[
				'label' 	=> __( 'Badge Title', 'digalu' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default'  	=> __( 'Recomendad', 'digalu' ),
                'condition'		=> [ 'show_badge' => [ 'yes']],
			]
        );
		$this->end_controls_section();
		//---------------------------------------general Style---------------------------------------//

		$this->start_controls_section(
			'general_style',
			[
				'label' 	=> __( 'General Style', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'pricing_cart_bg',
			[
				'label' 		=> __( 'Pricing BG', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .pricing-style-one-item'	=> '--white: {{VALUE}}!important;',
					'{{WRAPPER}} .pricing-style-three'	=> 'background: {{VALUE}}!important;',
				],
			]
        );
        $this->add_control(
			'content_color',
			[
				'label' 		=> __( 'Content Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .pricing-style-one-item h4,{{WRAPPER}} .pricing-style-one-item span,{{WRAPPER}} .pricing-style-one-item h2'	=> 'color: {{VALUE}}!important;',
					'{{WRAPPER}} h2'	=> '--color-heading: {{VALUE}}!important;',
				],
			]
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'button_style_section',
			[
				'label' 	=> __( 'Button Style', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
        );

        $this->add_control(
			'button_color',
			[
				'label' 		=> __( 'Button Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .vs-btn' => 'color: {{VALUE}}',
					'{{WRAPPER}} .banner_btn' => 'color: {{VALUE}}',
                ],
			]
        );

        $this->add_control(
			'button_color_hover',
			[
				'label' 		=> __( 'Button Color Hover', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .vs-btn:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .banner_btn:hover' => 'color: {{VALUE}}',
                ],
			]
        );

        $this->add_control(
			'button_bg_color',
			[
				'label' 		=> __( 'Button Background Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .vs-btn .btn-bg,{{WRAPPER}} .vs-btn,{{WRAPPER}} .banner_btn' => 'background-color:{{VALUE}}',
					'{{WRAPPER}} .btn.btn-gradient::after' => 'background:{{VALUE}}!important;',
                ],
			]
        );

        $this->add_control(
			'button_bg_hover_color',
			[
				'label' 		=> __( 'Button Background Hover Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .vs-btn' => '--dark:{{VALUE}}',
                ],
			]
        );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'border',
				'label' 	=> __( 'Border', 'digalu' ),
                'selector' 	=> '{{WRAPPER}} .vs-btn,{{WRAPPER}} .banner_btn',
			]
		);

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'border_hover',
				'label' 	=> __( 'Border Hover', 'digalu' ),
                'selector' 	=> '{{WRAPPER}} .vs-btn:hover',
			]
		);

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'button_typography',
				'label' 	=> __( 'Button Typography', 'digalu' ),
                'selector' 	=> '{{WRAPPER}} .vs-btn,{{WRAPPER}} .{{WRAPPER}} .banner_btn',
			]
        );

        $this->add_responsive_control(
			'button_margin',
			[
				'label' 		=> __( 'Button Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .vs-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .banner_btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
        );

        $this->add_responsive_control(
			'button_padding',
			[
				'label' 		=> __( 'Button Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .vs-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .banner_btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);
        $this->add_responsive_control(
			'button_border_radius',
			[
				'label' 		=> __( 'Button Border Radius', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .vs-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .banner_btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);
        $this->end_controls_section();


	}

	protected function render() {

        $settings = $this->get_settings_for_display();

        if( $settings['make_it_active'] == 'yes' ){
    		$active_class = 'active';
    	}else{
    		$active_class = '';
    	}

        if( $settings['price_style'] == '1' ){
        	echo '<div class="pricing-style-one-box">';
	        	echo '<div class="pricing-style-one '.esc_attr($active_class).'">';
	                echo '<div class="pricing-style-one-item">';
	                	if( $settings['show_badge'] == 'yes' &&  !empty($settings['badge_title'])){
		                    echo '<div class="span badge">'.esc_html($settings['badge_title']).'</div>';
		                }
	                    if($settings['chose_icon_style'] == 'class' ){
                        		echo wp_kses_post($settings['icon_class']);
                        }else{
                        	echo '<div class="icon">';
                            	echo digalu_img_tag( array(
									'url'	=> esc_url( $settings['icon_image']['url'] ),
								) );
							echo '</div>';
                        }
	                    echo '<div class="pricing-header">';
	                        if(!empty($settings['package'])){
                                echo '<h4>'.wp_kses_post($settings['package']).'</h4>';
                            }
                            if(!empty($settings['offer_text'])){
                                echo '<span>'.wp_kses_post($settings['offer_text']).'</span>';
                            }
	                    echo '</div>';
	                    echo '<div class="price">';
	                        if(!empty($settings['plan'])){
                                echo '<h2>'.wp_kses_post($settings['plan']).'</h2>';
                            }
	                    echo '</div>';
	                    	if(!empty($settings['features'])){
                                echo wp_kses_post($settings['features']);
                            }
                        if(!empty($settings['button_text'])){
                            $target_team 	= $settings['button_link']['is_external'] ? ' target="_blank"' : '';
							$nofollow_team 	= $settings['button_link']['nofollow'] ? ' rel="nofollow"' : '';
                                echo '<a '.wp_kses_post( $target_team.$nofollow_team ).' href="'.esc_url( $settings['button_link']['url'] ).'" class="btn vs-btn circle mt-25 btn-md btn-theme animation">'.esc_html( $settings['button_text'] ).'</a>';
                        }
	                echo '</div>';
	            echo '</div>';
            echo '</div>';
	    }else{

	    	echo '<div class="pricing-style-three '.esc_attr($active_class).'">';
                echo '<div class="row align-center">';
                	if($settings['chose_icon_style'] == 'class' ){
                    		echo wp_kses_post($settings['icon_class']);
                    }else{
                    	echo '<div class="col-lg-2 thumb">';
                        	echo digalu_img_tag( array(
								'url'	=> esc_url( $settings['icon_image']['url'] ),
							) );
						echo '</div>';
                    }
                    if(!empty($settings['package'])){
                    	echo '<div class="col-lg-2 title">';
                    		if( $settings['show_badge'] == 'yes' &&  !empty($settings['badge_title'])){
			                    echo '<span>'.esc_html($settings['badge_title']).'</span>';
			                }
                        	echo '<h2>'.wp_kses_post($settings['package']).'</h2>';
                        echo '</div>';
                    }
                    
                    if(!empty($settings['features'])){
                    	echo '<div class="col-lg-3 details">';
                        	echo wp_kses_post($settings['features']);
                        echo '</div>';
                    }
                    if(!empty($settings['plan'])){
                    	echo '<div class="col-lg-2 price">';
                        	echo '<h2>'.wp_kses_post($settings['plan']).'</h2>';
                        echo '</div>';
                    }
                    if(!empty($settings['button_text'])){                   
	                    echo '<div class="col-lg-3 button text-end">';
	                    	$target_team 	= $settings['button_link']['is_external'] ? ' target="_blank"' : '';
							$nofollow_team 	= $settings['button_link']['nofollow'] ? ' rel="nofollow"' : '';
                            echo '<a '.wp_kses_post( $target_team.$nofollow_team ).' href="'.esc_url( $settings['button_link']['url'] ).'" class="vs-btn btn circle btn-md btn-gradient animation">'.esc_html( $settings['button_text'] ).'</a>';
	                    echo '</div>';
	                }
                echo '</div>';
            echo '</div>';
	    }
	}
}