<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Group_Control_Border;
/**
 *
 * Banner Widget .
 *
 */
class Digalu_Banner extends Widget_Base {

	public function get_name() {
		return 'digalubanner';
	}

	public function get_title() {
		return __( 'Banner', 'digalu' );
	}

	public function get_icon() {
		return 'vt-icon';
    }

	public function get_categories() {
		return [ 'digalu_header_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'Banner_section',
			[
				'label' 	=> __( 'Banner', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

		$this->add_control(
			'banner_style',
			[
				'label' 		=> __( 'Banner Style', 'digalu' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> '1',
				'options' 		=> [
					'1'  		=> __( 'Style One', 'digalu' ),
					'2' 		=> __( 'Style Two', 'digalu' ),
					'3' 		=> __( 'Style Three', 'digalu' ),
					'4' 		=> __( 'Style Four', 'digalu' ),
					'5' 		=> __( 'Style Five', 'digalu' ),
					'6' 		=> __( 'Style Six', 'digalu' ),
				],
			]
		);

		$this->add_control(
			'banner_image',
			[
				'label' 		=> __( 'Banner Image', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'default' 		=> [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'banner_image2',
			[
				'label' 		=> __( 'Banner Image 2', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'default' 		=> [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition'		=> [ 'banner_style' => ['2','4','5', '3','6'] ],
			]
		);
		$this->add_control(
			'banner_image3',
			[
				'label' 		=> __( 'Banner Image 3', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'default' 		=> [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition'		=> [ 'banner_style' => ['2','4','6'] ],
			]
		);
		$this->add_control(
			'banner_image4',
			[
				'label' 		=> __( 'Banner Image 4', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'default' 		=> [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition'		=> [ 'banner_style' => ['4', '6'] ],
			]
		);
		$this->add_control(
			'banner_image5',
			[
				'label' 		=> __( 'Banner Image 5', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'default' 		=> [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition'		=> [ 'banner_style' => ['4', '6'] ],
			]
		);
		
		$this->add_control(
			'heading',
			[
				'label' 	=> __( 'Heading', 'digalu' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default'  	=> __( 'Grow business by', 'digalu' ),
                'condition'		=> [ 'banner_style' => ['1','3','5'] ],
			]
        );
        $this->add_control(
			'title',
			[
				'label' 	=> __( 'Title', 'digalu' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default'  	=> __( 'Award winning digital marketing agency ', 'digalu' )
			]
        );
        $this->add_control(
			'desc',
			[
				'label' 	=> __( 'Description', 'digalu' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default'  	=> __( 'Dissuade ecstatic and properly saw entirely sir why laughter endeavor. In on my jointure horrible margaret suitable he followed speedily. Indeed vanity excuse or mr lovers of on. By offer scale an stuff. Blush be sorry no sight sang lose.', 'digalu' ),
                'condition'		=> [ 'banner_style' => ['1', '2','4','5','6'] ],
			]
        );

        $this->add_control(
			'button_text',
			[
				'label' 	=> __( 'Button Text', 'digalu' ),
                'type' 		=> Controls_Manager::TEXT,
                'default'  	=> __( 'Button Text', 'digalu' ),
			]
        );

        $this->add_control(
			'button_link',
			[
				'label' 		=> __( 'Link', 'digalu' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __( 'https://your-link.com', 'digalu' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
			]
		);

		$this->add_control(
			'button_text2',
			[
				'label' 	=> __( '2nd Button Text', 'digalu' ),
                'type' 		=> Controls_Manager::TEXT,
                'default'  	=> __( 'Button Text', 'digalu' ),
                'condition'		=> [ 'banner_style' => '1' ],
			]
        );

        $this->add_control(
			'button_link2',
			[
				'label' 		=> __( '2nd Button Link', 'digalu' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __( 'https://your-link.com', 'digalu' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
				'condition'		=> [ 'banner_style' => '1' ],
			]
		);
		

        $this->end_controls_section();

        //---------------------------------------Descriptions Style---------------------------------------//

		$this->start_controls_section(
			'basic_style',
			[
				'label' 	=> __( 'Basic Style', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
				'condition'		=> [ 'banner_style' => [ '1' ] ],
			]
		);
		$this->add_control(
			'from_color',
			[
				'label' 		=> __( 'Gradient Color From', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .bg-gradient' => '--color-primary: {{VALUE}};',
                ],
			]
        );
        $this->add_control(
			'to_color',
			[
				'label' 		=> __( 'Gradient Color To', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .bg-gradient' => '--color-optional-secondary: {{VALUE}};',
					'{{WRAPPER}} .bg-gradient' => '--color-secondary: {{VALUE}};',
                ],
			]
        );

		$this->end_controls_section();

        //---------------------------------------Title Style---------------------------------------//

		$this->start_controls_section(
			'title_style',
			[
				'label' 	=> __( 'Title Style', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' 		=> __( 'Title Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} h2' => 'color: {{VALUE}}',
                ],
			]
        );
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'title_typography',
				'label' 	=> __( 'Title Typography', 'digalu' ),
                'selector' 	=> '{{WRAPPER}} h2',
			]
        );
        $this->add_responsive_control(
			'title_margin',
			[
				'label' 		=> __( 'Title Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
        );

        $this->add_responsive_control(
			'title_padding',
			[
				'label' 		=> __( 'Title Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);
		$this->end_controls_section();

		//---------------------------------------subTitle Style---------------------------------------//

		$this->start_controls_section(
			'subtitle_style',
			[
				'label' 	=> __( 'Subtitle Style', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
				'condition'		=> [ 'banner_style' => [ '1','3' ] ],
			]
		);
		$this->add_control(
			'subtitle_color',
			[
				'label' 		=> __( 'Subtitle Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} h4' => 'color: {{VALUE}}',
                ],
			]
        );
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'subtitle_typography',
				'label' 	=> __( 'Subtitle Typography', 'digalu' ),
                'selector' 	=> '{{WRAPPER}} h4',
			]
        );
        $this->add_responsive_control(
			'subtitle_margin',
			[
				'label' 		=> __( 'Subtitle Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
        );

        $this->add_responsive_control(
			'subtitle_padding',
			[
				'label' 		=> __( 'Subtitle Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} h4' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);
		$this->end_controls_section();

		//---------------------------------------Descriptions Style---------------------------------------//

		$this->start_controls_section(
			'desc_style',
			[
				'label' 	=> __( 'Descriptions Style', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
				'condition'		=> [ 'banner_style!' => [ '3' ] ],
			]
		);
		$this->add_control(
			'desc_color',
			[
				'label' 		=> __( 'Descriptions Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} p' => 'color: {{VALUE}}',
                ],
			]
        );
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'desc_typography',
				'label' 	=> __( 'Descriptions Typography', 'digalu' ),
                'selector' 	=> '{{WRAPPER}} p',
			]
        );
        $this->add_responsive_control(
			'desc_margin',
			[
				'label' 		=> __( 'Descriptions Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .banner_btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
        );

        $this->add_responsive_control(
			'desc_padding',
			[
				'label' 		=> __( 'Descriptions Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .banner_btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);
		$this->end_controls_section();

		//---------------------------------------Button Style---------------------------------------//

		$this->start_controls_section(
			'button_style_section',
			[
				'label' 	=> __( 'Button Style 1', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
				'condition'		=> [ 'banner_style' => [ '1' ] ],
			]
        );

        $this->add_control(
			'button_color',
			[
				'label' 		=> __( 'Text Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .btn.btn-theme.secondary' => '--white: {{VALUE}}',
                ],
			]
        );

        $this->add_control(
			'button_color_hover',
			[
				'label' 		=> __( 'Text Color Hover', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .text-light .btn.btn-theme.secondary:hover' => '--color-heading: {{VALUE}}!important;',
                ],
			]
        );

        $this->add_control(
			'button_bg_color',
			[
				'label' 		=> __( 'Background Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .text-light .btn.btn-theme.secondary' => '--color-optional:{{VALUE}}',
                ],
			]
        );

        $this->add_control(
			'button_bg_hover_color',
			[
				'label' 		=> __( 'Background Hover Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .text-light .btn.btn-theme.secondary::after' => '--white:{{VALUE}}',
                ],
			]
        );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'border',
				'label' 	=> __( 'Border', 'digalu' ),
                'selector' 	=> '{{WRAPPER}} .btn.btn-light.effect',
			]
		);

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'border_hover',
				'label' 	=> __( 'Border Hover', 'digalu' ),
                'selector' 	=> '{{WRAPPER}} .btn.btn-light.effect:hover',
			]
		);

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'button_typography',
				'label' 	=> __( 'Button Typography', 'digalu' ),
                'selector' 	=> '{{WRAPPER}} .btn.btn-light.effect',
			]
        );

        $this->add_responsive_control(
			'button_margin',
			[
				'label' 		=> __( 'Button Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .btn.btn-light.effect' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
        );

        $this->add_responsive_control(
			'button_padding',
			[
				'label' 		=> __( 'Button Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .btn.btn-light.effect' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);
        $this->add_responsive_control(
			'button_border_radius',
			[
				'label' 		=> __( 'Button Border Radius', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .btn.btn-light.effect' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_shadow',
				'label' => esc_html__( 'Button Shadow', 'digalu' ),
				'selector' => '{{WRAPPER}} .btn.btn-light.effect',
			]
		);
        $this->end_controls_section();

		//-------------------------------video button styling------------------------------- //

		$this->start_controls_section(
			'video_btn_style_section',
			[
				'label' 	=> __( 'Video Button Style', 'appku' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
				'condition'		=> [ 'banner_style' => [ '3' ] ],
			]
		);

		$this->add_control(
			'video_btn_color',
			[
				'label' 	=> __( 'Video Button Color', 'appku' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .video-play-button i' => '--color-primary: {{VALUE}}',
                ]
			]
        );


		$this->add_control(
			'video_btn_background_color',
			[
				'label' 	=> __( 'Video Button Background Color', 'appku' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .video-play-button.with-text.optional .effect' => '--white: {{VALUE}}!important;',
                ]
			]
		);

		$this->add_control(
			'video_btn_ripple_effect_color',
			[
				'label' 		=> __( 'Video Button Ripple Effect Color', 'appku' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .video-play-button.with-text.optional .effect::after' => '--white: {{VALUE}}!important;',
                ]
			]
        );

		$this->end_controls_section();

		// //-------------------------------Background styling------------------------------- //

		// $this->start_controls_section(
		// 	'bg_style_section',
		// 	[
		// 		'label' 	=> __( 'Background Style', 'appku' ),
		// 		'tab' 		=> Controls_Manager::TAB_STYLE,
		// 		'condition'		=> [ 'banner_style' => [ '1' ] ],
		// 	]
		// );

		// $this->add_control(
		// 	'banner_bg_color1',
		// 	[
		// 		'label' 		=> __( 'Background Color From', 'digalu' ),
		// 		'type' 			=> Controls_Manager::COLOR,
		// 	]
  //       );
  //       $this->add_control(
		// 	'banner_bg_color2',
		// 	[
		// 		'label' 		=> __( 'Background Color To', 'digalu' ),
		// 		'type' 			=> Controls_Manager::COLOR,
		// 		'selectors' 	=> [
		// 			'{{WRAPPER}} .bg-gradient' => 'background-image: -webkit-linear-gradient(30deg,{{button_bg_color1.VALUE}} 20%,{{VALUE}} 50%);',
  //               ],
		// 	]
  //       );
  //       $this->end_controls_section();
    }

	protected function render() {

        $settings = $this->get_settings_for_display();

		if( $settings['banner_style'] == '1' ){
			echo '<div class="banner-style-one-area overflow-hidden bg-gradient text-light">';
				echo '<!-- Single Item -->';
				echo '<div class="banner-style-one">';
					echo '<div class="container">';
						echo '<div class="content">';
							echo '<div class="row align-center">';
								echo '<div class="col-xl-6 col-lg-6">';
									echo '<div class="info pr-35 pr-xs-0 pr-md-0">';
										if(!empty($settings['heading'])){
											echo '<h4>'.esc_html($settings['heading']).'</h4>';
										}
										if(!empty($settings['title'])){
											echo '<h2>'.esc_html($settings['title']).'</h2>';
										}
										if(!empty($settings['desc'])){
											echo '<p>'.esc_html($settings['desc']).'</p>';
										}
										echo '<div class="button">';
											if( ! empty( $settings['button_text'] ) ) {
						                    	if( ! empty( $settings['button_link']['url'] ) ) {
										            $this->add_render_attribute( 'button', 'href', esc_url( $settings['button_link']['url'] ) );
										        }
							            		if( ! empty( $settings['button_link']['nofollow'] ) ) {
										            $this->add_render_attribute( 'button', 'rel', 'nofollow' );
										        }
										        if( ! empty( $settings['button_link']['is_external'] ) ) {
										            $this->add_render_attribute( 'button', 'target', '_blank' );
										        }
										        $this->add_render_attribute( 'button', 'class', 'btn btn-md btn-theme animation' );

						                        echo '<a '.$this->get_render_attribute_string('button').'>'.esc_html( $settings['button_text'] ).'</a>';
						                    }
						                    if( ! empty( $settings['button_text2'] ) ) {
						                    	if( ! empty( $settings['button_link2']['url'] ) ) {
										            $this->add_render_attribute( 'button2', 'href', esc_url( $settings['button_link2']['url'] ) );
										        }
							            		if( ! empty( $settings['button_link2']['nofollow'] ) ) {
										            $this->add_render_attribute( 'button2', 'rel', 'nofollow' );
										        }
										        if( ! empty( $settings['button_link2']['is_external'] ) ) {
										            $this->add_render_attribute( 'button2', 'target', '_blank' );
										        }
										        $this->add_render_attribute( 'button2', 'class', 'btn-regular' );

						                        echo '<a '.$this->get_render_attribute_string('button2').'>'.esc_html( $settings['button_text2'] ).'</a>';
						                    }
										echo '</div>';
									echo '</div>';
								echo '</div>';
								if( ! empty( $settings['banner_image']['url'] ) ){
									echo '<div class="col-xl-6 col-lg-6">';
										echo '<div class="thumb">';
											echo digalu_img_tag( array(
												'url'	=> esc_url( $settings['banner_image']['url'] )
											) );
										echo '</div>';
									echo '</div>';
								}
							echo '</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="shape-bottom-center" style="background-image: url('.DIGALU_PLUGDIRURI . 'assets/img/5.png);"></div>';
					echo '<div class="shape-top-right" style="background-image: url('.DIGALU_PLUGDIRURI . 'assets/img/6.png);"></div>';
					echo '<div class="shape-left-top" style="background-image: url('.DIGALU_PLUGDIRURI . 'assets/img/10.png);"></div>';
				echo '</div>';
				echo '<!-- End Single Item -->';
			echo '</div>';
		}elseif( $settings['banner_style'] == '3' ){
			if( ! empty( $settings['banner_image2']['url'] ) ){
				echo '<div class="banner-style-three-area text-center bg-cover text-light" style="background-image: url('.esc_url( $settings['banner_image2']['url'] ).');">';
			}
				echo '<div class="animate-shape">';
					echo '<img src="'.DIGALU_PLUGDIRURI . 'assets/img/cloud.png" alt="Image not found">';
					echo '<img src="'.DIGALU_PLUGDIRURI . 'assets/img/cloud2.png" alt="Image not found">';
				echo '</div>';
				echo '<!-- Single Item -->';
				echo '<div class="banner-style-three">';
					echo '<div class="container">';
						echo '<div class="content">';
							echo '<div class="row">';
								echo '<div class="col-lg-8 offset-lg-2">';
									echo '<div class="info">';
										if(!empty($settings['heading'])){
											echo '<h4>'.esc_html($settings['heading']).'</h4>';
										}
										if(!empty($settings['title'])){
											echo '<h2>'.esc_html($settings['title']).'</h2>';
										}
										if( ! empty( $settings['button_text'] ) ) {
											if( ! empty( $settings['button_link']['url'] ) ) {
										            $this->add_render_attribute( 'button', 'href', esc_url( $settings['button_link']['url'] ) );
										        }
							            		if( ! empty( $settings['button_link']['nofollow'] ) ) {
										            $this->add_render_attribute( 'button', 'rel', 'nofollow' );
										        }
										        if( ! empty( $settings['button_link']['is_external'] ) ) {
										            $this->add_render_attribute( 'button', 'target', '_blank' );
										        }
										        $this->add_render_attribute( 'button', 'class', 'popup-youtube video-play-button optional light with-text' );

											echo '<div class="button mt-40">';
												echo '<a '.$this->get_render_attribute_string('button').'>';
													echo '<div class="effect"></div>';
													echo '<span><i class="fas fa-play"></i> '.esc_html( $settings['button_text'] ).'</span>';
												echo '</a>';
											echo '</div>';
										}
									echo '</div>';
								echo '</div>';
								echo '<div class="col-lg-8 offset-lg-2">';
									if( ! empty( $settings['banner_image']['url'] ) ){
										echo '<div class="thumb">';
											echo digalu_img_tag( array(
												'url'	=> esc_url( $settings['banner_image']['url'] )
											) );
										echo '</div>';
									}
								echo '</div>';
								
							echo '</div>';
						echo '</div>';
					echo '</div>';
					echo '<div class="shape-bottom-center" style="background-image: url('.DIGALU_PLUGDIRURI . 'assets/img/5.png);"></div>';
					echo '<div class="shape-top-right" style="background-image: url('.DIGALU_PLUGDIRURI . 'assets/img/6.png);"></div>';
					echo '<div class="shape-left-top" style="background-image: url('.DIGALU_PLUGDIRURI . 'assets/img/7.png);"></div>';
				echo '</div>';
				echo '<!-- End Single Item -->';
			echo '</div>';
		}elseif( $settings['banner_style'] == '2' ){
			echo '<div class="banner-style-two-area overflow-hidden">';
		        echo '<!-- Single Item -->';
		        echo '<div class="banner-style-two">';
		            echo '<div class="container">';
		                echo '<div class="content">';
		                    echo '<div class="row align-center">';
		                        echo '<div class="col-xl-6 col-lg-6">';
		                            echo '<div class="info pr-35 pr-xs-0 pr-md-0">';

		                                if(!empty($settings['title'])){
											echo '<h2>'.wp_kses_post($settings['title']).'</h2>';
										}

		                                if(!empty($settings['desc'])){
											echo '<p>'.esc_html($settings['desc']).'</p>';
										}  
	                                	if( ! empty( $settings['button_text'] ) ) {
	                                		echo '<div class="button">';
						                    	if( ! empty( $settings['button_link']['url'] ) ) {
										            $this->add_render_attribute( 'button', 'href', esc_url( $settings['button_link']['url'] ) );
										        }
							            		if( ! empty( $settings['button_link']['nofollow'] ) ) {
										            $this->add_render_attribute( 'button', 'rel', 'nofollow' );
										        }
										        if( ! empty( $settings['button_link']['is_external'] ) ) {
										            $this->add_render_attribute( 'button', 'target', '_blank' );
										        }
										        $this->add_render_attribute( 'button', 'class', 'btn btn-md btn-gradient secondary animation' );

						                        echo '<a '.$this->get_render_attribute_string('button').'>'.esc_html( $settings['button_text'] ).'</a>';
					                        echo '</div>';
					                    } 
		                            echo '</div>';
		                        echo '</div>';

		                        echo '<div class="col-xl-6 col-lg-6">';
		                            echo '<div class="thumb">';

										if( ! empty( $settings['banner_image']['url'] ) ){
			                                echo digalu_img_tag( array(
												'url'	=> esc_url( $settings['banner_image']['url'] )
											) );
			                            }
			                            if( ! empty( $settings['banner_image2']['url'] ) ){
			                                echo '<div class="social">';
			                                    echo digalu_img_tag( array(
													'url'	=> esc_url( $settings['banner_image2']['url'] )
												) );
			                                echo '</div>';
			                            }
		                            echo '</div>';
		                        echo '</div>';
		                        
		                    echo '</div>';
		                echo '</div>';
		            echo '</div>';
		            if( ! empty( $settings['banner_image3']['url'] ) ){
			            echo '<div class="shape-bottom-center" style="background-image: url('.esc_url( $settings['banner_image3']['url'] ).');"></div>';
			        }
		        echo '</div>';
		        echo '<!-- End Single Item -->';
		    echo '</div>';
		}elseif( $settings['banner_style'] == '4' ){
			if( ! empty( $settings['banner_image']['url'] ) ){
				echo '<div class="banner-style-four-area bg-fixed" style="background-image: url('.esc_url( $settings['banner_image']['url'] ).');">';
			}else{
				echo '<div class="banner-style-four-area bg-fixed">';
			}

		        echo '<!-- Single Item -->';
		        echo '<div class="banner-style-four">';
		            echo '<div class="container">';
		                echo '<div class="content">';
		                    echo '<div class="row align-center">';
		                        echo '<div class="col-xl-6 col-lg-7">';
		                            echo '<div class="info pr-35 pr-xs-0 pr-md-0">';
		                                if(!empty($settings['title'])){
											echo '<h2>'.wp_kses_post($settings['title']).'</h2>';
										}

		                                if(!empty($settings['desc'])){
											echo '<p>'.esc_html($settings['desc']).'</p>';
										}
										if( ! empty( $settings['button_text'] ) ) {
	                                		echo '<div class="button mt-35">';
						                    	if( ! empty( $settings['button_link']['url'] ) ) {
										            $this->add_render_attribute( 'button', 'href', esc_url( $settings['button_link']['url'] ) );
										        }
							            		if( ! empty( $settings['button_link']['nofollow'] ) ) {
										            $this->add_render_attribute( 'button', 'rel', 'nofollow' );
										        }
										        if( ! empty( $settings['button_link']['is_external'] ) ) {
										            $this->add_render_attribute( 'button', 'target', '_blank' );
										        }
										        $this->add_render_attribute( 'button', 'class', 'btn btn-md circle btn-gradient animation' );

						                        echo '<a '.$this->get_render_attribute_string('button').'>'.esc_html( $settings['button_text'] ).'</a>';
					                        echo '</div>';
					                    } 
		                            echo '</div>';
		                        echo '</div>';

		                        echo '<div class="col-xl-6 col-lg-5 pl-60 pl-md-15 pl-xs-15">';
		                            echo '<div class="thumb">';
		                            	if( ! empty( $settings['banner_image2']['url'] ) ){
			                                echo '<img src="'.esc_url( $settings['banner_image2']['url'] ).'" alt="Thumb">';
			                            }
		                                echo '<div class="thumb-sub">';
		                                	if( ! empty( $settings['banner_image3']['url'] ) ){
			                                    echo '<img class="wow fadeInLeft" data-wow-delay="800ms" src="'.esc_url( $settings['banner_image3']['url'] ).'" alt="Image not found">';
			                                }
			                                if( ! empty( $settings['banner_image4']['url'] ) ){
			                                    echo '<img class="wow fadeInRight" data-wow-delay="1200ms" src="'.esc_url( $settings['banner_image4']['url'] ).'" alt="Image not found">';
			                                }
			                                if( ! empty( $settings['banner_image5']['url'] ) ){
			                                    echo '<img class="wow fadeInDown" data-wow-delay="1500ms" src="'.esc_url( $settings['banner_image5']['url'] ).'" alt="Image not found">';
			                                }
		                                echo '</div>';
		                            echo '</div>';
		                        echo '</div>';
		                        
		                    echo '</div>';
		                echo '</div>';
		            echo '</div>';
		        echo '</div>';
		        echo '<!-- End Single Item -->';
		    echo '</div>';
		}elseif( $settings['banner_style'] == '5' ){
			echo '<div class="banner-style-two-area text-light overflow-hidden">';

		        echo '<!-- Single Item -->';
		        echo '<div class="banner-style-two">';
		            echo '<div class="container">';
		                echo '<div class="content">';
		                    echo '<div class="row align-center">';
		                        echo '<div class="col-xl-6 col-lg-6">';
		                            echo '<div class="info pr-35 pr-xs-0 pr-md-0">';
		                                if(!empty($settings['heading'])){
											echo '<h4>'.wp_kses_post($settings['heading']).'</h4>';
										}
										if(!empty($settings['title'])){
											echo '<h2>'.wp_kses_post($settings['title']).'</h2>';
										}

		                                if(!empty($settings['desc'])){
											echo '<p>'.esc_html($settings['desc']).'</p>';
										} 


										if( ! empty( $settings['button_text'] ) ) {
	                                		echo '<div class="button">';
						                    	if( ! empty( $settings['button_link']['url'] ) ) {
										            $this->add_render_attribute( 'button', 'href', esc_url( $settings['button_link']['url'] ) );
										        }
							            		if( ! empty( $settings['button_link']['nofollow'] ) ) {
										            $this->add_render_attribute( 'button', 'rel', 'nofollow' );
										        }
										        if( ! empty( $settings['button_link']['is_external'] ) ) {
										            $this->add_render_attribute( 'button', 'target', '_blank' );
										        }
										        $this->add_render_attribute( 'button', 'class', 'btn btn-md btn-theme animation' );

						                        echo '<a '.$this->get_render_attribute_string('button').'>'.esc_html( $settings['button_text'] ).'</a>';
					                        echo '</div>';
					                    } 
		                            echo '</div>';
		                        echo '</div>';
		                        if( ! empty( $settings['banner_image']['url'] ) ){
			                        echo '<div class="col-xl-6 col-lg-6">';
			                            echo '<div class="thumb">';
			                                echo digalu_img_tag( array(
												'url'	=> esc_url( $settings['banner_image']['url'] )
											) );
			                            echo '</div>';
			                        echo '</div>';
			                    }
		                        
		                    echo '</div>';
		                echo '</div>';
		            echo '</div>';
		            if( ! empty( $settings['banner_image2']['url'] ) ){
			            echo '<div class="shape-bottom-center" style="background-image: url('.esc_url( $settings['banner_image2']['url'] ).');"></div>';
			        }
		        echo '</div>';
		        echo '<!-- End Single Item -->';
		    echo '</div>';
		}else{

			if( ! empty( $settings['banner_image']['url'] ) ){
				echo '<div class="banner-style-five-area bg-cover" style="background-image: url('.esc_url( $settings['banner_image']['url'] ).');">';
			}else{
				echo '<div class="banner-style-five-area bg-cover" style="background-image: url();">';
			}
		        echo '<!-- Single Item -->';
		        echo '<div class="banner-style-five">';
		            echo '<div class="container">';
		                echo '<div class="content">';
		                    echo '<div class="row align-center">';
		                        echo '<div class="col-xl-6 col-lg-7">';
		                            echo '<div class="info pr-35 pr-xs-0 pr-md-0">';
		                                if(!empty($settings['title'])){
											echo '<h2>'.wp_kses_post($settings['title']).'</h2>';
										}

		                                if(!empty($settings['desc'])){
											echo '<p>'.esc_html($settings['desc']).'</p>';
										} 
		                                
		                                if( ! empty( $settings['button_text'] ) ) {
	                                		echo '<div class="button mt-30">';
						                    	if( ! empty( $settings['button_link']['url'] ) ) {
										            $this->add_render_attribute( 'button', 'href', esc_url( $settings['button_link']['url'] ) );
										        }
							            		if( ! empty( $settings['button_link']['nofollow'] ) ) {
										            $this->add_render_attribute( 'button', 'rel', 'nofollow' );
										        }
										        if( ! empty( $settings['button_link']['is_external'] ) ) {
										            $this->add_render_attribute( 'button', 'target', '_blank' );
										        }
										        $this->add_render_attribute( 'button', 'class', 'btn btn-md btn-gradient animation' );

						                        echo '<a '.$this->get_render_attribute_string('button').'>'.esc_html( $settings['button_text'] ).'</a>';
					                        echo '</div>';
					                    }
		                            echo '</div>';
		                        echo '</div>';

		                        echo '<div class="col-xl-6 col-lg-5 pl-60 pl-md-15 pl-xs-15 mt-md-80">';
		                            echo '<div class="banner-style-five-thumb">';
		                                if( ! empty( $settings['banner_image2']['url'] ) ){
			                        
										    echo digalu_img_tag( array(
												'url'	=> esc_url( $settings['banner_image2']['url'] )
											) );
										        
										}
										if( ! empty( $settings['banner_image3']['url'] ) ){
			                        
										    echo digalu_img_tag( array(
												'url'	=> esc_url( $settings['banner_image3']['url'] )
											) );
										        
										}
										if( ! empty( $settings['banner_image4']['url'] ) ){
			                        
										    echo digalu_img_tag( array(
												'url'	=> esc_url( $settings['banner_image4']['url'] )
											) );
										        
										}
										if( ! empty( $settings['banner_image5']['url'] ) ){
			                        		echo '<div class="shape">';
											    echo digalu_img_tag( array(
													'url'	=> esc_url( $settings['banner_image5']['url'] )
												) );
											echo '</div>';
										        
										}
		                            echo '</div>';
		                        echo '</div>';
		                        
		                    echo '</div>';
		                echo '</div>';
		            echo '</div>';
		        echo '</div>';
		        echo '<!-- End Single Item -->';
		    echo '</div>';
		}
	}
}