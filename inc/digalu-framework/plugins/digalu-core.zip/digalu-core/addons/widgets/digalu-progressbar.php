<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * circle progressbar Widget .
 *
 */
class Digalu_Progressbar extends Widget_Base {

	public function get_name() {
		return 'digalupprogressbar2';
	}

	public function get_title() {
		return __( 'Digalu Progressbar', 'digalu' );
	}


	public function get_icon() {
		return 'vt-icon';
    }


	public function get_categories() {
		return [ 'digalu' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'progressbar_section',
			[
				'label' 	=> __( 'Progressbar', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'section_title',
			[
				'label' 	=> __( 'Title', 'digalu' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'default'  	=> __( 'Section Title', 'digalu' ),
			]
        );
        $this->add_control(
			'section_subtitle',
			[
				'label' 	=> __( 'Subitle', 'digalu' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'default'  	=> __( 'Section Subitle', 'digalu' ),
			]
        );

        
        $repeater = new Repeater();

        $repeater->add_control(
			's_progressbar_text',
			[
				'label'     => __( 'Progressbar Text', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default' 		=> __('Business Growth','digalu'),
			]
        );
        $repeater->add_control(
			's_progressbar_number',
			[
				'label'     => __( 'Progressbar Number', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default' 		=> __('50','digalu'),
			]
        );

        $this->add_control(
			'progressbars',
			[
				'label' 		=> __( 'Progressbar', 'digalu' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'progressbar_text' 		=> __( 'title', 'digalu' ),
					],
				],
				'title_field' 	=> '{{{ s_progressbar_text }}}',
			]
		);
        $this->end_controls_section();

        $this->start_controls_section(
			'service_section',
			[
				'label' 	=> __( 'Service', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );
        $repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'     => __( 'Title', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
			]
        );
        $repeater->add_control(
			'content',
			[
				'label'     => __( 'Content', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 4,
			]
        );
        $repeater->add_control(
			'url',
			[
				'label'     => __( 'Details Page', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
			]
        );
        $repeater->add_control(
			'icon',
			[
				'label'     => __( 'Icon', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
			]
        );
        $this->add_control(
			'services_1',
			[
				'label' 		=> __( 'Services', 'digalu' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 		=> __( 'Marketing Strategy', 'digalu' ),
					],
				],
				'title_field' 	=> '{{{ title }}}',
			]
		);


        
        $this->end_controls_section();

		
		
	}

	protected function render() {

        $settings = $this->get_settings_for_display();


        echo '<div class="container mb-60 mb-md-40 mb-xs-30">';
            echo '<div class="row">';
                echo '<div class="col-lg-5 info">';
                	if( ! empty( $settings['section_title'] ) ){
                        echo '<h4 class="sub-title">' .esc_html( $settings['section_title'] ). '</h4>';
                    }
                    if( ! empty( $settings['section_subtitle'] ) ){
                        echo '<h2 class="title">' .esc_html( $settings['section_subtitle'] ). '</h2>';
                    }
                echo '</div>';
                echo '<div class="col-lg-6 offset-lg-1 right-info">';
                    echo '<div class="skill-items style-two">';
                        foreach( $settings['progressbars'] as $single_data ) { 
	                        echo '<!-- Progress Bar Start -->';
	                        echo '<div class="progress-box">';
	                            if(!empty($single_data['s_progressbar_text'])){
					                echo '<h5>'.esc_html($single_data['s_progressbar_text']).'</h5>';
					            }
					            if(!empty($single_data['s_progressbar_number'])){
		                           	echo '<div class="progress">';
		                                echo '<div class="progress-bar" role="progressbar" data-width="'.esc_attr($single_data['s_progressbar_number']).'"><span>'.esc_html($single_data['s_progressbar_number']).'%</span></div>';
		                            echo '</div>';
		                        }
	                        echo '</div>';
	                    }
                       
                    echo '</div>';
                echo '</div>';
            echo '</div>';
        echo '</div>';

        echo '<div class="container">';
            echo '<div class="expertise-items">';
                echo '<div class="row">';
                    foreach( $settings['services_1'] as $data ) {  
	                    echo '<!-- Single Itme -->';
	                    echo '<div class="col-lg-4 col-md-6 mb-30">';
	                        echo '<div class="expertise-item">';
	                            echo '<div class="content">';
	                                if( ! empty( $data['title'] ) ){
				                        echo '<h4>'.esc_html( $data['title'] ).'</h4>';
				                    }
			                        if( ! empty( $data['content'] ) ){
				                        echo '<p>'.esc_html( $data['content'] ).'</p>';
				                    }
	                            echo '</div>';
	                            echo '<div class="bottom">';
	                                if( ! empty( $data['icon'] ) ){
				                        echo wp_kses_post( $data['icon'] );
				                    }
	                                echo '<a href="'.esc_url( $data['url'] ).'"><i class="fas fa-arrow-right"></i></a>';
	                            echo '</div>';
	                        echo '</div>';
	                    echo '</div>';
	                    echo '<!-- End Single Itme -->';
	                } 
                echo '</div>';
            echo '</div>';
        echo '</div>';
	}

}