<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
/**
 *
 * Button Widget .
 *
 */
class Digalu_Button extends Widget_Base {

	public function get_name() {
		return 'digalubutton';
	}

	public function get_title() {
		return __( 'Button', 'digalu' );
	}

	public function get_icon() {
		return 'vt-icon';
    }

	public function get_categories() {
		return [ 'digalu' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'button_section',
			[
				'label' 	=> __( 'Button', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

		$this->add_control(
			'button_style',
			[
				'label' 	=> __( 'Button Style', 'digalu' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '1',
				'options' 	=> [
					'1'  		=> __( 'Style One', 'digalu' ),
					'2' 		=> __( 'Style Two', 'digalu' ),
				],
			]
		);

        $this->add_control(
			'button_text',
			[
				'label' 	=> __( 'Button Text', 'digalu' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'default'  	=> __( 'Button Text', 'digalu' )
			]
        );

        $this->add_control(
			'button_link',
			[
				'label' 		=> __( 'Link', 'digalu' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __( 'https://your-link.com', 'digalu' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
			]
		);

		$this->add_control(
			'show_arrow_icon',
			[
				'label' 		=> __( 'Show Arrow Icon?', 'digalu' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Show', 'digalu' ),
				'label_off' 	=> __( 'Hide', 'digalu' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);
		$this->add_control(
			'icon_class',
			[
				'label' 	=> __( 'Icon ', 'digalu' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'default'  	=> __( '<i class="far fa-long-arrow-right"></i>', 'digalu' ),
                'condition'		=> [ 'show_arrow_icon' => [ 'yes' ] ],
			]
        );

        $this->add_responsive_control(
			'button_align',
			[
				'label' 		=> __( 'Alignment', 'digalu' ),
				'type' 			=> Controls_Manager::CHOOSE,
				'options' 		=> [
					'left' 			=> [
						'title' 		=> __( 'Left', 'digalu' ),
						'icon' 			=> 'fa fa-align-left',
					],
					'center' 		=> [
						'title' 		=> __( 'Center', 'digalu' ),
						'icon' 			=> 'fa fa-align-center',
					],
						'right' 	=> [
						'title' 		=> __( 'Right', 'digalu' ),
						'icon' 			=> 'fa fa-align-right',
					],
				],
				'default' 		=> 'left',
				'toggle' 		=> true,
				'selectors' 	=> [
					'{{WRAPPER}} .btn-wrapper' => 'text-align: {{VALUE}}',
                ],
			]
        );

        $this->end_controls_section();

        $this->start_controls_section(
			'button_style_section',
			[
				'label' 	=> __( 'Button Style', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,

			]
        );

        $this->add_control(
			'button_color',
			[
				'label' 		=> __( 'Button Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .vs-btn' => 'color: {{VALUE}}',
					'{{WRAPPER}} .banner_btn' => 'color: {{VALUE}}',
                ],
                'condition'		=> [ 'button_style' => [ '1' ] ],
			]
        );

        $this->add_control(
			'button_color_hover',
			[
				'label' 		=> __( 'Button Color Hover', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .vs-btn:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .banner_btn:hover' => 'color: {{VALUE}}',
                ],
                'condition'		=> [ 'button_style' => [ '1' ] ],
			]
        );

        $this->add_control(
			'button_bg_color',
			[
				'label' 		=> __( 'Button Background Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .vs-btn .btn-bg,{{WRAPPER}} .vs-btn,{{WRAPPER}} .banner_btn' => 'background-color:{{VALUE}}',
                ],
                'condition'		=> [ 'button_style' => [ '1' ] ],
			]
        );

        $this->add_control(
			'button_bg_hover_color',
			[
				'label' 		=> __( 'Button Background Hover Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .vs-btn' => '--dark:{{VALUE}}',
                ],
                'condition'		=> [ 'button_style' => [ '1' ] ],
			]
        );
   //      $this->add_control(
			// 'button_bg_color1',
			// [
			// 	'label' 		=> __( 'Background Color From', 'digalu' ),
			// 	'type' 			=> Controls_Manager::COLOR,
			// 	'condition'		=> [ 'button_style' => [ '2' ] ],
			// ]
   //      );
   //      $this->add_control(
			// 'button_bg_color2',
			// [
			// 	'label' 		=> __( 'Background Color To', 'digalu' ),
			// 	'type' 			=> Controls_Manager::COLOR,
			// 	'selectors' 	=> [
			// 		'{{WRAPPER}} .button a::after' => '--bg-gradient: -webkit-linear-gradient(30deg,{{button_bg_color1.VALUE}} 20%,{{VALUE}} 50%);',

   //              ],
   //              'condition'		=> [ 'button_style' => [ '2' ] ],
			// ]
   //      );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'border',
				'label' 	=> __( 'Border', 'digalu' ),
                'selector' 	=> '{{WRAPPER}} .vs-btn,{{WRAPPER}} .banner_btn',
			]
		);

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'border_hover',
				'label' 	=> __( 'Border Hover', 'digalu' ),
                'selector' 	=> '{{WRAPPER}} .vs-btn:hover',
			]
		);

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'button_typography',
				'label' 	=> __( 'Button Typography', 'digalu' ),
                'selector' 	=> '{{WRAPPER}} .vs-btn,{{WRAPPER}} .banner_btn',
			]
        );

        $this->add_responsive_control(
			'button_margin',
			[
				'label' 		=> __( 'Button Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .vs-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .banner_btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
        );

        $this->add_responsive_control(
			'button_padding',
			[
				'label' 		=> __( 'Button Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .vs-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .banner_btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);
        $this->add_responsive_control(
			'button_border_radius',
			[
				'label' 		=> __( 'Button Border Radius', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .vs-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .banner_btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);
        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        $this->add_render_attribute( 'wrapper', 'class', 'btn-wrapper' );
        $this->add_render_attribute( 'wrapper', 'class', esc_attr( $settings['button_align'] ) );

		if( $settings['button_style'] == '1' ){
	        $this->add_render_attribute( 'button', 'class', 'digalu vs-btn btn btn-md mt-20 circle btn-theme animation' );
		}else{
			$this->add_render_attribute( 'button', 'class', 'vs-btn btn btn-md btn-gradient animation' );
		}

        if( ! empty( $settings['button_link']['url'] ) ) {
            $this->add_render_attribute( 'button', 'href', esc_url( $settings['button_link']['url'] ) );
        }

        if( ! empty( $settings['button_link']['nofollow'] ) ) {
            $this->add_render_attribute( 'button', 'rel', 'nofollow' );
        }

        if( ! empty( $settings['button_link']['is_external'] ) ) {
            $this->add_render_attribute( 'button', 'target', '_blank' );
        }

        echo '<!-- Button -->';
        echo '<div '.$this->get_render_attribute_string('wrapper').'>';
            if( ! empty( $settings['button_text'] ) ) {
                echo '<a '.$this->get_render_attribute_string('button').'>';
					echo esc_html( $settings['button_text'] );
					if( $settings['show_arrow_icon'] == 'yes' ){
						if(!empty($settings['icon_class'])){
							echo wp_kses_post($settings['icon_class']);
						}
					}
					if( $settings['button_style'] == '1' ){
						echo ' ';
					}
				echo '</a>';
            }
        echo '</div>';
        echo '<!-- End Button -->';
	}
}