<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
/**
 *
 * Image Widget .
 *
 */
class Digalu_Group_Image extends Widget_Base {

	public function get_name() {
		return 'digalugroupimage';
	}

	public function get_title() {
		return __( 'Digalu Group Image', 'digalu' );
	}


	public function get_icon() {
		return 'vt-icon';
    }


	public function get_categories() {
		return [ 'digalu' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'image_section',
			[
				'label' 	=> __( 'Group Image', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'iamge_style',
			[
				'label' 	=> __( 'Group Style', 'digalu' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '1',
				'options' 	=> [
					'1'  		=> __( 'Style One', 'digalu' ),
					'2'  		=> __( 'Style Two', 'digalu' ),
					'3'  		=> __( 'Style Three', 'digalu' ),
					'4'  		=> __( 'Style Four', 'digalu' ),
					'5'  		=> __( 'Style Five', 'digalu' ),
					'6'  		=> __( 'Style Six', 'digalu' ),
					'7'  		=> __( 'Style Seven', 'digalu' ),
					'8'  		=> __( 'Style Eight', 'digalu' ),
				],
			]
		);

        $this->add_control(
			'image1',
			[
				'label' 		=> __( 'Image 1', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'image2',
			[
				'label' 		=> __( 'Image 2', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'image3',
			[
				'label' 		=> __( 'Image 3', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
				'condition'		=> [ 'iamge_style' => [ '1', '2', '3', '4' ] ],
			]
		);
		$this->add_control(
			'image4',
			[
				'label' 		=> __( 'Image 4', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
				'condition'		=> [ 'iamge_style' => [ '3','6' ] ],
			]
		);
		$this->add_control(
			'image5',
			[
				'label' 		=> __( 'Image 5', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
				'condition'		=> [ 'iamge_style' => [ '3','6' ] ],
			]
		);
		$this->add_control(
			'image6',
			[
				'label' 		=> __( 'Image 6', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
				'condition'		=> [ 'iamge_style' => [ '3' ] ],
			]
		);
		$this->add_control(
			'image7',
			[
				'label' 		=> __( 'Image 7', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
				'condition'		=> [ 'iamge_style' => [ '3' ] ],
			]
		);
		$this->add_control(
			'years',
			[
				'label' 	=> __( 'Years of experience', 'digalu' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default'  	=> __( 'Award winning', 'digalu' ),
                'condition'		=> [ 'iamge_style' => [ '8' ] ],
			]
        );
		
        $this->end_controls_section();

        /*-----------------------------------------section Content styling------------------------------------*/

		$this->start_controls_section(
			'section_con_styling',
			[
				'label' 	=> __( 'Image Effect', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
        );
        $this->start_controls_tabs(
			'style_tabs1'
		);


		$this->start_controls_tab(
			'style_normal_tab1',
			[
				'label' => esc_html__( '1st Image', 'digalu' ),
			]
		);
		$this->add_control(
			'digalu_img_animation_1',
			[
				'label' 	=> __( 'Animation', 'digalu' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'no animation',
				'options' 	=> [
					'wow fadeIn'  			=> __( 'Fade In', 'digalu' ),
					'wow fadeInLeft'  		=> __( 'Fade In Left', 'digalu' ),
					'wow fadeInDown'  		=> __( 'Fade In Down', 'digalu' ),
					'wow fadeInRight'  		=> __( 'Fade In Right', 'digalu' ),
					'wow fadeInUp'  		=> __( 'Fade In Up', 'digalu' ),
					'no animation'  		=> __( 'No Animation', 'digalu' ),
					'wow pulse'  			=> __( 'Pulse', 'digalu' ),
				],
			]
		);
		$this->add_control(
			'digalu_img_duration_1',
			[
				'label' => esc_html__( 'Duration', 'digalu' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 100,
				'max' => 1000,
				'step' => 100,
				'default' => 100,
			]
		);
        
		$this->end_controls_tab();

		//--------------------secound--------------------//

		$this->start_controls_tab(
			'style_hover_tab2',
			[
				'label' => esc_html__( '2nd Image', 'digalu' ),
			]
		);
		$this->add_control(
			'digalu_img_animation_2',
			[
				'label' 	=> __( 'Animation', 'digalu' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'no animation',
				'options' 	=> [
					'wow fadeIn'  			=> __( 'Fade In', 'digalu' ),
					'wow fadeInLeft'  		=> __( 'Fade In Left', 'digalu' ),
					'wow fadeInDown'  		=> __( 'Fade In Down', 'digalu' ),
					'wow fadeInRight'  		=> __( 'Fade In Right', 'digalu' ),
					'wow fadeInUp'  		=> __( 'Fade In Up', 'digalu' ),
					'no animation'  		=> __( 'No Animation', 'digalu' ),
					'wow pulse'  			=> __( 'Pulse', 'digalu' ),
				],
			]
		);
		$this->add_control(
			'digalu_img_duration_2',
			[
				'label' => esc_html__( 'Duration', 'digalu' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 100,
				'max' => 1000,
				'step' => 100,
				'default' => 100,
			]
		);
      
		$this->end_controls_tab();

		$this->start_controls_tab(
			'style_normal_tab4',
			[
				'label' => esc_html__( '3rd Image', 'digalu' ),
			]
		);
        $this->add_control(
			'digalu_img_animation_3',
			[
				'label' 	=> __( 'Animation', 'digalu' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'no animation',
				'options' 	=> [
					'wow fadeIn'  			=> __( 'Fade In', 'digalu' ),
					'wow fadeInLeft'  		=> __( 'Fade In Left', 'digalu' ),
					'wow fadeInDown'  		=> __( 'Fade In Down', 'digalu' ),
					'wow fadeInRight'  		=> __( 'Fade In Right', 'digalu' ),
					'wow fadeInUp'  		=> __( 'Fade In Up', 'digalu' ),
					'no animation'  		=> __( 'No Animation', 'digalu' ),
					'wow pulse'  			=> __( 'Pulse', 'digalu' ),
				],
			]
		);
		$this->add_control(
			'digalu_img_duration_3',
			[
				'label' => esc_html__( 'Duration', 'digalu' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 100,
				'max' => 1000,
				'step' => 100,
				'default' => 100,
			]
		);
        
		$this->end_controls_tab();

		//--------------------------------4--------------------------------//

		$this->start_controls_tab(
			'style_normal_tab5',
			[
				'label' => esc_html__( '4th Image', 'digalu' ),
				'condition'		=> [ 'iamge_style' => [ '3' ] ],
			]
		);
        $this->add_control(
			'digalu_img_animation_4',
			[
				'label' 	=> __( 'Animation', 'digalu' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'no animation',
				'options' 	=> [
					'wow fadeIn'  			=> __( 'Fade In', 'digalu' ),
					'wow fadeInLeft'  		=> __( 'Fade In Left', 'digalu' ),
					'wow fadeInDown'  		=> __( 'Fade In Down', 'digalu' ),
					'wow fadeInRight'  		=> __( 'Fade In Right', 'digalu' ),
					'wow fadeInUp'  		=> __( 'Fade In Up', 'digalu' ),
					'no animation'  		=> __( 'No Animation', 'digalu' ),
					'wow pulse'  			=> __( 'Pulse', 'digalu' ),
				],
			]
		);
		$this->add_control(
			'digalu_img_duration_4',
			[
				'label' => esc_html__( 'Duration', 'digalu' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 100,
				'max' => 1000,
				'step' => 100,
				'default' => 100,
			]
		);
        
		$this->end_controls_tab();

		//--------------------------------5--------------------------------//

		$this->start_controls_tab(
			'style_normal_tab6',
			[
				'label' => esc_html__( '5th Image', 'digalu' ),
				'condition'		=> [ 'iamge_style' => [ '3' ] ],
			]
		);
        $this->add_control(
			'digalu_img_animation_5',
			[
				'label' 	=> __( 'Animation', 'digalu' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'no animation',
				'options' 	=> [
					'wow fadeIn'  			=> __( 'Fade In', 'digalu' ),
					'wow fadeInLeft'  		=> __( 'Fade In Left', 'digalu' ),
					'wow fadeInDown'  		=> __( 'Fade In Down', 'digalu' ),
					'wow fadeInRight'  		=> __( 'Fade In Right', 'digalu' ),
					'wow fadeInUp'  		=> __( 'Fade In Up', 'digalu' ),
					'no animation'  		=> __( 'No Animation', 'digalu' ),
					'wow pulse'  			=> __( 'Pulse', 'digalu' ),
				],
			]
		);
		$this->add_control(
			'digalu_img_duration_5',
			[
				'label' => esc_html__( 'Duration', 'digalu' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 100,
				'max' => 1000,
				'step' => 100,
				'default' => 100,
			]
		);
        
		$this->end_controls_tab();

		//--------------------------------6--------------------------------//

		$this->start_controls_tab(
			'style_normal_tab7',
			[
				'label' => esc_html__( '6th Image', 'digalu' ),
				'condition'		=> [ 'iamge_style' => [ '3' ] ],
			]
		);
        $this->add_control(
			'digalu_img_animation_6',
			[
				'label' 	=> __( 'Animation', 'digalu' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'no animation',
				'options' 	=> [
					'wow fadeIn'  			=> __( 'Fade In', 'digalu' ),
					'wow fadeInLeft'  		=> __( 'Fade In Left', 'digalu' ),
					'wow fadeInDown'  		=> __( 'Fade In Down', 'digalu' ),
					'wow fadeInRight'  		=> __( 'Fade In Right', 'digalu' ),
					'wow fadeInUp'  		=> __( 'Fade In Up', 'digalu' ),
					'no animation'  		=> __( 'No Animation', 'digalu' ),
					'wow pulse'  			=> __( 'Pulse', 'digalu' ),
				],
			]
		);
		$this->add_control(
			'digalu_img_duration_6',
			[
				'label' => esc_html__( 'Duration', 'digalu' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 100,
				'max' => 1000,
				'step' => 100,
				'default' => 100,
			]
		);
        
		$this->end_controls_tab();

		//--------------------------------7--------------------------------//

		$this->start_controls_tab(
			'style_normal_tab8',
			[
				'label' => esc_html__( '7th Image', 'digalu' ),
				'condition'		=> [ 'iamge_style' => [ '3' ] ],
			]
		);
        $this->add_control(
			'digalu_img_animation_7',
			[
				'label' 	=> __( 'Animation', 'digalu' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'no animation',
				'options' 	=> [
					'wow fadeIn'  			=> __( 'Fade In', 'digalu' ),
					'wow fadeInLeft'  		=> __( 'Fade In Left', 'digalu' ),
					'wow fadeInDown'  		=> __( 'Fade In Down', 'digalu' ),
					'wow fadeInRight'  		=> __( 'Fade In Right', 'digalu' ),
					'wow fadeInUp'  		=> __( 'Fade In Up', 'digalu' ),
					'no animation'  		=> __( 'No Animation', 'digalu' ),
					'wow pulse'  			=> __( 'Pulse', 'digalu' ),
				],
			]
		);
		$this->add_control(
			'digalu_img_duration_7',
			[
				'label' => esc_html__( 'Duration', 'digalu' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 100,
				'max' => 1000,
				'step' => 100,
				'default' => 100,
			]
		);
        
		$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();
	}

	protected function render() {

        $settings = $this->get_settings_for_display();

        if( $settings['iamge_style'] == '1' ){
        	$class = 'about-style-one';
        }elseif( $settings['iamge_style'] == '2' ){
        	$class = 'about-style-two';
        }elseif( $settings['iamge_style'] == '3' ){
        	$class = 'animate-illustration';
        }elseif( $settings['iamge_style'] == '4' ){
        	$class = 'about-style-three';
        }else{
        	$class = 'choose-us-style-three';
        }



        if( $settings['iamge_style'] == '6' ){
        	echo '<div class="about-style-four">';
                echo '<div class="thumb">';
                    if(!empty($settings['image1']['url'])){
	                    echo digalu_img_tag( array(
		                    'url'   => esc_url( $settings['image1']['url']  ),
		                ));
		            }
		            if(!empty($settings['image2']['url'])){
	                    echo digalu_img_tag( array(
		                    'url'   => esc_url( $settings['image2']['url']  ),
		                ));
		            }
		            if(!empty($settings['image3']['url'])){
	                    echo digalu_img_tag( array(
		                    'url'   => esc_url( $settings['image3']['url']  ),
		                ));
		            }
		            if(!empty($settings['image4']['url'])){
	                    echo digalu_img_tag( array(
		                    'url'   => esc_url( $settings['image4']['url']  ),
		                ));
		            }
		            if(!empty($settings['image5']['url'])){
		            	echo '<div class="shape">';
		                    echo digalu_img_tag( array(
			                    'url'   => esc_url( $settings['image5']['url']  ),
			                ));
		                echo '</div>';
		            }
                    echo '<div class="icon"><i class="fas fa-arrow-up"></i></div>';
                echo '</div>';
            echo '</div>';
        }elseif( $settings['iamge_style'] == '5' ){
        	echo '<div class="'.esc_attr($class).'">';
	        	echo '<div class="thumb">';
	        		if(!empty($settings['image1']['url'])){
		                echo '<div class="shape">';
		                    echo digalu_img_tag( array(
			                    'url'   => esc_url( $settings['image1']['url']  ),
			                ));
		                echo '</div>';
		            }
		            if(!empty($settings['image2']['url'])){
		                echo '<div class="thumb-inner">';
		                    echo digalu_img_tag( array(
			                    'url'   => esc_url( $settings['image2']['url']  ),
			                ));
		                echo '</div>';
		            }
	            echo '</div>';
            echo '</div>';
        }elseif( $settings['iamge_style'] == '8' ){
        	echo '<div class="choose-us-style-three">';
                echo '<div class="thumb">';
                	if(!empty($settings['image1']['url'])){
	                    echo '<div class="shape">';
	                        echo digalu_img_tag( array(
			                    'url'   => esc_url( $settings['image1']['url']  ),
			                ));
	                    echo '</div>';
	                }
	                if(!empty($settings['image2']['url'])){
	                    echo '<div class="thumb-inner">';
	                        echo digalu_img_tag( array(
			                    'url'   => esc_url( $settings['image2']['url']  ),
			                ));
	                    echo '</div>';
	                }
	                if(!empty($settings['years'])){
	                    echo '<div class="experience-box">';
	                        echo '<div class="item-inner">';
	                            echo '<h2>'.wp_kses_post( $settings['years'] ).'</h2>';
	                        echo '</div>';
	                    echo '</div>';
	                }
                echo '</div>';
            echo '</div>';
        }elseif( $settings['iamge_style'] == '7' ){
        	echo '<div class="about-style-three">';
                echo '<div class="thumb">';
                	if(!empty($settings['image1']['url'])){
	                    echo digalu_img_tag( array(
		                    'url'   => esc_url( $settings['image1']['url']  ),
		                ));
	                }
	                if(!empty($settings['image2']['url'])){
	                    echo '<div class="sub-thumb">';
	                        echo digalu_img_tag( array(
			                    'url'   => esc_url( $settings['image2']['url']  ),
			                ));
	                    echo '</div>';
	                }
                echo '</div>';
            echo '</div>';
        }else{
	        echo '<div class="'.esc_attr($class).'">';
	        	if($settings['iamge_style'] != '3' ){
		        	echo '<div class="thumb">';
		        }
		        	if(!empty($settings['image1']['url'])){
		                echo digalu_img_tag( array(
		                    'url'   => esc_url( $settings['image1']['url']  ),
		                    'class' => esc_attr( $settings['digalu_img_animation_1'] ),
		                    'data-wow-delay' => $settings['digalu_img_duration_1'].'ms'

		                ));
			        }
			        
			        if(($settings['iamge_style'] == '2') || ($settings['iamge_style'] == '3') ){
			        	echo '<div class="sub-item">';
			        }
			        if(($settings['iamge_style'] == '4') ){
			        	echo '<div class="sub-thumb">';
			        }
				        if(!empty($settings['image2']['url'])){
			                echo digalu_img_tag( array(
			                    'url'   => esc_url( $settings['image2']['url']  ),
			                    'class' => esc_attr( $settings['digalu_img_animation_2'] ),
			                    'data-wow-delay' => $settings['digalu_img_duration_2'].'ms'
			                ));
				        }
				        if(!empty($settings['image3']['url'])){
			                echo digalu_img_tag( array(
			                    'url'   => esc_url( $settings['image3']['url']  ),
			                    'class' => esc_attr( $settings['digalu_img_animation_3'] ),
			                    'data-wow-delay' => $settings['digalu_img_duration_3'].'ms'
			                ));
				        }
				        if(!empty($settings['image4']['url'])){
			                echo digalu_img_tag( array(
			                    'url'   => esc_url( $settings['image4']['url']  ),
			                    'class' => esc_attr( $settings['digalu_img_animation_4'] ),
			                    'data-wow-delay' => $settings['digalu_img_duration_4'].'ms'
			                ));
				        }
				        if(!empty($settings['image5']['url'])){
			                echo digalu_img_tag( array(
			                    'url'   => esc_url( $settings['image5']['url']  ),
			                    'class' => esc_attr( $settings['digalu_img_animation_5'] ),
			                    'data-wow-delay' => $settings['digalu_img_duration_5'].'ms'
			                ));
				        }
				        if(!empty($settings['image6']['url'])){
			                echo digalu_img_tag( array(
			                    'url'   => esc_url( $settings['image6']['url']  ),
			                    'class' => esc_attr( $settings['digalu_img_animation_6'] ),
			                    'data-wow-delay' => $settings['digalu_img_duration_6'].'ms'
			                ));
				        }
				        if(!empty($settings['image7']['url'])){
			                echo digalu_img_tag( array(
			                    'url'   => esc_url( $settings['image7']['url']  ),
			                    'class' => esc_attr( $settings['digalu_img_animation_7'] ),
			                    'data-wow-delay' => $settings['digalu_img_duration_7'].'ms'
			                ));
				        }
			        if(($settings['iamge_style'] == '2') || ($settings['iamge_style'] == '3')  || ($settings['iamge_style'] == '4') ){
			        	echo '</div>';
			        }

				if($settings['iamge_style'] != '3' ){
		        	echo '</div>';
		        }
	        echo '</div>'; 
	    }

	}

}