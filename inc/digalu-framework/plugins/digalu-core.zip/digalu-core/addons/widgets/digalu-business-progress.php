<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * WCU Box Widget .
 *
 */
class Digalu_Business_Progress extends Widget_Base {

	public function get_name() {
		return 'digalubusinessprogress';
	}

	public function get_title() {
		return __( 'Business Progress', 'digalu' );
	}


	public function get_icon() {
		return 'vt-icon';
    }


	public function get_categories() {
		return [ 'digalu' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'services_section',
			[
				'label' 	=> __( 'Right Area', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

		$this->add_control(
			'title',
			[
				'label'     	=> __( 'Title', 'digalu' ),
                'type'      	=> Controls_Manager::TEXTAREA,
                'rows' 			=> 2,
                'default' 		=>  __( 'This is title area', 'digalu'),
			]
        );
        $this->add_control(
			'item_list',
			[
				'label'     => __( 'Item List', 'digalu' ),
                'type'      => Controls_Manager::WYSIWYG,
			]
        );
        
        $this->add_control(
			'progressbar_title',
			[
				'label'     => __( 'Progressbar Title', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
			]
        );
        $this->add_control(
			'progressbar',
			[
				'label'     => __( 'Number', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
			]
        );
        $this->end_controls_section();

        $this->start_controls_section(
			'left_section',
			[
				'label' 	=> __( 'Left Area', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'thumb',
			[
				'label' 		=> __( 'Image', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'counter',
			[
				'label'     => __( 'Counter', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
			]
        );
        $this->add_control(
			'counter_title',
			[
				'label'     => __( 'Counter Title', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
			]
        );
        $this->end_controls_section();
        

	/*--------------------------------------------------------end Feedback styling---------------------------------------------------*/


	}

	protected function render() {

        $settings = $this->get_settings_for_display();


        echo '<div class="business-progress-area">';
	        echo '<div class="container">';
	            echo '<div class="row align-center">';
	            	if( ! empty( $settings['thumb']['url'] ) ){
		                echo '<div class="col-xl-6 col-lg-5">';
		                    echo '<div class="business-progress-thumb">';
		                        echo digalu_img_tag( array(
									'url'	=> esc_url( $settings['thumb']['url'] )
								) );
		                        echo '<div class="fun-fact">';
		                            echo '<div class="counter">';
		                            	if( ! empty( $settings['counter'] ) ){
			                                echo '<div class="timer" data-to="'.esc_attr( $settings['counter'] ).'" data-speed="5000">'.esc_html( $settings['counter'] ).'</div>';
			                                echo '<div class="operator">K</div>';
			                            }
		                            echo '</div>';
		                            if( ! empty( $settings['counter_title'] ) ){
			                            echo '<span class="medium">'.esc_html( $settings['counter_title'] ).'</span>';
			                        }
		                        echo '</div>';
		                    echo '</div>';
		                echo '</div>';
		            }

	                echo '<div class="col-xl-5 offset-xl-1 col-lg-6 offset-lg-1">';
	                    echo '<div class="business-progress-info">';
	                    if( ! empty( $settings['title'] ) ){
		                    echo '<h2 class="title">'.wp_kses_post( $settings['title'] ).'</h2>';
		                }
	                        echo '<div class="list-grid-info">';
	                          if( ! empty( $settings['item_list'] ) ){
				                    echo wp_kses_post( $settings['item_list'] );
				                } 
	                           
	                        echo '</div>';
	                        echo '<div class="skill-items style-two mt-30">';
	                            echo '<!-- Progress Bar Start -->';
	                            echo '<div class="progress-box">';
	                            	if( ! empty( $settings['progressbar_title'] ) ){
		                                echo '<h5>'.esc_html( $settings['progressbar_title'] ).'</h5>';
		                            }
		                            if( ! empty( $settings['progressbar_title'] ) ){
		                                echo '<div class="progress">';
		                                    echo '<div class="progress-bar" role="progressbar" data-width="'.esc_attr( $settings['progressbar'] ).'">';
		                                            echo '<span>'.esc_html( $settings['progressbar'] ).'%</span>';
		                                    echo '</div>';
		                                echo '</div>';
		                            }
	                            echo '</div>';
	                            echo '<!-- End Progressbar -->';
	                        echo '</div>';
	                    echo '</div>';
	                echo '</div>';
	                
	            echo '</div>';
	        echo '</div>';
	    echo '</div>';
	}
}