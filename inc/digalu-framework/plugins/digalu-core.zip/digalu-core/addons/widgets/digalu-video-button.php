<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
/**
 *
 * Image Widget .
 *
 */
class Digalu_Play_Button extends Widget_Base {

	public function get_name() {
		return 'digaluplaybutton';
	}

	public function get_title() {
		return __( 'Digalu Play Button', 'digalu' );
	}


	public function get_icon() {
		return 'vt-icon';
    }


	public function get_categories() {
		return [ 'digalu' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'play_button_section',
			[
				'label' 	=> __( 'Play Button', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'btn_text',
			[
				'label'     => __( 'Button Text', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default' 		=> __('OUR STORY','digalu')
			]
        );
        $this->add_control(
			'video_link',
			[
				'label' 		=> __( 'Video Url', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
                'default' 		=> __('#','digalu'),
                'placeholder' 	=> __( 'https://your-link.com', 'digalu' ),

			]
        );	
        $this->end_controls_section();
        //-------------------------------video button styling------------------------------- //

		$this->start_controls_section(
			'video_btn_style_section',
			[
				'label' 	=> __( 'Video Button Style', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'video_btn_color',
			[
				'label' 	=> __( 'Video Button Color', 'digalu' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .video-play-button.with-text span' => '--white: {{VALUE}}!important;',
                ]
			]
        );


		$this->add_control(
			'video_btn_background_color',
			[
				'label' 	=> __( 'Video Button Background Color', 'digalu' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .video-play-button.with-text .effect' => '--color-primary: {{VALUE}}!important;',
                ]
			]
		);

		$this->add_control(
			'video_btn_ripple_effect_color',
			[
				'label' 		=> __( 'Video Button Ripple Effect Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .video-play-button.with-text .effect::after' => '--color-primary: {{VALUE}}!important;',
                ]
			]
        );

		$this->end_controls_section();
	}

	protected function render() {

        $settings = $this->get_settings_for_display();

        echo '<a href="'.esc_url($settings['video_link']).'" class="popup-youtube video-play-button with-text">';
        	if(!empty($settings['btn_text'])){
	            echo '<div class="effect"></div><span><i class="fas fa-play"></i> '.esc_html($settings['btn_text']).'</span>';
	        }
        echo '</a>';
	}

}