<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Utils;
/**
 *
 * Blog Post Widget .
 *
 */
class Digalu_Blog_Post extends Widget_Base {

	public function get_name() {
		return 'digalublogpost';
	}

	public function get_title() {
		return __( 'Digalu Blog Post', 'digalu' );
	}

	public function get_icon() {
		return 'vt-icon';
    }

	public function get_categories() {
		return [ 'digalu' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'blog_post_section',
			[
				'label' => __( 'Blog Post', 'digalu' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'blog_style',
			[
				'label' 		=> __( 'Blog Style', 'digalu' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> '1',
				'options' 		=> [
					'1'  		=> __( 'Style One', 'digalu' ),
					'2' 		=> __( 'Style Two', 'digalu' ),
				],
			]
		);
        
        $this->add_control(
			'blog_post_count',
			[
				'label' 	=> __( 'No of Post to show', 'digalu' ),
                'type' 		=> Controls_Manager::NUMBER,
                'min'       => 1,
                'max'       => count( get_posts( array('post_type' => 'post', 'post_status' => 'publish', 'fields' => 'ids', 'posts_per_page' => '-1') ) ),
                'default'  	=> __( '4', 'digalu' )
			]
        );

		$this->add_control(
			'title_count',
			[
				'label' 	=> __( 'Title Length', 'digalu' ),
				'type' 		=> Controls_Manager::TEXT,
				'default'  	=> __( '4', 'digalu' ),
			]
		);
		$this->add_control(
			'excerpt_count',
			[
				'label' 	=> __( 'Excerpt Length', 'digalu' ),
				'type' 		=> Controls_Manager::TEXT,
				'default'  	=> __( '16', 'digalu' ),
			]
		);
		$this->add_control(
			'read_more_text',
			[
				'label' 	=> __( 'Button Text', 'digalu' ),
				'type' 		=> Controls_Manager::TEXT,
				'default'  	=> __( 'Read More', 'digalu' ),
				'condition'		=> [ 'blog_style' =>  '2' ],
			]
		);

        $this->add_control(
			'blog_post_order',
			[
				'label' 	=> __( 'Order', 'digalu' ),
                'type' 		=> Controls_Manager::SELECT,
                'options'   => [
                    'ASC'   	=> __('ASC','digalu'),
                    'DESC'   	=> __('DESC','digalu'),
                ],
                'default'  	=> 'DESC'
			]
        );

        $this->add_control(
			'blog_post_order_by',
			[
				'label' 	=> __( 'Order By', 'digalu' ),
                'type' 		=> Controls_Manager::SELECT,
                'options'   => [
                    'ID'    	=> __( 'ID', 'digalu' ),
                    'author'    => __( 'Author', 'digalu' ),
                    'title'    	=> __( 'Title', 'digalu' ),
                    'date'    	=> __( 'Date', 'digalu' ),
                    'rand'    	=> __( 'Random', 'digalu' ),
                ],
                'default'  	=> 'ID'
			]
        );

        $this->add_control(
			'exclude_cats',
			[
				'label' 		=> __( 'Exclude Categories', 'digalu' ),
                'type' 			=> Controls_Manager::SELECT2,
                'multiple' 		=> true,
				'options' 		=> $this->digalu_get_categories(),
			]
        );

        $this->add_control(
			'exclude_tags',
			[
				'label' 		=> __( 'Exclude Tags', 'digalu' ),
                'type' 			=> Controls_Manager::SELECT2,
                'multiple' 		=> true,
				'options' 		=> $this->digalu_get_tags(),
			]
        );

        $this->add_control(
			'exclude_post_id',
			[
				'label'         => __( 'Exclude Post', 'digalu' ),
                'type'          => Controls_Manager::SELECT2,
                'multiple'      => true,
				'options'       => $this->digalu_post_id(),
			]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'slider_control_section',
			[
				'label' 		=> __( 'Slider Control', 'digalu' ),
				'tab' 			=> Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'make_slider',
			[
				'label' 		=> __( 'Use it as slider ?', 'digalu' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Show', 'digalu' ),
				'label_off' 	=> __( 'Hide', 'digalu' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);
		$this->add_control(
			'desktop_items',
			[
				'label' 		=> __( 'Items To Show', 'digalu' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ '%' ],
				'range' 		=> [
					'%' 	=> [
						'min' 		=> 0,
						'step' 		=> 1,
						'max' 		=> 10,
					],
				],
				'default' 		=> [
					'unit' 			=> '%',
					'size' 			=> 5,
				],
				'condition'		=> [ 'make_slider' => [ 'yes' ] ],
			]
		);
		$this->add_control(
			'laptop_items',
			[
				'label' 		=> __( 'Laptop Items', 'digalu' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ '%' ],
				'range' 		=> [
					'%' 	=> [
						'min' 	=> 0,
						'step' 	=> 1,
						'max' 	=> 10,
					],
				],
				'default' 	=> [
					'unit' 		=> '%',
					'size' 		=> 2,
				],
				'condition'		=> [ 'make_slider' => [ 'yes' ] ],
			]
		);

        $this->add_control(
			'tablet_items',
			[
				'label' 		=> __( 'Tablet Items', 'digalu' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ '%' ],
				'range' 		=> [
					'%' 	=> [
						'min' 	=> 0,
						'step' 	=> 1,
						'max' 	=> 10,
					],
				],
				'default' 	=> [
					'unit' 		=> '%',
					'size' 		=> 2,
				],
				'condition'		=> [ 'make_slider' => [ 'yes' ] ],
			]
		);

        $this->add_control(
			'mobile_items',
			[
				'label' 		=> __( 'Mobile Items', 'digalu' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ '%' ],
				'range' 		=> [
					'%' 	=> [
						'min' 	=> 0,
						'step' 	=> 1,
						'max' 	=> 10,
					],
				],
				'default' 	=> [
					'unit' 		=> '%',
					'size' 		=> 1,
				],
				'condition'		=> [ 'make_slider' => [ 'yes' ] ],
			]
		);
		$this->add_control(
			'colmn_items',
			[
				'label' 		=> __( 'Column View', 'digalu' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ '%' ],
				'range' 		=> [
					'%' 	=> [
						'min' 		=> 0,
						'step' 		=> 1,
						'max' 		=> 4,
					],
				],
				'default' 		=> [
					'unit' 			=> '%',
					'size' 			=> 4,
				],
				'condition'		=> [ 'make_slider!' =>  'yes' ],
			]
		);
		$this->end_controls_section();

        /*-----------------------------------------META styling------------------------------------*/

		$this->start_controls_section(
			'meta_con_styling',
			[
				'label' 	=> __( 'Meta Styling', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
        );
        $this->start_controls_tabs(
			'meta_tabs3'
		);


		$this->start_controls_tab(
			'meta_normal_tab3',
			[
				'label' => esc_html__( 'Icon', 'digalu' ),
			]
		);
        $this->add_control(
			'meta_title_color',
			[
				'label' 		=> __( 'Icon Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .blog-area .item .info .meta ul li i'	=> 'color: {{VALUE}}!important;'

				],
			]
        );
        $this->add_control(
			'icon_size',
			[
				'label' 		=> __( 'icon Size', 'digalu' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' 	=> [ 'px' ],
				'range' 		=> [
					'%' 	=> [
						'min' 		=> 0,
						'step' 		=> 1,
						'max' 		=> 100,
					],
				],
				'default' 		=> [
					'unit' 			=> 'px',
					'size' 			=> 4,
				],
				'selectors' => [
					'{{WRAPPER}} .blog-area .item .info .meta ul li i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		//--------------------secound--------------------//

		$this->start_controls_tab(
			'meta_hover_tab4',
			[
				'label' => esc_html__( 'Content', 'digalu' ),
			]
		);
		$this->add_control(
			'meta_content_color',
			[
				'label' 		=> __( 'Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .blog-area .item .info .meta ul li, {{WRAPPER}} .blog-area .item .info .meta ul li a'	=> 'color: {{VALUE}}!important;'
				],
			]
        );
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'meta_title_typography',
		 		'label' 		=> __( 'Typography', 'digalu' ),
		 		'selector' 	=> '{{WRAPPER}} .blog-area .item .info .meta ul li, {{WRAPPER}} .blog-area .item .info .meta ul li a',
			]
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();

		

		/*-----------------------------------------Blog Content styling------------------------------------*/

		$this->start_controls_section(
			'blog_con_styling',
			[
				'label' 	=> __( 'Blog Content Styling', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
        );
        $this->start_controls_tabs(
			'blog_tabs3'
		);


		$this->start_controls_tab(
			'blog_normal_tab3',
			[
				'label' => esc_html__( 'Title', 'digalu' ),
			]
		);
        $this->add_control(
			'blog_title_color',
			[
				'label' 		=> __( 'Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} h4 a'	=> 'color: {{VALUE}}!important;'

				],
			]
        );
        $this->add_control(
			'blog_title_hvr_color',
			[
				'label' 		=> __( 'Hover Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .blog-area h4 a:hover'	=> 'color: {{VALUE}}!important;'

				],
			]
        );
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'blog_title_typography',
		 		'label' 		=> __( 'Typography', 'digalu' ),
		 		'selector' 	=> '{{WRAPPER}} h4 a',
			]
		);

        $this->add_responsive_control(
			'blog_title_margin',
			[
				'label' 		=> __( 'Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} h4 a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ],
			]
        );

        $this->add_responsive_control(
			'blog_title_padding',
			[
				'label' 		=> __( 'Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} h4 a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

				],
			]
        );
		$this->end_controls_tab();

		//--------------------secound--------------------//

		$this->start_controls_tab(
			'blog_hover_tab4',
			[
				'label' => esc_html__( 'Content', 'digalu' ),
			]
		);
		$this->add_control(
			'blog_content_color',
			[
				'label' 		=> __( 'Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .info p'	=> 'color: {{VALUE}}!important;'
				],
			]
        );
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'blog_content_typography',
		 		'label' 		=> __( 'Typography', 'digalu' ),
		 		'selector' 	=> '{{WRAPPER}} .info p',
			]
		);

        $this->add_responsive_control(
			'blog_content_margin',
			[
				'label' 		=> __( 'Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .info p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ],
			]
        );

        $this->add_responsive_control(
			'blog_content_padding',
			[
				'label' 		=> __( 'Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .info p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ],
			]
        );

		$this->end_controls_tab();


		$this->end_controls_tabs();
		$this->end_controls_section();

    }

    public function digalu_get_categories() {
        $cats = get_terms(array(
            'taxonomy' => 'category',
            'hide_empty' => true,
        ));

        $catarr = [];

        foreach( $cats as $singlecat ) {
            $catarr[$singlecat->term_id] = __($singlecat->name,'digalu');
        }

        return $catarr;
    }

    public function digalu_get_tags() {
        $cats = get_terms(array(
            'taxonomy' => 'post_tag',
            'hide_empty' => true,
        ));

        $catarr = [];

        foreach( $cats as $singlecat ) {
            $catarr[$singlecat->term_id] = __($singlecat->name,'digalu');
        }

        return $catarr;
    }

    // Get Specific Post
    public function digalu_post_id(){
        $args = array(
            'post_type'         => 'post',
            'posts_per_page'    => -1,
        );

        $digalu_post = new WP_Query( $args );

        $postarray = [];

        while( $digalu_post->have_posts() ){
            $digalu_post->the_post();
            $postarray[get_the_Id()] = get_the_title();
        }
        wp_reset_postdata();
        return $postarray;
    }

	protected function render() {

        $settings = $this->get_settings_for_display();
        $exclude_post = $settings['exclude_post_id'];

        if( !empty( $settings['exclude_cats'] ) && empty( $settings['exclude_tags'] ) && empty( $settings['exclude_post_id'] ) ) {
            $args = array(
                'post_type'             => 'post',
                'posts_per_page'        => esc_attr( $settings['blog_post_count'] ),
                'order'                 => esc_attr( $settings['blog_post_order'] ),
                'orderby'               => esc_attr( $settings['blog_post_order_by'] ),
                'ignore_sticky_posts'   => true,
                'category__not_in'      => $settings['exclude_cats']
            );
        } elseif( !empty( $settings['exclude_cats'] ) && !empty( $settings['exclude_tags'] ) && empty( $settings['exclude_post_id'] ) ) {
            $args = array(
                'post_type'             => 'post',
                'posts_per_page'        => esc_attr( $settings['blog_post_count'] ),
                'order'                 => esc_attr( $settings['blog_post_order'] ),
                'orderby'               => esc_attr( $settings['blog_post_order_by'] ),
                'ignore_sticky_posts'   => true,
                'category__not_in'      => $settings['exclude_cats'],
                'tag__not_in'           => $settings['exclude_tags']
            );
        }elseif( !empty( $settings['exclude_cats'] ) && !empty( $settings['exclude_tags'] ) && !empty( $settings['exclude_post_id'] ) ) {
            $args = array(
                'post_type'             => 'post',
                'posts_per_page'        => esc_attr( $settings['blog_post_count'] ),
                'order'                 => esc_attr( $settings['blog_post_order'] ),
                'orderby'               => esc_attr( $settings['blog_post_order_by'] ),
                'ignore_sticky_posts'   => true,
                'category__not_in'      => $settings['exclude_cats'],
                'tag__not_in'           => $settings['exclude_tags'],
                'post__not_in'          => $exclude_post
            );
        } elseif( !empty( $settings['exclude_cats'] ) && empty( $settings['exclude_tags'] ) && !empty( $settings['exclude_post_id'] ) ) {
            $args = array(
                'post_type'             => 'post',
                'posts_per_page'        => esc_attr( $settings['blog_post_count'] ),
                'order'                 => esc_attr( $settings['blog_post_order'] ),
                'orderby'               => esc_attr( $settings['blog_post_order_by'] ),
                'ignore_sticky_posts'   => true,
                'category__not_in'      => $settings['exclude_cats'],
                'post__not_in'          => $exclude_post
            );
        } elseif( empty( $settings['exclude_cats'] ) && !empty( $settings['exclude_tags'] ) && !empty( $settings['exclude_post_id'] ) ) {
            $args = array(
                'post_type'             => 'post',
                'posts_per_page'        => esc_attr( $settings['blog_post_count'] ),
                'order'                 => esc_attr( $settings['blog_post_order'] ),
                'orderby'               => esc_attr( $settings['blog_post_order_by'] ),
                'ignore_sticky_posts'   => true,
                'tag__not_in'           => $settings['exclude_tags'],
                'post__not_in'          => $exclude_post
            );
        } elseif( empty( $settings['exclude_cats'] ) && !empty( $settings['exclude_tags'] ) && empty( $settings['exclude_post_id'] ) ) {
            $args = array(
                'post_type'             => 'post',
                'posts_per_page'        => esc_attr( $settings['blog_post_count'] ),
                'order'                 => esc_attr( $settings['blog_post_order'] ),
                'orderby'               => esc_attr( $settings['blog_post_order_by'] ),
                'ignore_sticky_posts'   => true,
                'tag__not_in'           => $settings['exclude_tags'],
            );
        } elseif( empty( $settings['exclude_cats'] ) && empty( $settings['exclude_tags'] ) && !empty( $settings['exclude_post_id'] ) ) {
            $args = array(
                'post_type'             => 'post',
                'posts_per_page'        => esc_attr( $settings['blog_post_count'] ),
                'order'                 => esc_attr( $settings['blog_post_order'] ),
                'orderby'               => esc_attr( $settings['blog_post_order_by'] ),
                'ignore_sticky_posts'   => true,
                'post__not_in'          => $exclude_post
            );
        } else {
            $args = array(
                'post_type'             => 'post',
                'posts_per_page'        => esc_attr( $settings['blog_post_count'] ),
                'order'                 => esc_attr( $settings['blog_post_order'] ),
                'orderby'               => esc_attr( $settings['blog_post_order_by'] ),
                'ignore_sticky_posts'   => true
            );
        }

        if( $settings['make_slider'] == 'yes' ){
    		$this->add_render_attribute( 'wrapper', 'class', 'row blog-carousel swiper' );
			$this->add_render_attribute( 'wrapper', 'data-slide-show', $settings['desktop_items']['size'] );
	        $this->add_render_attribute( 'wrapper', 'data-lg-slide-show', $settings['laptop_items']['size'] );
	        $this->add_render_attribute( 'wrapper', 'data-md-slide-show', $settings['tablet_items']['size'] );
	        $this->add_render_attribute( 'wrapper', 'data-sm-slide-show', $settings['mobile_items']['size'] );

		}else{
			$this->add_render_attribute( 'wrapper', 'class', 'row' );
			if( $settings['colmn_items']['size'] == 1 ){
				$colmn = 12;
			}elseif( $settings['colmn_items']['size'] == 2 ){
				$colmn = 6;
			}elseif( $settings['colmn_items']['size'] == 3 ){
				$colmn = 4;
			}else{
				$colmn = 3;
			}
		}
		
        $blogpost = new WP_Query( $args );

        if( $blogpost->have_posts() ) {
        	
        	echo '<div class="blog-area blog-grid">';
        		if( $settings['blog_style'] == '1' ){
        			$style = 'single-item thumb-less';
        		}else{
        			$style = 'single-item';
        		}
		        
	            echo '<div '.$this->get_render_attribute_string('wrapper').'>';
	            	if( $settings['make_slider'] == 'yes' ){
		                $div_class = '<div class="swiper-slide '.esc_attr($style).' ">';
		            }else{
		            	$div_class = '<div class="'.esc_attr($style).' col-xl-'.$colmn.' col-md-6">';
		            }
		            if( $settings['make_slider'] == 'yes' ){
		                echo '<div class="swiper-wrapper">';
		            }
	            	while( $blogpost->have_posts() ) {
						$blogpost->the_post();
						$categories = get_the_category();

						echo wp_kses_post($div_class);


							if( $settings['blog_style'] == '1' ){
								$featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'digalu_750X500');

								
	                            echo '<div class="item text-light" style="background-image: url('.esc_url($featured_img_url).');">';
	                                echo '<div class="info">';
	                                    echo '<div class="tags">';
	                                        echo '<a href="'. esc_url( get_category_link( $categories[0]->term_id ) ) . '">'.esc_html( $categories[0]->name ).'</a>';
	                                    echo '</div>';
	                                    echo '<div class="meta">';
	                                        echo '<ul>';
	                                            echo '<li>';
	                                            	$role_id = get_the_author_meta('ID');
	                                            	$theAuthorDataRoles = get_userdata($role_id);

	                                                echo '<a href="'.esc_url( get_author_posts_url( get_the_author_meta('ID') ) ).'"><i class="fas fa-user-circle"></i> '.array_shift($theAuthorDataRoles->roles).'</a>';
	                                            echo '</li>';
	                                            echo '<li>';
	                                                echo '<a href="'.esc_url( digalu_blog_date_permalink() ).'"><i class="fas fa-calendar-alt"></i> '.esc_html( get_the_date( 'd M, Y' ) ).'</a>';
	                                            echo '</li>';
	                                        echo '</ul>';
	                                    echo '</div>';
	                                    echo '<h4><a href="'.esc_url( get_permalink() ).'">'.esc_html( wp_trim_words( get_the_title( ), $settings['title_count'], '' ) ).'</a></h4>';
	                                    echo '<p>'.esc_html( wp_trim_words( get_the_content( ), $settings['excerpt_count'], '' ) ).'</p>';
	                                    echo '<div class="author-meta">';
	                                        echo '<div class="thumbs">';
	                                            echo '<a href="'.esc_url( get_author_posts_url( get_the_author_meta('ID') ) ).'">';
	                                            echo digalu_img_tag( array(
						                            "url"       => esc_url( get_avatar_url( get_the_author_meta('ID'), array() ) ),
						                        ) );
	                                            echo '</a>';
	                                        echo '</div>';
	                                        echo '<div class="meta-info">';
	                                            echo '<h5>'.esc_html( get_the_author() ).'</h5>';
	                                            echo '<span>'.esc_html( get_the_date( 'M d, Y' ) ).'</span>';
	                                        echo '</div>';
	                                    echo '</div>';
	                                echo '</div>';
	                            echo '</div>';
	                        }else{

	                        	echo '<div class="item">';
	                        		if(has_post_thumbnail()){
				                        echo '<div class="thumb">';
				                            echo '<a href="'.esc_url( get_permalink() ).'">';
					                        	if(has_post_thumbnail()){
						                            the_post_thumbnail('digalu_800X600');
						                        }
						                    echo '</a>';
				                            echo '<div class="tags">';
				                                echo '<a href="'. esc_url( get_category_link( $categories[0]->term_id ) ) . '">'.esc_html( $categories[0]->name ).'</a>';
				                            echo '</div>';
				                        echo '</div>';
				                    }
			                        echo '<div class="info">';
			                            echo '<div class="meta">';
			                                echo '<ul>';
			                                    echo '<li><a href="'.esc_url( digalu_blog_date_permalink() ).'"><i class="far fa-calendar-alt"></i> '.esc_html( get_the_date( 'M d, Y' ) ).'</a></li>';
			                                    echo '<li><a href="'.esc_url( get_author_posts_url( get_the_author_meta('ID') ) ).'"><i class="far fa-user-circle"></i> '.esc_html( get_the_author() ).'</a></li>';
			                                echo '</ul>';
			                            echo '</div>';
			                            echo '<h4><a href="'.esc_url( get_permalink() ).'">'.esc_html( wp_trim_words( get_the_title( ), $settings['title_count'], '' ) ).'</a></h4>';
			                            if( !empty( $settings['read_more_text'] ) ){
				                            echo '<a href="'.esc_url( get_permalink() ).'" class="button-regular">'.esc_html( $settings['read_more_text'] ).'<i class="fas fa-arrow-right"></i></a>';
				                        }
			                        echo '</div>';
			                    echo '</div>';
	                        }
                        echo '</div>';
		            }
		            if( $settings['make_slider'] == 'yes' ){
		                echo '</div>';
		                if( $settings['allow_arrow'] == 'yes' ){
			                echo '<div class="swiper-control">';
		                        echo '<!-- Pagination -->';
		                        echo '<div class="swiper-pagination"></div>';

		                        echo '<!-- Navigation -->';
		                        echo '<div class="swiper-button-prev"></div>';
		                        echo '<div class="swiper-button-next"></div>';
		                    echo '</div>';
		                }
		            }
		            wp_reset_postdata();
		        echo '</div>';
		    echo '</div>';
        }   
	}
}