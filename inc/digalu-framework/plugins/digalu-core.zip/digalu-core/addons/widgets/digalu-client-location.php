<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * client location Widget .
 *
 */
class Digalu_Client_Location_Process extends Widget_Base {

	public function get_name() {
		return 'digaluclientlocation';
	}

	public function get_title() {
		return __( 'Digalu Location', 'digalu' );
	}


	public function get_icon() {
		return 'vt-icon';
    }


	public function get_categories() {
		return [ 'digalu' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'location_section',
			[
				'label' 	=> __( 'Location', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

		$this->add_control(
			'location',
			[
				'label'     => __( 'Location Name', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default' 	=> __( 'USA' , 'digalu' ),
			]
        );
        
        $this->end_controls_section();

        $this->start_controls_section(
			'style_section',
			[
				'label' 	=> __( 'position', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
        );

        $this->add_responsive_control(
			'from_top',
			[
				'label' 		=> __( 'Top', 'digalu' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' 	=> [
					'{{WRAPPER}} .clients-map .location-pointer'	=> 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'from_left',
			[
				'label' 		=> __( 'Left', 'digalu' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' 	=> [
					'{{WRAPPER}} .clients-map .location-pointer'	=> 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'from_right',
			[
				'label' 		=> __( 'Right', 'digalu' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' 	=> [
					'{{WRAPPER}} .clients-map .location-pointer'	=> 'right: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'from_bottom',
			[
				'label' 		=> __( 'Bottom', 'digalu' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' 	=> [
					'{{WRAPPER}} .clients-map .location-pointer'	=> 'bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
        $this->end_controls_section();

		

	}

	protected function render() {

        $settings = $this->get_settings_for_display();

        echo '<div class="clients-map">';
            echo '<div class="location-pointer">';
                echo '<a href="#">'.esc_html($settings['location']).'</a>';
            echo '</div>';
        echo '</div>';
	}
}