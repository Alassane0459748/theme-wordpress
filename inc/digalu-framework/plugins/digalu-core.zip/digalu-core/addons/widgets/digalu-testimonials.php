<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Repeater;
use \Elementor\Group_Control_Border;
/**
 *
 * Testimonials Widget .
 *
 */
class Digalu_Testimonials extends Widget_Base {

	public function get_name() {
		return 'digalutestimonials';
	}

	public function get_title() {
		return __( 'Digalu Testimonials', 'digalu' );
	}

	public function get_icon() {
		return 'vt-icon';
    }

	public function get_categories() {
		return [ 'digalu' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'features_section',
			[
				'label'     => __( 'Testimonials', 'digalu' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'testimonials_style',
			[
				'label' 		=> __( 'Testimonial Style', 'digalu' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> '1',
				'options' 		=> [
					'1'  		=> __( 'Style One', 'digalu' ),
					'2' 		=> __( 'Style Two', 'digalu' ),
				],
			]
		);
        //----------------------------feddback repeter start--------------------------------//

		$repeater = new Repeater();

		$repeater->add_control(
			'name', [
				'label' 		=> __( 'Name', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Rubaida Kanom' , 'digalu' ),
				'label_block' 	=> true,
			]
        );
        $repeater->add_control(
			'designation', [
				'label' 		=> __( 'Designation', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Rubaida Kanom' , 'digalu' ),
				'label_block' 	=> true,
			]
        );
        $repeater->add_control(
			'feedback_title', [
				'label' 		=> __( 'Feedback For', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Design Quality' , 'digalu' ),
				'label_block' 	=> true,
			]
        );
        $repeater->add_control(
			'feedback', [
				'label' 		=> __( 'Feedback', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Rubaida Kanom' , 'digalu' ),
				'label_block' 	=> true,
			]
        );
        $repeater->add_control(
			'img',
			[
				'label' 		=> __( 'Image', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'slides',
			[
				'label' 		=> __( 'Slides', 'digalu' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'name' 		=> __( 'Rubaida Kanom', 'digalu' ),
					],
				],
				'title_field' 	=> '{{{ name }}}',
			]
		);
		$this->add_control(
			'allow_arrow',
			[
				'label' 		=> __( 'Allow Arrow ?', 'digalu' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Show', 'digalu' ),
				'label_off' 	=> __( 'Hide', 'digalu' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);

		$this->add_control(
			'shape',
			[
				'label' 		=> __( 'Shape Image', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'quote',
			[
				'label' 		=> __( 'Quote Image', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->end_controls_section();

		
        /*-----------------------------------------Feedback styling------------------------------------*/

		$this->start_controls_section(
			'overview_con_styling',
			[
				'label' 	=> __( 'Testimonials Styling', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
        );
        $this->start_controls_tabs(
			'style_tabs2'
		);


		$this->start_controls_tab(
			'style_normal_tab2',
			[
				'label' => esc_html__( 'Name', 'digalu' ),
			]
		);
        $this->add_control(
			'overview_title_color',
			[
				'label' 		=> __( 'Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} h4'	=> 'color: {{VALUE}}!important;',
				],
			]
        );
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'overview_title_typography',
		 		'label' 		=> __( 'Typography', 'digalu' ),
		 		'selector' 	=> '{{WRAPPER}} h4',
			]
		);

        $this->add_responsive_control(
			'overview_title_margin',
			[
				'label' 		=> __( 'Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'overview_title_padding',
			[
				'label' 		=> __( 'Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} h4' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );
		$this->end_controls_tab();

		//--------------------secound--------------------//

		$this->start_controls_tab(
			'style_hover_tab2',
			[
				'label' => esc_html__( 'Designation', 'digalu' ),
			]
		);
		$this->add_control(
			'overview_content_color',
			[
				'label' 		=> __( 'Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} span'	=> 'color: {{VALUE}}!important;',
				],
			]
        );
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'overview_content_typography',
		 		'label' 		=> __( 'Typography', 'digalu' ),
		 		'selector' 	=> '{{WRAPPER}} span',
			]
		);

        $this->add_responsive_control(
			'overview_content_margin',
			[
				'label' 		=> __( 'Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'overview_content_padding',
			[
				'label' 		=> __( 'Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

		$this->end_controls_tab();


		//--------------------three--------------------//

		$this->start_controls_tab(
			'style_hover_tab3',
			[
				'label' => esc_html__( 'Feedback', 'digalu' ),
			]
		);
		$this->add_control(
			'counter_color',
			[
				'label' 		=> __( 'Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} p'	=> 'color: {{VALUE}}!important;',
				],
			]
        );
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'counter_typography',
		 		'label' 		=> __( 'Typography', 'digalu' ),
		 		'selector' 	=> '{{WRAPPER}} p',
			]
		);

        $this->add_responsive_control(
			'counter_margin',
			[
				'label' 		=> __( 'Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'counter_padding',
			[
				'label' 		=> __( 'Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );



		$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();
    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        echo '<!------------------------------- Testimonials Area start ------------------------------->';

        	echo '<div class="testimonial-style-one-carousel swiper">';
                        
                echo '<div class="swiper-wrapper">';

                   	foreach( $settings['slides'] as $single_data ){
	                    echo '<div class="swiper-slide">';
	                    	if( $settings['testimonials_style'] == '1' ){
		                        echo '<div class="testimonial-style-one-item">';
		                        	if( ! empty( $settings['shape']['url'] ) ){
			                            echo '<div class="shape">';
			                                echo digalu_img_tag( array(
												'url'	=> esc_url( $settings['shape']['url'] ),
											) );
			                            echo '</div>';
			                        }
			                        if( ! empty( $settings['quote']['url'] ) ){
			                            echo '<div class="quote-icon">';
			                                echo digalu_img_tag( array(
												'url'	=> esc_url( $settings['quote']['url'] ),
											) );
			                            echo '</div>';
			                        }

		                            echo '<div class="item">';   
		                                echo '<div class="provider">';
		                                    echo '<div class="info">';
		                                        if(!empty($single_data['feedback_title'])){
				                                    echo '<h4>'.wp_kses_post($single_data['feedback_title']).'</h4>';
				                                }
				                                if(!empty($single_data['name'] &&  $single_data['designation'] )){
			                                        echo '<span><strong>'.esc_html($single_data['name']).'</strong> / '.esc_html($single_data['designation']).'</span>';
			                                    }
		                                    echo '</div>';
		                                echo '</div>';
		                                if(!empty($single_data['feedback'])){
			                                echo '<div class="content">';
			                                    echo '<p>'.esc_html( $single_data['feedback'] ).'</p>';
			                                echo '</div>';
			                            }
		                            echo '</div>';
		                       echo ' </div>';
		                   	}else{
		                   		echo '<div class="testimonial-style-two-item">';
                                    echo '<div class="item">';
                                    	if(!empty($single_data['feedback'])){
	                                        echo '<div class="content">';
	                                            echo '<p>'.esc_html( $single_data['feedback'] ).'</p>';
	                                        echo '</div>';
	                                    }

                                        echo '<div class="provider">';
                                        	if( ! empty( $single_data['img']['url'] ) ){
	                                            echo '<div class="thumb">';
	                                                echo digalu_img_tag( array(
														'url'	=> esc_url( $single_data['img']['url'] ),
													) );
	                                            echo '</div>';
	                                        }
                                            echo '<div class="info">';
                                                if(!empty($single_data['feedback_title'])){
				                                    echo '<h4>'.wp_kses_post($single_data['feedback_title']).'</h4>';
				                                }
                                                if(!empty($single_data['name'] &&  $single_data['designation'] )){
			                                        echo '<span><strong>'.esc_html($single_data['name']).'</strong> / '.esc_html($single_data['designation']).'</span>';
			                                    }
                                            echo '</div>';
                                        echo '</div>';
                                    echo '</div>';
                                echo '</div>';
		                   	}

	                    echo '</div>';
	                }
                echo '</div>';
                if( $settings['allow_arrow'] == 'yes' ){
	                echo '<div class="swiper-control">';
                        echo '<!-- Pagination -->';
                        echo '<div class="swiper-pagination"></div>';

                        echo '<!-- Navigation -->';
                        echo '<div class="swiper-button-prev"></div>';
                        echo '<div class="swiper-button-next"></div>';
                    echo '</div>';
                }
            echo '</div>';
		echo '<!--------------------------------- Testimonials Area end --------------------------------->';
	}
}