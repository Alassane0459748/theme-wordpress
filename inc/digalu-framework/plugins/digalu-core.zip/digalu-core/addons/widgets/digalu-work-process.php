<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * process Widget .
 *
 */
class Digalu_Work_Process extends Widget_Base {

	public function get_name() {
		return 'digaluworkprocess';
	}

	public function get_title() {
		return __( 'Digalu Work Process', 'digalu' );
	}


	public function get_icon() {
		return 'vt-icon';
    }


	public function get_categories() {
		return [ 'digalu' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'work_process_section',
			[
				'label' 	=> __( 'Work Process', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'process_style',
			[
				'label' 	=> __( 'Process Style', 'digalu' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '1',
				'options' 	=> [
					'1'  		=> __( 'Style One', 'digalu' ),
					'2' 		=> __( 'Style Two', 'digalu' ),
					'3' 		=> __( 'Style Three', 'digalu' ),
					'4' 		=> __( 'Style Four', 'digalu' ),
				],
			]
		);
		$this->add_control(
			'section_title',
			[
				'label' 	=> __( 'Title', 'digalu' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'default'  	=> __( 'Section Title', 'digalu' ),
                'condition'		=> [ 'process_style' => [ '4' ] ],
			]
        );
        $this->add_control(
			'section_subtitle',
			[
				'label' 	=> __( 'Subitle', 'digalu' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'default'  	=> __( 'Section Subitle', 'digalu' ),
			]
        );
		$this->add_control(
			'show_animation',
			[
				'label' 		=> __( 'Allow Animation ?', 'digalu' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Show', 'digalu' ),
				'label_off' 	=> __( 'Hide', 'digalu' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
				'condition'		=> [ 'process_style' => [ '4' ] ],
			]
		);
        $repeater = new Repeater();

		$repeater->add_control(
			'process_title',
			[
				'label'     => __( 'Title', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default' 		=> __( 'Project Planning' , 'digalu' ),
			]
        );
        $repeater->add_control(
			'process_content',
			[
				'label'     => __( 'Content', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default' 		=> __( 'Facilisis leo vel fringilla est ullamcorper. Posuere urna nec tincidunt praesent semper feugiat nibh sed. Non pulvinar neque laoreet suspendisse interdum consectetur semper feugiat nibh sed. Non pulvinar neque.. ' , 'digalu' ),
			]
        );

        $this->add_control(
			'process',
			[
				'label' 		=> __( 'Process', 'digalu' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 		=> __( 'title', 'digalu' ),
					],
				],
				'title_field' 	=> '{{{ process_title }}}',
				'condition'		=> [ 'process_style' => [ '1' ] ],
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'process_title',
			[
				'label'     => __( 'Title', 'digalu' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default' 		=> __( 'Project Planning' , 'digalu' ),
			]
        );
        $repeater->add_control(
			'chose_icon_style',
			[
				'label' 		=> __( 'Icon Type', 'digalu' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'class',
				'options' 		=> [
					'class'  	=> __( 'Class', 'digalu' ),
					'img' 		=> __( 'Image', 'digalu' ),
				],
			]
		);
        $repeater->add_control(
			'icon_class', [
				'label' 		=> __( 'Icon Class', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( '<i class="flaticon-bullhorn"></i>' , 'digalu' ),
				'label_block' 	=> true,
				'condition'		=> [ 'chose_icon_style' => [ 'class' ] ],
			]
        );
        $repeater->add_control(
			'icon_image',
			[
				'label' 		=> __( 'Image', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
				'condition'		=> [ 'chose_icon_style' => [ 'img' ] ],
			]
		);
        

        $this->add_control(
			'process2',
			[
				'label' 		=> __( 'Process', 'digalu' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' 		=> __( 'title', 'digalu' ),
					],
				],
				'title_field' 	=> '{{{ process_title }}}',
				'condition'		=> [ 'process_style' => [ '2','3', '4' ] ],
			]
		);
        $this->end_controls_section();

        //---------------------------------------Title Style---------------------------------------//

		$this->start_controls_section(
			'title_style',
			[
				'label' 	=> __( 'Title Style', 'appku' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' 		=> __( 'Title Color', 'appku' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} h4' => 'color: {{VALUE}}',
                ],
			]
        );
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'title_typography',
				'label' 	=> __( 'Title Typography', 'appku' ),
                'selector' 	=> '{{WRAPPER}} h4',
			]
        );
        $this->add_responsive_control(
			'title_margin',
			[
				'label' 		=> __( 'Title Margin', 'appku' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
        );

        $this->add_responsive_control(
			'title_padding',
			[
				'label' 		=> __( 'Title Padding', 'appku' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} h4' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);
		$this->end_controls_section();

		//---------------------------------------Number Style---------------------------------------//

		$this->start_controls_section(
			'con_style',
			[
				'label' 	=> __( 'Description Style', 'appku' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'number_color',
			[
				'label' 		=> __( 'Color', 'appku' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} p' => 'color: {{VALUE}}',
                ],
			]
        );
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'number_typography',
				'label' 	=> __( 'Typography', 'appku' ),
                'selector' 	=> '{{WRAPPER}} p',
			]
        );
        $this->add_responsive_control(
			'number_margin',
			[
				'label' 		=> __( 'Margin', 'appku' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
        );

        $this->add_responsive_control(
			'number_padding',
			[
				'label' 		=> __( 'Padding', 'appku' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);
		$this->end_controls_section();


	}

	protected function render() {

        $settings = $this->get_settings_for_display();

        if( $settings['process_style'] == '1' ){
	        echo '<div class="process-list-box">';
	        	$n = 100;
	            foreach( $settings['process'] as $single_data ) {  
	            	$n+=400; 
	            	if( $settings['show_animation'] == 'yes' ) {
			            echo '<div class="proces-style-two-list wow fadeInUp" data-wow-delay="'.esc_attr($n).'ms">';
			        }else{
			        	echo '<div class="proces-style-two-list">';
			        }
		            	if(!empty($single_data['process_title'])){
			                echo '<h4>'.esc_html($single_data['process_title']).'</h4>';
			            }
			            if(!empty($single_data['process_content'])){
			                echo '<p>'.esc_html($single_data['process_content']).'</p>';
			            }
		            echo '</div>';
		        }

	        echo '</div>';
	    }elseif( $settings['process_style'] == '2' ){
	    	echo '<div class="process-area text-center text-light">'; 
		    	echo '<div class="container">'; 
			    	echo '<div class="process-style-one-box">'; 
		                echo '<div class="row">'; 
		                	$i = 0;
		                    foreach( $settings['process2'] as $single_data ) { 
		                    	$i++;
		        				$k = str_pad($i, 2, '0', STR_PAD_LEFT);
			                    echo '<div class="col-lg-3 col-md-6 process-style-one">'; 
									if($i % 2 == 0){
									  	if(!empty($single_data['process_title'])){
									        echo '<h4>'.esc_html($single_data['process_title']).'</h4>';
									    }
									}
			                    	if($single_data['chose_icon_style'] == 'class' ){
		                            	echo '<div class="icon">';
		                            		echo wp_kses_post($single_data['icon_class']);
		                            		echo '<span>'.esc_html($k).'</span>'; 
		                            	echo '</div>';
		                            }else{
		                            	echo '<div class="icon">';
		                                	echo digalu_img_tag( array(
												'url'	=> esc_url( $single_data['icon_image']['url'] ),
											) );
											echo '<span>'.esc_html($k).'</span>'; 
										echo '</div>';
		                            }
		                            if($i % 2 !== 0){
									  	if(!empty($single_data['process_title'])){
									        echo '<h4>'.esc_html($single_data['process_title']).'</h4>';
									    }
									}
			                    echo '</div>';
			                }
		                echo '</div>'; 
		            echo '</div>'; 
	            echo '</div>'; 
            echo '</div>'; 
	    }elseif( $settings['process_style'] == '3' ){
	    	echo '<div class="process-area text-center text-light">';
		    	echo '<div class="container">';
			    	echo '<div class="process-style-one-box">';
		                echo '<div class="row">';
		                    $i = 0;
		                    foreach( $settings['process2'] as $single_data ) { 
		                    	$i++;
		        				$k = str_pad($i, 2, '0', STR_PAD_LEFT);
			                    echo '<div class="col-lg-3 col-md-6 process-style-one">';
			                    	if($single_data['chose_icon_style'] == 'class' ){
				                        echo '<div class="icon">';
				                            echo wp_kses_post($single_data['icon_class']);
				                            echo '<span>'.esc_html($k).'</span>'; 
				                        echo '</div>';
				                    }else{
				                    	echo '<div class="icon">';
		                                	echo digalu_img_tag( array(
												'url'	=> esc_url( $single_data['icon_image']['url'] ),
											) );
											echo '<span>'.esc_html($k).'</span>'; 
										echo '</div>';
				                    }
				                    if(!empty($single_data['process_title'])){
				                        echo '<h4>'.esc_html($single_data['process_title']).'</h4>';
				                    }
			                    echo '</div>';
			                }
		                echo '</div>';
		            echo '</div>';
	            echo '</div>';
            echo '</div>';
	    }else{
	    	echo '<div class="process-area text-center bg-cover default-padding-bottom">';
		        echo '<div class="container">';
		            echo '<div class="row">';
		                echo '<div class="col-lg-8 offset-lg-2">';
		                    echo '<div class="site-heading text-center">';
		                        if( ! empty( $settings['section_title'] ) ){
			                        echo '<h4 class="sub-title">' .esc_html( $settings['section_title'] ). '</h4>';
			                    }
			                    if( ! empty( $settings['section_subtitle'] ) ){
			                        echo '<h2 class="title">' .esc_html( $settings['section_subtitle'] ). '</h2>';
			                    }
		                        echo '<div class="devider"></div>';
		                    echo '</div>';
		                echo '</div>';
		            echo '</div>';
		        echo '</div>';
		        echo '<div class="container">';
		            echo '<div class="process-style-one-box style-two">';
		                echo '<div class="row">';
		                    echo '<!-- Single Item -->';
		                    $i = 0;
		                    foreach( $settings['process2'] as $single_data ) { 
		                    	$i++;
		        				$k = str_pad($i, 2, '0', STR_PAD_LEFT);

		        				$class = ( $i == 2 ) ? 'active' : '';
			                    echo '<div class="col-lg-4 col-md-6 process-style-one  '.esc_attr( $class ).'">';
			                        echo '<div class="icon">';
			                            if($single_data['chose_icon_style'] == 'class' ){
		                            		echo wp_kses_post($single_data['icon_class']);
		                            		echo '<span>'.esc_html($k).'</span>'; 
			                            }else{
		                                	echo digalu_img_tag( array(
												'url'	=> esc_url( $single_data['icon_image']['url'] ),
											) );
											echo '<span>'.esc_html($k).'</span>'; 
			                            }
			                        echo '</div>';
			                        if(!empty($single_data['process_title'])){
				                        echo '<h4>'.esc_html($single_data['process_title']).'</h4>';
				                    }
			                    echo '</div>';
			                }
		                    
		                echo '</div>';
		            echo '</div>';
		        echo '</div>';
		    echo '</div>';
	    }
	}
}