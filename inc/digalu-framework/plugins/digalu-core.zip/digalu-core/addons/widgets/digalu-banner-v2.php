<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Group_Control_Border;
/**
 *
 * Banner Widget .
 *
 */
class Digalu_Banner_V2 extends Widget_Base {

	public function get_name() {
		return 'digalubannerv2';
	}

	public function get_title() {
		return __( 'Banner V2', 'digalu' );
	}

	public function get_icon() {
		return 'vt-icon';
    }

	public function get_categories() {
		return [ 'digalu_header_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'Banner_section',
			[
				'label' 	=> __( 'Banner', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

		$this->add_control(
			'banner_style',
			[
				'label' 		=> __( 'Banner Style', 'digalu' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> '1',
				'options' 		=> [
					'1'  		=> __( 'Style One', 'digalu' ),
					'2' 		=> __( 'Style Two', 'digalu' ),
				],
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'banner_image',
			[
				'label' 		=> __( 'Banner Image', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'default' 		=> [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'banner_image2',
			[
				'label' 		=> __( 'Banner Image 2', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'default' 		=> [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		
		$repeater->add_control(
			'heading',
			[
				'label' 	=> __( 'Heading', 'digalu' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default'  	=> __( 'Grow business by', 'digalu' ),
			]
        );
        $repeater->add_control(
			'title',
			[
				'label' 	=> __( 'Title', 'digalu' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default'  	=> __( 'Award winning digital marketing agency ', 'digalu' )
			]
        );
       

        $repeater->add_control(
			'button_text',
			[
				'label' 	=> __( 'Button Text', 'digalu' ),
                'type' 		=> Controls_Manager::TEXT,
                'default'  	=> __( 'Button Text', 'digalu' ),
			]
        );

        $repeater->add_control(
			'button_link',
			[
				'label' 		=> __( 'Link', 'digalu' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __( 'https://your-link.com', 'digalu' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
			]
		);
		 $this->add_control(
			'banners',
			[
				'label' 		=> __( 'Banners', 'digalu' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'heading' 		=> __( 'title', 'digalu' ),
					],
				],
				'title_field' 	=> '{{{ heading }}}',
			]
		);

		$this->add_control(
			'shape_image',
			[
				'label' 		=> __( 'Shape Image', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'default' 		=> [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition'		=> [ 'banner_style' => '2' ],
			]
		);
		$this->add_control(
			'shape_image2',
			[
				'label' 		=> __( 'Shape Image 2', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'default' 		=> [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition'		=> [ 'banner_style' => '2' ],
			]
		);

		
		

        $this->end_controls_section();
       //---------------------------------------Title Style---------------------------------------//

		$this->start_controls_section(
			'title_style',
			[
				'label' 	=> __( 'Title Style', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' 		=> __( 'Title Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} h2' => 'color: {{VALUE}}',
                ],
			]
        );
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'title_typography',
				'label' 	=> __( 'Title Typography', 'digalu' ),
                'selector' 	=> '{{WRAPPER}} h2',
			]
        );
        $this->add_responsive_control(
			'title_margin',
			[
				'label' 		=> __( 'Title Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
        );

        $this->add_responsive_control(
			'title_padding',
			[
				'label' 		=> __( 'Title Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);
		$this->end_controls_section();

		//---------------------------------------subTitle Style---------------------------------------//

		$this->start_controls_section(
			'subtitle_style',
			[
				'label' 	=> __( 'Subtitle Style', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'subtitle_color',
			[
				'label' 		=> __( 'Subtitle Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} h4' => 'color: {{VALUE}}',
                ],
			]
        );
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'subtitle_typography',
				'label' 	=> __( 'Subtitle Typography', 'digalu' ),
                'selector' 	=> '{{WRAPPER}} h4',
			]
        );
        $this->add_responsive_control(
			'subtitle_margin',
			[
				'label' 		=> __( 'Subtitle Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
        );

        $this->add_responsive_control(
			'subtitle_padding',
			[
				'label' 		=> __( 'Subtitle Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} h4' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);
		$this->end_controls_section();


		//---------------------------------------Button Style---------------------------------------//

		$this->start_controls_section(
			'button_style_section',
			[
				'label' 	=> __( 'Button Style 1', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
        );

        $this->add_control(
			'button_color',
			[
				'label' 		=> __( 'Text Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .btn.btn-theme.secondary' => '--white: {{VALUE}}',
                ],
			]
        );

        $this->add_control(
			'button_color_hover',
			[
				'label' 		=> __( 'Text Color Hover', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .text-light .btn.btn-theme.secondary:hover' => '--color-heading: {{VALUE}}!important;',
                ],
			]
        );

        $this->add_control(
			'button_bg_color',
			[
				'label' 		=> __( 'Background Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .text-light .btn.btn-theme.secondary' => '--color-optional:{{VALUE}}',
                ],
			]
        );

        $this->add_control(
			'button_bg_hover_color',
			[
				'label' 		=> __( 'Background Hover Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .text-light .btn.btn-theme.secondary::after' => '--white:{{VALUE}}',
                ],
			]
        );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'border',
				'label' 	=> __( 'Border', 'digalu' ),
                'selector' 	=> '{{WRAPPER}} .btn.btn-light.effect',
			]
		);

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'border_hover',
				'label' 	=> __( 'Border Hover', 'digalu' ),
                'selector' 	=> '{{WRAPPER}} .btn.btn-light.effect:hover',
			]
		);

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'button_typography',
				'label' 	=> __( 'Button Typography', 'digalu' ),
                'selector' 	=> '{{WRAPPER}} .btn.btn-light.effect',
			]
        );

        $this->add_responsive_control(
			'button_margin',
			[
				'label' 		=> __( 'Button Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .btn.btn-light.effect' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
        );

        $this->add_responsive_control(
			'button_padding',
			[
				'label' 		=> __( 'Button Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .btn.btn-light.effect' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);
        $this->add_responsive_control(
			'button_border_radius',
			[
				'label' 		=> __( 'Button Border Radius', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .btn.btn-light.effect' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_shadow',
				'label' => esc_html__( 'Button Shadow', 'digalu' ),
				'selector' => '{{WRAPPER}} .btn.btn-light.effect',
			]
		);
        $this->end_controls_section();

		
    }

	protected function render() {

        $settings = $this->get_settings_for_display();

		if( $settings['banner_style'] == '1' ){
			echo '<div class="banner-area banner-business text-center navigation-circle zoom-effect overflow-hidden text-light">';
		        echo '<!-- Slider main container -->';
		        echo '<div class="banner-fade">';
		            echo '<!-- Additional required wrapper -->';
		            echo '<div class="swiper-wrapper">';
		                
		            	foreach( $settings['banners'] as $single_data ) {  
			                echo '<!-- Single Item -->';
			                echo '<div class="swiper-slide banner-style-business">';
			                	if( ! empty( $single_data['banner_image']['url'] ) ){
				                    echo '<div class="banner-thumb bg-cover" style="background: url('.esc_url( $single_data['banner_image']['url'] ).');"></div>';
				                }

			                    echo '<div class="container">';
			                        echo '<div class="row align-center">';
			                            echo '<div class="col-lg-8 offset-lg-2">';
			                                echo '<div class="content">';
			                                    if(!empty($single_data['heading'])){
													echo '<h4>'.esc_html($single_data['heading']).'</h4>';
												}
			                                    if(!empty($single_data['title'])){
													echo '<h2>'.wp_kses_post($single_data['title']).'</h2>';
												}
												if( ! empty( $single_data['button_text'] ) ) {
							                    	if( ! empty( $single_data['button_link']['url'] ) ) {
											            $this->add_render_attribute( 'button', 'href', esc_url( $single_data['button_link']['url'] ) );
											        }
								            		if( ! empty( $single_data['button_link']['nofollow'] ) ) {
											            $this->add_render_attribute( 'button', 'rel', 'nofollow' );
											        }
											        if( ! empty( $single_data['button_link']['is_external'] ) ) {
											            $this->add_render_attribute( 'button', 'target', '_blank' );
											        }
											        $this->add_render_attribute( 'button', 'class', 'btn btn-md btn-light animation' );

							                        echo '<div class="button"><a '.$this->get_render_attribute_string('button').'>'.esc_html( $single_data['button_text'] ).'</a></div>';
							                    }
			                                echo '</div>';
			                            echo '</div>';
			                        echo '</div>';
			                    echo '</div>';
			                    if( ! empty( $single_data['banner_image2']['url'] ) ){
				                    echo '<!-- Shape -->';
				                    echo '<div class="banner-shape-bg">';
				                        echo digalu_img_tag( array(
											'url'	=> esc_url( $single_data['banner_image2']['url'] ),
										) );
				                    echo '</div>';
				                    echo '<!-- End Shape -->';
				                }
			                echo '</div>';
			                echo '<!-- End Single Item -->';
			            }
		            echo '</div>';

		            echo '<!-- Navigation -->';
		            echo '<div class="swiper-button-prev"></div>';
		            echo '<div class="swiper-button-next"></div>';

		        echo '</div>  ';
		    echo '</div>';
		}else{
			$shape_image = $settings['shape_image']['url'] ?  $settings['shape_image']['url'] : '#';
			$shape_image2 = $settings['shape_image2']['url'] ?  $settings['shape_image2']['url'] : '#';


			echo '<div class="banner-area auto-height bg-cover double-items bottom-thumb banner-style-six-area bg-gray navigation-circle" style="background-image: url('.esc_url( $shape_image ).');">';
		        echo '<div class="banner-shape-six" style="background-image: url('.esc_url( $shape_image2 ).');"></div>';
		        echo '<!-- Slider main container -->';
		        echo '<div class="banner-fade">';
		            echo '<!-- Additional required wrapper -->';
		            echo '<div class="swiper-wrapper">';
		                
		            	foreach( $settings['banners'] as $single_data ) {  
			                echo '<!-- Single Item -->';
			                echo '<div class="swiper-slide banner-style-six">';
			                    echo '<div class="container">';
			                        echo '<div class="row align-center">';
			                            echo '<div class="col-lg-7">';
			                                echo '<div class="content">';
			                                    if(!empty($single_data['heading'])){
													echo '<h4>'.esc_html($single_data['heading']).'</h4>';
												}
			                                    if(!empty($single_data['title'])){
													echo '<h2>'.wp_kses_post($single_data['title']).'</h2>';
												}
			                                    if( ! empty( $single_data['button_text'] ) ) {
							                    	if( ! empty( $single_data['button_link']['url'] ) ) {
											            $this->add_render_attribute( 'button', 'href', esc_url( $single_data['button_link']['url'] ) );
											        }
								            		if( ! empty( $single_data['button_link']['nofollow'] ) ) {
											            $this->add_render_attribute( 'button', 'rel', 'nofollow' );
											        }
											        if( ! empty( $single_data['button_link']['is_external'] ) ) {
											            $this->add_render_attribute( 'button', 'target', '_blank' );
											        }
											        $this->add_render_attribute( 'button', 'class', 'btn btn-md btn-gradient animation' );

							                        echo '<div class="button"><a '.$this->get_render_attribute_string('button').'>'.esc_html( $single_data['button_text'] ).'</a></div>';
							                    }
			                                echo '</div>';
			                            echo '</div>';
			                            if( ! empty( $single_data['banner_image']['url'] ) ){
				                            echo '<div class="col-lg-5">';
				                                echo '<div class="thumb">';
				                                    echo digalu_img_tag( array(
														'url'	=> esc_url( $single_data['banner_image']['url'] ),
													) );
				                                echo '</div>';
				                            echo '</div>';
				                        }
			                        echo '</div>';
			                    echo '</div>';
			                echo '</div>';
			                echo '<!-- End Single Item -->';
			            }
		                
		            echo '</div>';

		            echo '<!-- Navigation -->';
		            echo '<div class="swiper-button-prev"></div>';
		            echo '<div class="swiper-button-next"></div>';

		        echo '</div>  ';
		    echo '</div>';
		}
	}
}