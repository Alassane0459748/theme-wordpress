<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Repeater;
use \Elementor\Group_Control_Border;
/**
 *
 * Team Widget .
 *
 */
class Digalu_Team extends Widget_Base {

	public function get_name() {
		return 'digaluteam';
	}

	public function get_title() {
		return __( 'Digalu Team', 'digalu' );
	}

	public function get_icon() {
		return 'vt-icon';
    }

	public function get_categories() {
		return [ 'digalu' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'features_section',
			[
				'label'     => __( 'Team', 'digalu' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'team_style',
			[
				'label' 	=> __( 'Team Style', 'digalu' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '1',
				'options' 	=> [
					'1'  		=> __( 'Style One', 'digalu' ),
					'2' 		=> __( 'Style Two', 'digalu' ),
					'3' 		=> __( 'Style Three', 'digalu' ),
				],
			]
		);
        //----------------------------feddback repeter start--------------------------------//
		$this->add_control(
			'image',
			[
				'label' 		=> __( 'Image', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'name', [
				'label' 		=> __( 'Name', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Rubaida Kanom' , 'digalu' ),
				'label_block' 	=> true,
			]
        );
        $this->add_control(
			'designation', [
				'label' 		=> __( 'Designation', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Rubaida Kanom' , 'digalu' ),
				'label_block' 	=> true,
			]
        );
        $this->add_control(
			'details_page', [
				'label' 		=> __( 'Details Page URL', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( '#' , 'digalu' ),
				'label_block' 	=> true,
			]
        );
        $this->add_control(
			'shape',
			[
				'label' 		=> __( 'Shape', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'condition'		=> [ 
					'team_style' => [ '1', '2' ],
				],
				
			]
		);

        $repeater = new Repeater();

		$repeater->add_control(
			'social_icon',
			[
				'label' 	=> __( 'Social Icon', 'digalu' ),
				'type' 		=> Controls_Manager::ICONS,
				'default' 	=> [
					'value' 	=> 'fab fa-facebook-f',
					'library' 	=> 'solid',
				],
			]
		);

		$repeater->add_control(
			'icon_link',
			[
				'label' 		=> __( 'Link', 'digalu' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __( 'https://your-link.com', 'digalu' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> true,
					'nofollow' 		=> true,
				],
			]
		);

		$this->add_control(

			'social_icon_list',
			[
				'label' 		=> __( 'Social Icon', 'digalu' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'social_icon' => __( 'Add Social Icon','digalu' ),
					],
				],
				'title_field' 	=> '{{{ social_icon.value }}}',
				'condition'		=> [ 
					'team_style' => [ '2', '3' ],
				],
			]
		);

		$this->end_controls_section();

		
        /*-----------------------------------------Feedback styling------------------------------------*/

		$this->start_controls_section(
			'overview_con_styling',
			[
				'label' 	=> __( 'Team Styling', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
        );
        $this->start_controls_tabs(
			'style_tabs2'
		);


		$this->start_controls_tab(
			'style_normal_tab2',
			[
				'label' => esc_html__( 'Name', 'digalu' ),
			]
		);
        $this->add_control(
			'overview_title_color',
			[
				'label' 		=> __( 'Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} a'	=> 'color: {{VALUE}}!important;',
				],
			]
        );
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'overview_title_typography',
		 		'label' 		=> __( 'Typography', 'digalu' ),
		 		'selector' 	=> '{{WRAPPER}} a',
			]
		);

        $this->add_responsive_control(
			'overview_title_margin',
			[
				'label' 		=> __( 'Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'overview_title_padding',
			[
				'label' 		=> __( 'Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );
		$this->end_controls_tab();

		//--------------------secound--------------------//

		$this->start_controls_tab(
			'style_hover_tab2',
			[
				'label' => esc_html__( 'Designation', 'digalu' ),
			]
		);
		$this->add_control(
			'overview_content_color',
			[
				'label' 		=> __( 'Color', 'digalu' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} span'	=> 'color: {{VALUE}}!important;',
				],
			]
        );
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'overview_content_typography',
		 		'label' 		=> __( 'Typography', 'digalu' ),
		 		'selector' 	=> '{{WRAPPER}} span',
			]
		);

        $this->add_responsive_control(
			'overview_content_margin',
			[
				'label' 		=> __( 'Margin', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'overview_content_padding',
			[
				'label' 		=> __( 'Padding', 'digalu' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

		$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();
    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        echo '<!------------------------------- Team Area start ------------------------------->';

        $url = $settings['details_page'] ;
		if(!empty($url)){
			$url_start_tag 	= '<a href="'.esc_url($url).'">';
			$url_end_tag 	= '</a>';
		}else{
			$url_start_tag 	= '';
			$url_end_tag 	= '';
		}
		if( $settings['team_style'] == '1' ){
	        echo '<div class="team-style-one-area">';
		        echo '<div class="team-style-one-item">';
		        	if( ! empty( $settings['image']['url'] ) ){
			            echo '<div class="thumb">';
			                echo digalu_img_tag( array(
								'url'	=> esc_url( $settings['image']['url'] ),
							) );
			            echo '</div>';
			        }
		            echo '<div class="info">';
		            	if(!empty($settings['name'])){
			                echo '<h4>'.$url_start_tag.esc_html($settings['name']).$url_end_tag.'</h4>';
			            }
			            if(!empty($settings['designation'])){
			                echo '<span>'.esc_html($settings['designation']).'</span>';
			            }
		            echo '</div>';
		        echo '</div>';
	        echo '</div>';
	    }elseif( $settings['team_style'] == '2' ){
	    	echo '<div class="team-style-one">';
	    		if( ! empty( $settings['shape']['url'] ) ){
		            echo '<div class="team-style-one-item" style="background-image: url('.esc_url( $settings['shape']['url'] ).');">';
		        }else{
		        	echo '<div class="team-style-one-item">';
		        }
	                echo '<div class="thumb">';
	                	if( ! empty( $settings['image']['url'] ) ){
		                    echo digalu_img_tag( array(
								'url'	=> esc_url( $settings['image']['url'] ),
							) );
		                }
	                    echo '<div class="social">';
	                        foreach( $settings['social_icon_list'] as $social_icon ){
	                          	$social_target    = $social_icon['icon_link']['is_external'] ? ' target="_blank"' : '';
	                          	$social_nofollow  = $social_icon['icon_link']['nofollow'] ? ' rel="nofollow"' : '';

	                            echo '<a '.wp_kses_post( $social_target.$social_nofollow ).' href="'.esc_url( $social_icon['icon_link']['url'] ).'">';

	                            \Elementor\Icons_Manager::render_icon( $social_icon['social_icon'], [ 'aria-hidden' => 'true' ] );

	                          	echo '</a> ';
	                      	}
	                    echo '</div>';
	                echo '</div>';
	                echo '<div class="info">';
	                    if(!empty($settings['name'])){
			                echo '<h4>'.$url_start_tag.esc_html($settings['name']).$url_end_tag.'</h4>';
			            }
			            if(!empty($settings['designation'])){
			                echo '<span>'.esc_html($settings['designation']).'</span>';
			            }
	                echo '</div>';
	            echo '</div>';
	        echo '</div>';
	    }else{
	    	echo '<div class="team-style-two-area">';
		    	echo '<div class="team-style-two">';
	                echo '<div class="thumb">';
	                    if( ! empty( $settings['image']['url'] ) ){
		                    echo digalu_img_tag( array(
								'url'	=> esc_url( $settings['image']['url'] ),
							) );
		                }
	                    foreach( $settings['social_icon_list'] as $social_icon ){
                          	$social_target    = $social_icon['icon_link']['is_external'] ? ' target="_blank"' : '';
                          	$social_nofollow  = $social_icon['icon_link']['nofollow'] ? ' rel="nofollow"' : '';

                            echo '<a '.wp_kses_post( $social_target.$social_nofollow ).' href="'.esc_url( $social_icon['icon_link']['url'] ).'">';

                            \Elementor\Icons_Manager::render_icon( $social_icon['social_icon'], [ 'aria-hidden' => 'true' ] );

                          	echo '</a> ';
                      	}
	                    
	                echo '</div>';
	                echo '<div class="info">';
	                    if(!empty($settings['designation'])){
			                echo '<span>'.esc_html($settings['designation']).'</span>';
			            }
	                    if(!empty($settings['name'])){
			                echo '<h4>'.$url_start_tag.esc_html($settings['name']).$url_end_tag.'</h4>';
			            }
	                echo '</div>';
	            echo '</div>';
            echo '</div>';
	    }
		echo '<!--------------------------------- Team Area end --------------------------------->';
	}
}