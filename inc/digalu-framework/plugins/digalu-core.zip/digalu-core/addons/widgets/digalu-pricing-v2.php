<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * pricing Plan Widget .
 *
 */
class Digalu_Pricing_Plan_v2 extends Widget_Base {

	public function get_name() {
		return 'digalupricingplanv2';
	}

	public function get_title() {
		return __( 'Pricing Table V2', 'digalu' );
	}


	public function get_icon() {
		return 'vt-icon';
    }


	public function get_categories() {
		return [ 'digalu' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'pricing_section',
			[
				'label' 	=> __( 'Pricing Table', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

		$this->add_control(
			'show_section_heading',
			[
				'label' 		=> __( 'Show SSection Header?', 'digalu' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Show', 'digalu' ),
				'label_off' 	=> __( 'Hide', 'digalu' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);

		$this->add_control(
			'title',
			[
				'label'     	=> __( 'Title', 'digalu' ),
                'type'      	=> Controls_Manager::TEXTAREA,
                'rows' 			=> 2,
                'default' 		=>  __( 'This is title area', 'digalu'),
                'condition'		=> [ 'show_section_heading' => 'yes'  ],
			]
        );
        $this->add_control(
			'subtitle',
			[
				'label'     	=> __( 'Subtitle', 'digalu' ),
                'type'      	=> Controls_Manager::TEXTAREA,
                'rows' 			=> 2,
                'default' 		=>  __( 'This is subtitle area', 'digalu'),
                'condition'		=> [ 'show_section_heading' => 'yes'  ],
			]
        );
		
        $repeater = new Repeater();

		$repeater->add_control(
			'package', [
				'label' 		=> __( 'Package', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Trial Version' , 'digalu' ),
				'label_block' 	=> true,
			]
        );
        $repeater->add_control(
			'icon', [
				'label' 		=> __( 'Icon', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'label_block' 	=> true,
			]
        );
        $repeater->add_control(
			'plan', [
				'label' 		=> __( 'Pricing Plan', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( '<sup>$</sup>0 <sub>/ Monthly</sub>' , 'digalu' ),
				'label_block' 	=> true,
			]
        );
        $repeater->add_control(
			'features', [
				'label' 		=> __( 'Features', 'digalu' ),
				'type' 			=> Controls_Manager::WYSIWYG,
				'default' 		=> __( 'Rubaida Kanom' , 'digalu' ),
				'label_block' 	=> true,
			]
        );
        $repeater->add_control(
			'button_text',
			[
				'label' 	=> __( 'Button Text', 'digalu' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default'  	=> __( 'Button Text', 'digalu' )
			]
        );
        $repeater->add_control(
			'button_link',
			[
				'label' 		=> __( 'Link', 'digalu' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'placeholder' 	=> __( 'https://your-link.com', 'digalu' ),
			]
		);
		$repeater->add_control(
			'make_it_active',
			[
				'label' 		=> __( 'Make it Active ?', 'digalu' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Show', 'digalu' ),
				'label_off' 	=> __( 'Hide', 'digalu' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);
		$this->add_control(
			'plans3',
			[
				'label' 		=> __( 'Plans', 'digalu' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'package' 		=> __( 'Marketing Strategy', 'digalu' ),
					],
				],
				'title_field' 	=> '{{{ package }}}',
			]
		);

		$this->end_controls_section();


	}

	protected function render() {

        $settings = $this->get_settings_for_display();

        echo '<div class="pricing-style-two-area default-padding bottom-less">';

	        if( $settings['show_section_heading'] == 'yes' ) {
	        	echo '<div class="container">';
		            echo '<div class="row">';
		                echo '<div class="col-lg-8 offset-lg-2">';
		                    echo '<div class="site-heading text-center">';
		                    	if( ! empty( $settings['title'] ) ){
			                        echo '<h5 class="sub-title">'.esc_html( $settings['title'] ).'</h5>';
			                    }
			                    if( ! empty( $settings['subtitle'] ) ){
			                        echo '<h2 class="title">'.wp_kses_post( $settings['subtitle'] ).'</h2>';
			                    }
		                    echo '</div>';
		                echo '</div>';
		            echo '</div>';
		        echo '</div>';
		    }

	        echo '<div class="container">';
	            echo '<div class="row">';
	                foreach( $settings['plans3'] as $data ) { 
            			if( $data['make_it_active'] == 'yes' ){
				    		$active_class = 'active';
				    		$btn_class = 'btn mt-20 btn-md btn-gradient effect circle';
				    	}else{
				    		$active_class = '';
				    		$btn_class = 'btn mt-20 btn-md btn-border-dark animation circle';
				    	}

		                echo '<!-- Single Itme -->';
		                echo '<div class="col-xl-4 col-md-6 mb-30">';
		                    echo '<div class="pricing-style-two '.esc_attr( $active_class ).'">';
		                        echo '<div class="pricing-header">';
		                            if(!empty($data['icon'])){
		                                echo wp_kses_post($data['icon']);
		                            }
		                            if(!empty($data['package'])){
		                                echo '<h4>'.wp_kses_post($data['package']).'</h4>';
		                            }
		                        echo '</div>';
		                        echo '<div class="pricing-content">';
		                            
		                        	if(!empty($data['features'])){
		                                echo wp_kses_post($data['features']);
		                            }

		                            echo '<div class="price">';
		                                if(!empty($data['plan'])){
			                                echo '<h2>'.wp_kses_post($data['plan']).'</h2>';
			                            }
		                            echo '</div>';
		                            if(!empty($data['button_text'])){
		                                echo '<a class="'.esc_attr( $btn_class ).'" href="'.esc_url( $data['button_link'] ).'">'.esc_html( $data['button_text'] ).'</a>';
		                            }
		                        echo '</div>';
		                    echo '</div>';
		                echo '</div>';
		                echo '<!-- End Single Itme -->';
		            }

	                
	            echo '</div>';
	        echo '</div>';
	    echo '</div>';
	}
}