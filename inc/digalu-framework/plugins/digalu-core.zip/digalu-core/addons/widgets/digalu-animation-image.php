<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
/**
 *
 * Image Widget .
 *
 */
class Digalu_Animated_Image extends Widget_Base {

	public function get_name() {
		return 'digalushapeimage';
	}

	public function get_title() {
		return __( 'Digalu BG Shape', 'digalu' );
	}


	public function get_icon() {
		return 'vt-icon';
    }


	public function get_categories() {
		return [ 'digalu' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'image_section',
			[
				'label' 	=> __( 'Shape For BG', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'image',
			[
				'label' 		=> __( 'Choose Image', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name' 			=> 'image', // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `image_size` and `image_custom_dimension`.
				'default' 		=> 'large',
				'separator' 	=> 'none',
			]
		);

        $this->add_responsive_control(
			'image_align',
			[
				'label' 		=> __( 'Alignment', 'digalu' ),
				'type' 			=> Controls_Manager::CHOOSE,
				'options' 		=> [
					'left' 	=> [
						'title' 		=> __( 'Left', 'digalu' ),
						'icon' 			=> 'eicon-text-align-left',
					],
					'center' 	=> [
						'title' 		=> __( 'Center', 'digalu' ),
						'icon' 			=> 'eicon-text-align-center',
					],
					'right' 	=> [
						'title' 		=> __( 'Right', 'digalu' ),
						'icon' 			=> 'eicon-text-align-right',
					],
				],
				'default' 	=> 'left',
				'toggle' 	=> true,
				'selectors' => [
					'{{WRAPPER}} .bg-position' => 'text-align: {{VALUE}};',
				],
			]
        );
        $this->add_responsive_control(
			'width',
			[
				'label' 	=> __( 'Width', 'digalu' ),
				'type' 		=> Controls_Manager::SLIDER,
				'default' 	=> [
					'unit' 		=> '%',
				],
				'tablet_default' => [
					'unit' => '%',
				],
				'mobile_default' => [
					'unit' => '%',
				],
				'size_units' => [ '%', 'px', 'vw' ],
				'range' => [
					'%' => [
						'min' => 1,
						'max' => 100,
					],
					'px' => [
						'min' => 1,
						'max' => 1000,
					],
					'vw' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .bg-position img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'space',
			[
				'label' 	=> __( 'Max Width', 'digalu' ) . ' (%)',
				'type' 		=> Controls_Manager::SLIDER,
				'default' 	=> [
					'unit' 		=> '%',
				],
				'tablet_default' => [
					'unit' => '%',
				],
				'mobile_default' => [
					'unit' => '%',
				],
				'size_units' => [ '%' ],
				'range' => [
					'%' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .bg-position img' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'height',
			[
				'label' 	=> __( 'Height', 'digalu' ),
				'type' 		=> Controls_Manager::SLIDER,
				'default' 	=> [
					'unit' 		=> '%',
				],
				'tablet_default' => [
					'unit' => '%',
				],
				'mobile_default' => [
					'unit' => '%',
				],
				'size_units' => [ '%', 'px', 'vw' ],
				'range' => [
					'%' => [
						'min' => 1,
						'max' => 100,
					],
					'px' => [
						'min' => 1,
						'max' => 1000,
					],
					'vw' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .bg-position img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();
        /*----------------------------------------- styling------------------------------------*/

		$this->start_controls_section(
			'style_section',
			[
				'label' 	=> __( 'Style', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
        );

        $this->add_control(
			'digalu_position',
			[
				'label' 	=> __( 'Position', 'digalu' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'absolute',
				'options' 	=> [
					'static'  		=> __( 'Static', 'digalu' ),
					'relative' 		=> __( 'Relative', 'digalu' ),
					'fixed' 		=> __( 'Fixed', 'digalu' ),
					'absolute' 		=> __( 'Absolute', 'digalu' ),
					'sticky' 		=> __( 'Sticky', 'digalu' ),
				],
				'selectors' 	=> [
					'{{WRAPPER}} .bg-position'	=> 'position: {{VALUE}}!important;',
				],
			]
		);

		$this->add_control(
			'digalu_bg_size',
			[
				'label' 	=> __( 'Background Size', 'digalu' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'absolute',
				'options' 	=> [
					'auto'  		=> __( 'Auto', 'digalu' ),
					'contain' 		=> __( 'Contain', 'digalu' ),
					'cover' 		=> __( 'Cover', 'digalu' ),
					'inherit' 		=> __( 'Inherit', 'digalu' ),
					'initial' 		=> __( 'Initial', 'digalu' ),
					'revert' 		=> __( 'Revert', 'digalu' ),
					'revert-layer' 		=> __( 'Revert Layer', 'digalu' ),
					'unset' 		=> __( 'Unset', 'digalu' ),
				],
				'selectors' 	=> [
					'{{WRAPPER}} .bg-position'	=> 'background-size: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'digalu_repeat',
			[
				'label' 	=> __( 'Background Repeat', 'digalu' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'absolute',
				'options' 	=> [
					'repet'  		=> __( 'Repeat', 'digalu' ),
					'no-repeat'  		=> __( 'No Repeat', 'digalu' ),

				],
				'selectors' 	=> [
					'{{WRAPPER}} .bg-position'	=> 'background-repeat: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'digalu_bg_position',
			[
				'label' 	=> __( 'Background Position', 'digalu' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> 'absolute',
				'options' 	=> [
					'left top'  		=> __( 'left top', 'digalu' ),
					'left center'  		=> __( 'left center', 'digalu' ),
					'left bottom'  		=> __( 'left bottom', 'digalu' ),
					'right top'  		=> __( 'right top', 'digalu' ),
					'right center'  		=> __( 'right center', 'digalu' ),
					'right botom'  		=> __( 'right botom', 'digalu' ),
					'center top'  		=> __( 'center top', 'digalu' ),
					'center center'  		=> __( 'center center', 'digalu' ),
					'center bottom'  		=> __( 'center bottom', 'digalu' ),

				],
				'selectors' 	=> [
					'{{WRAPPER}} .bg-position'	=> 'background-position: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'opacity__1',
			[
				'label' 		=> __( 'Opacity', 'digalu' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' 	=> [
					'{{WRAPPER}} .bg-position'	=> 'opacity: {{SIZE}};',
				],
			]
		);
		$this->add_responsive_control(
			'from_top',
			[
				'label' 		=> __( 'Top', 'digalu' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' 	=> [
					'{{WRAPPER}} .bg-position'	=> 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'from_left',
			[
				'label' 		=> __( 'Left', 'digalu' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' 	=> [
					'{{WRAPPER}} .bg-position'	=> 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'from_right',
			[
				'label' 		=> __( 'Right', 'digalu' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' 	=> [
					'{{WRAPPER}} .bg-position'	=> 'right: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'from_bottom',
			[
				'label' 		=> __( 'Bottom', 'digalu' ),
				'type' 			=> Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' 	=> [
					'{{WRAPPER}} .bg-position'	=> 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
        $this->end_controls_section();
	}

	protected function render() {

        $settings = $this->get_settings_for_display();

        $this->add_render_attribute('wrapper','class','bg-position');
        // $this->add_render_attribute('wrapper','class', $settings['effect_style']);



        if( !empty( $settings['image']['id'] ) ) {
            echo '<!-- Image -->';

            echo '<div '.$this->get_render_attribute_string('wrapper').'>';
	            echo '<img src="'.esc_url( $settings['image']['url']).'" alt="'.esc_html( get_bloginfo('name') ).'">';
	        echo '</div>';
            echo '<!-- End Image -->';
        }
	}
}