<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Repeater;
/**
 *
 * Rating Box Widget .
 *
 */
class Digalu_Rating_Box extends Widget_Base {

	public function get_name() {
		return 'digalurating';
	}

	public function get_title() {
		return __( 'Digalu Rating Box', 'digalu' );
	}


	public function get_icon() {
		return 'vt-icon';
    }


	public function get_categories() {
		return [ 'digalu' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'client_logo_section',
			[
				'label' 	=> __( 'Rating Box', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );
		$this->add_control(
			'gallery',
			[
				'label' => esc_html__( 'Add Image', 'digalu' ),
				'type' => \Elementor\Controls_Manager::GALLERY,
				'default' => [],
			]
		);
		$this->add_control(
			'client_rating',
			[
				'label' 	=> __( 'Client Rating', 'digalu' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '5',
				'options' 	=> [
					'one'  		=> __( 'One Star', 'digalu' ),
					'two' 		=> __( 'Two Star', 'digalu' ),
					'three' 	=> __( 'Three Star', 'digalu' ),
					'four' 		=> __( 'Four Star', 'digalu' ),
					'five' 	 	=> __( 'Five Star', 'digalu' ),
				],
			]
		);
		$this->add_control(
			'rating_number',
			[
				'label' 	=> __( 'Rating Number', 'diglau' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default'  	=> __( '(4.8/5)', 'diglau' ),
			]
        );
        $this->add_control(
			'rating_count',
			[
				'label' 	=> __( 'Rating Count', 'diglau' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                'default'  	=> __( 'Based on 1,258 reviews', 'diglau' ),
			]
        );
        $this->end_controls_section();

        
		



	}

	protected function render() {

        $settings = $this->get_settings_for_display();

        echo '<!-----------------------Start partner Logo Slider----------------------->';

        echo '<div class="rating-provider">';
        	if( isArray( $settings['gallery'] ) ){
	            foreach( $settings['gallery'] as $singlelogo ) {
	                echo '<div class="thumb">';
	                    echo digalu_img_tag( array(
	                        'url'   => esc_url( $singlelogo['url'] )
	                    ) );
	                echo '</div>';
	            } 
	        }
            echo '<div class="ratings">';
                echo '<div class="rating-icon">';
                    if( $settings['client_rating'] == 'one' ){
	                	echo '<i class="fas fa-star"></i>';
		                echo '<i class="far fa-star"></i>';
		                echo '<i class="far fa-star"></i>';
		                echo '<i class="far fa-star"></i>';
		                echo '<i class="far fa-star"></i>';
	                }elseif( $settings['client_rating'] == 'two' ){
	                	echo '<i class="fas fa-star"></i>';
		                echo '<i class="fas fa-star"></i>';
		                echo '<i class="far fa-star"></i>';
		                echo '<i class="far fa-star"></i>';
		                echo '<i class="far fa-star"></i>';
	                }elseif( $settings['client_rating'] == 'three' ){
	                	echo '<i class="fas fa-star"></i>';
		                echo '<i class="fas fa-star"></i>';
		                echo '<i class="fas fa-star"></i>';
		                echo '<i class="far fa-star"></i>';
		                echo '<i class="far fa-star"></i>';
	                }elseif( $settings['client_rating'] == 'four' ){
	                	echo '<i class="fas fa-star"></i>';
		                echo '<i class="fas fa-star"></i>';
		                echo '<i class="fas fa-star"></i>';
		                echo '<i class="fas fa-star"></i>';
		                echo '<i class="far fa-star"></i>';
	                }else{
	                	echo '<i class="fas fa-star"></i>';
		                echo '<i class="fas fa-star"></i>';
		                echo '<i class="fas fa-star"></i>';
		                echo '<i class="fas fa-star"></i>';
		                echo '<i class="fas fa-star"></i>';
	                }
	                if(!empty($settings['rating_count'])){
	                    echo '<h4>'.esc_html($settings['rating_count']).'</h4>';
	                }
                echo '</div>';
                if(!empty($settings['rating_number'])){
	                echo '<span>'.esc_html($settings['rating_count']).'</span>';
	            }
            echo '</div>';
        echo '</div>';
        echo '<!-----------------------End partner Logo Slider----------------------->';
	}
}