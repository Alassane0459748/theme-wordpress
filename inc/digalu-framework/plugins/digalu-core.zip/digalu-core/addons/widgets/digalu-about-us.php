<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * WCU Box Widget .
 *
 */
class Digalu_About_Us extends Widget_Base {

	public function get_name() {
		return 'digaluaboutus';
	}

	public function get_title() {
		return __( 'About Us', 'digalu' );
	}


	public function get_icon() {
		return 'vt-icon';
    }


	public function get_categories() {
		return [ 'digalu' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'services_section',
			[
				'label' 	=> __( 'About Us', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'layout',
			[
				'label' 		=> __( 'Style', 'digalu' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> '1',
				'options'		=> [
					'1'  			=> __( 'Style One', 'digalu' ),
					'2' 			=> __( 'Style Two', 'digalu' ),
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'left_info',
			[
				'label' 	=> __( 'About Us Left Info', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
				'condition'		=> [ 'layout' => ['1'] ],
			]
        );

		//-------------------------------------section heading start-------------------------------------//

		$this->add_control(
			'counter',
			[
				'label'     	=> __( 'Number', 'digalu' ),
                'type'      	=> Controls_Manager::TEXTAREA,
                'rows' 			=> 2,
                'default' 		=>  __( '1832', 'digalu'),

			]
        );
        $this->add_control(
			'title',
			[
				'label'     	=> __( 'Title', 'digalu' ),
                'type'      	=> Controls_Manager::TEXTAREA,
                'rows' 			=> 2,
                'default' 		=>  __( 'This is title area', 'digalu'),
			]
        );
        $this->add_control(
			'desc',
			[
				'label'     	=> __( 'Description', 'digalu' ),
                'type'      	=> Controls_Manager::WYSIWYG,
                'rows' 			=> 4,
                'default' 		=>  __( 'This is description area', 'digalu'),
			]
        );
       

        $this->end_controls_section();

      
        $this->start_controls_section(
			'right_info',
			[
				'label' 	=> __( 'About Us Right Info', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
				'condition'		=> [ 'layout' => ['1'] ],
			]
        );

		//-------------------------------------section heading start-------------------------------------//

        $this->add_control(
			'title2',
			[
				'label'     	=> __( 'Title', 'digalu' ),
                'type'      	=> Controls_Manager::TEXTAREA,
                'rows' 			=> 2,
                'default' 		=>  __( 'This is title area', 'digalu'),
			]
        );
        $this->add_control(
			'desc2',
			[
				'label'     	=> __( 'Description', 'digalu' ),
                'type'      	=> Controls_Manager::WYSIWYG,
                'rows' 			=> 4,
                'default' 		=>  __( 'This is description area', 'digalu'),
			]
        );
       

        $this->end_controls_section();



          //----------------------------------------style 2 -----------------------------------------//

        $this->start_controls_section(
			'left_info2',
			[
				'label' 	=> __( 'About Us Left Info', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
				'condition'		=> [ 'layout' => ['2'] ],
			]
        );

		$repeater2 = new Repeater();

		$repeater2->add_control(
			'counter_number',
			[
				'label'     => __( 'Counter Number', 'digalu' ),
				'type'      => Controls_Manager::TEXTAREA,
				'rows' 		=> 2,
				'default' 	=> __( '25', 'digalu' ),
			]
		);
		$repeater2->add_control(
			'counter_suffix',
			[
				'label'     => __( 'Counter Suffix', 'digalu' ),
				'type'      => Controls_Manager::TEXTAREA,
				'rows' 		=> 2,
				'default' 	=> __( 'k', 'digalu' ),
			]
		);
		$repeater2->add_control(
			'counter_text',
			[
				'label'     => __( 'Counter Text', 'digalu' ),
				'type'      => Controls_Manager::TEXTAREA,
				'rows' 		=> 2,
				'default' 	=> __( 'Years Of Experience', 'digalu' ),
			]
		);
		
		$this->add_control(
			'counter2',
			[
				'label' 		=> __( 'Counter', 'digalu' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater2->get_controls(),
			]
		);
       

        $this->end_controls_section();

        $this->start_controls_section(
			'right_info2',
			[
				'label' 	=> __( 'About Us Right Info', 'digalu' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
				'condition'		=> [ 'layout' => ['2'] ],
			]
        );

        $this->add_control(
			'title3',
			[
				'label'     	=> __( 'Title', 'digalu' ),
                'type'      	=> Controls_Manager::TEXTAREA,
                'rows' 			=> 2,
                'default' 		=>  __( 'This is title area', 'digalu'),
			]
        );
        $this->add_control(
			'subtitle3',
			[
				'label'     	=> __( 'Subtitle', 'digalu' ),
                'type'      	=> Controls_Manager::TEXTAREA,
                'rows' 			=> 2,
                'default' 		=>  __( 'This is title area', 'digalu'),
			]
        );
        $this->add_control(
			'desc3',
			[
				'label'     	=> __( 'Description', 'digalu' ),
                'type'      	=> Controls_Manager::WYSIWYG,
                'rows' 			=> 4,
                'default' 		=>  __( 'This is description area', 'digalu'),
			]
        );
        $repeater = new Repeater();

		$repeater->add_control(
			'label',
			[
				'label'     => __( 'Label', 'digalu' ),
				'type'      => Controls_Manager::TEXTAREA,
				'rows' 		=> 2,
				'default' 	=> __( 'Email', 'digalu' ),
			]
		);
		$repeater->add_control(
			'info',
			[
				'label'     => __( 'Info', 'digalu' ),
				'type'      => Controls_Manager::TEXTAREA,
				'rows' 		=> 2,
				'default' 	=> __( 'Info@gmail.com ', 'digalu' ),
			]
		);
		$repeater->add_control(
			'icon',
			[
				'label'     => __( 'Icon Class', 'digalu' ),
				'type'      => Controls_Manager::TEXTAREA,
				'rows' 		=> 2,
				'default' 	=> __( '<i class="fas fa-envelope"></i>', 'digalu' ),
			]
		);
		$this->add_control(
			'infos',
			[
				'label' 		=> __( 'Information', 'digalu' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'label' 		=> __( 'Counter One', 'digalu' ),
					],
				],
				'title_field' 	=> '{{{ label }}}',
			]
		);
		$this->add_control(
			'image',
			[
				'label' 		=> __( 'Shape Image', 'digalu' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
			]
		);
        $this->end_controls_section();

        

		/*--------------------------------------------------------end Feedback styling---------------------------------------------------*/


	}

	protected function render() {

        $settings = $this->get_settings_for_display();

        if( $settings['layout'] == '1' ){

        	echo '<div class="about-style-five-area">';
		        echo '<div class="container">';
		            echo '<div class="row align-center">';
		                echo '<div class="col-xl-5 col-lg-7">';
		                    echo '<div class="about-style-five">';
		                        echo '<div class="fun-fact">';
		                        	if( ! empty( $settings['counter'] ) ){
			                            echo '<div class="counter">';
			                                echo '<div class="timer" data-to="'.esc_attr( $settings['counter'] ).'" data-speed="2000">'.esc_html( $settings['counter'] ).'</div>';
			                                echo '<div class="operator">K</div>';
			                            echo '</div>';
			                        }
			                        if( ! empty( $settings['title'] ) ){
			                            echo '<span class="medium">'.esc_html( $settings['title'] ).'</span>';
			                        }
		                        echo '</div>';
		                        
		                        if( ! empty( $settings['desc'] ) ){
		                            echo wp_kses_post( $settings['desc'] );
		                        }

		                    echo '</div>';
		                echo '</div>';
		                echo '<div class="col-xl-6 offset-xl-1 col-lg-5">';
		                    echo '<div class="about-style-five right-border">';
		                    	if( ! empty( $settings['title2'] ) ){
			                        echo '<h2 class="title">'.wp_kses_post( $settings['title2'] ).'</h2>';
			                    }
			                    if( ! empty( $settings['desc2'] ) ){
		                            echo wp_kses_post( $settings['desc2'] );
		                        }
		                    echo '</div>';
		                echo '</div>';
		            echo '</div>';
		        echo '</div>';
		    echo '</div>';

	    }else{
	    	echo '<div class="about-style-six-area default-padding-top">';
		        echo '<div class="container">';
		            echo '<div class="row">';
		                echo '<div class="col-lg-5">';
		                    echo '<div class="about-style-six-counter">';
		                        echo '<ul class="counter-list">';
		                        	foreach( $settings['counter2'] as $data ) {  
			                            echo '<li>';
			                                echo '<div class="fun-fact">';
			                                    echo '<div class="counter">';
			                                    	if( ! empty( $data['counter_number'] ) ){
			                                    		$suffix = ( $data['counter_suffix'] ) ? $data['counter_suffix'] : '';
				                                        echo '<div class="timer" data-to="'.esc_attr( $data['counter_number'] ).'" data-speed="2000">'.esc_html( $data['counter_number'] ).'</div>';
				                                        echo '<div class="operator">'.esc_html($suffix).'</div>';
				                                    }
			                                    echo '</div>';
			                                    if( !empty( $data['counter_text'] ) ){
				                                    echo '<span class="medium">'.esc_html( $data['counter_text'] ).'</span>';
				                                }
			                                echo '</div>';
			                            echo '</li>';
			                        }
		                        echo '</ul>';
		                    echo '</div>';
		                echo '</div>';
		                echo '<div class="col-lg-7">';

		                	$shape = $settings['image']['url'] ? $settings['image']['url'] : '#';

		                    echo '<div class="about-style-six bg-dark text-light" style="background-image: url('.esc_url( $shape ).');">';
		                    	if( ! empty( $settings['title3'] ) ){
			                        echo '<h4 class="sub-title">'.wp_kses_post( $settings['title3'] ).'</h4>';
			                    }
			                    if( ! empty( $settings['subtitle3'] ) ){
			                        echo '<h2 class="title">'.wp_kses_post( $settings['subtitle3'] ).'</h2>';
			                    }
			                    if( ! empty( $settings['desc3'] ) ){
			                        echo '<p>'.wp_kses_post( $settings['desc3'] ).'</p>';
			                    }
		                        echo '<ul class="shor-contact">';

		                        	foreach( $settings['infos'] as $data ) {  
			                            echo '<li>';
			                            	if( ! empty( $data['icon'] ) ){
				                                echo '<div class="icon">'.wp_kses_post( $data['icon'] ).'</div>';
				                            }
				                            if( ! empty( $data['info'] && $data['label'] ) ){
				                                echo '<div class="info">';
				                                    echo '<span>'.esc_html( $data['label'] ).'</span> '.esc_html( $data['info'] ).'';
				                                echo '</div>';
				                            }
			                            echo '</li>';
			                        }
		                        echo '</ul>';
		                    echo '</div>';
		                echo '</div>';
		            echo '</div>';
		        echo '</div>';
		    echo '</div>';
	    }
	}
}