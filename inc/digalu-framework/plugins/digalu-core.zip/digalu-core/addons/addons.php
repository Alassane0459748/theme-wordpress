<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Main Digalu Core Class
 *
 * The main class that initiates and runs the plugin.
 *
 * @since 1.0.0
 */
final class Digalu_Extension {

	/**
	 * Plugin Version
	 *
	 * @since 1.0.0
	 *
	 * @var string The plugin version.
	 */
	const VERSION = '1.0.0';

	/**
	 * Minimum Elementor Version
	 *
	 * @since 1.0.0
	 *
	 * @var string Minimum Elementor version required to run the plugin.
	 */
	const MINIMUM_ELEMENTOR_VERSION = '2.0.0';

	/**
	 * Minimum PHP Version
	 *
	 * @since 1.0.0
	 *
	 * @var string Minimum PHP version required to run the plugin.
	 */
	const MINIMUM_PHP_VERSION = '7.0';

	/**
	 * Instance
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 * @static
	 *
	 * @var Elementor_Test_Extension The single instance of the class.
	 */
	private static $_instance = null;

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 * @static
	 *
	 * @return Elementor_Test_Extension An instance of the class.
	 */
	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;

	}

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function __construct() {
		add_action( 'plugins_loaded', [ $this, 'init' ] );

	}


	/**
	 * Initialize the plugin
	 *
	 * Load the plugin only after Elementor (and other plugins) are loaded.
	 * Checks for basic plugin requirements, if one check fail don't continue,
	 * if all check have passed load the files required to run the plugin.
	 *
	 * Fired by `plugins_loaded` action hook.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function init() {

		// Check if Elementor installed and activated
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );
			return;
		}

		// Check for required Elementor version
		if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );
			return;
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );
			return;
		}

		// Add Plugin actions
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'init_widgets' ] );

        // Register widget scripts
		add_action( 'elementor/frontend/after_enqueue_scripts', [ $this, 'widget_scripts' ]);

        // category register
		add_action( 'elementor/elements/categories_registered',[ $this, 'digalu_elementor_widget_categories' ] );

	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have Elementor installed or activated.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_missing_main_plugin() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor */
			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'digalu' ),
			'<strong>' . esc_html__( 'Digalu Core', 'digalu' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'digalu' ) . '</strong>'
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required Elementor version.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_minimum_elementor_version() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'digalu' ),
			'<strong>' . esc_html__( 'Digalu Core', 'digalu' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'digalu' ) . '</strong>',
			 self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required PHP version.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_minimum_php_version() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'digalu' ),
			'<strong>' . esc_html__( 'Digalu Core', 'digalu' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'digalu' ) . '</strong>',
			 self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Init Widgets
	 *
	 * Include widgets files and register them
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function init_widgets() {

		// Include Widget files
		require_once( DIGALU_ADDONS . '/widgets/section-title.php' );
		require_once( DIGALU_ADDONS . '/widgets/blog-post.php' );
		require_once( DIGALU_ADDONS . '/widgets/button.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-banner.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-featurs.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-animation-image.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-group-image.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-video-button.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-circle-progressbar.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-animated-process.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-work-process.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-service.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-counterup.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-logo-slider.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-service-tab.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-projects.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-testimonials.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-rating-box.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-animation.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-pricing-plan.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-team.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-faq.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-bg-text.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-feature-list.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-expert.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-contact-form.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-seo-feature.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-client-location.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-contact-box.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-contact-info.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-team-details.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-project-info.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-image-box.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-boosting.php' );

		// ----------------------------------------secound update---------------------------------------- //
		require_once( DIGALU_ADDONS . '/widgets/digalu-banner-v2.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-about-us.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-service-v2.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-business-progress.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-project-v2.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-faq-v2.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-progressbar.php' );
		require_once( DIGALU_ADDONS . '/widgets/digalu-pricing-v2.php' );
		
		

		// Header Elements
		require_once( DIGALU_ADDONS . '/header/header.php' );
		require_once( DIGALU_ADDONS . '/header/header-v2.php' );


		// Footer Elements
		require_once( DIGALU_ADDONS . '/footer-widgets/newsletter-widget.php' );

		// Register widget
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Section_Title_Widget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Blog_Post() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Button() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Banner() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Feature_Box() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Animated_Image() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Group_Image() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Play_Button() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Circle_Progressbar() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Animated_Process_Widgets() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Work_Process() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Services() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Counterup() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Client_Logo() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Tab_Builder() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Projects() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Testimonials() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Rating_Box() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Animation_Image() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Pricing_Plan() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Team() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Faq() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Bg_Text() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Feature_List() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Expert() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Contact_Form() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Seo_List() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Client_Location_Process() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Contact_Box() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Contact_Info() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Team_Info() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Project_Info() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Image() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Boosting() );
		// ----------------------------------------secound update---------------------------------------- //
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Banner_V2() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_About_Us() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Services_V2() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Business_Progress() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Project_V2() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Faq_V2() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Progressbar() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Pricing_Plan_v2() );
		
		
		// Header Widget Register
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Header() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Header_V2() );


		// Footer Widget Register
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Digalu_Newsletter_Widgets() );

	}

    public function widget_scripts() {
        wp_enqueue_script(
            'digalu-frontend-script',
            DIGALU_PLUGDIRURI . 'assets/js/digalu-frontend.js',
            array('jquery'),
            false,
            true
		);
	}
	

    function digalu_elementor_widget_categories( $elements_manager ) {
        $elements_manager->add_category(
            'digalu',
            [
                'title' => __( 'Digalu', 'digalu' ),
                'icon' 	=> 'fa fa-plug',
            ]
        );
        $elements_manager->add_category(
            'digalu_footer_elements',
            [
                'title' => __( 'Digalu Footer Elements', 'digalu' ),
                'icon' 	=> 'fa fa-plug',
            ]
		);

		$elements_manager->add_category(
            'digalu_header_elements',
            [
                'title' => __( 'Digalu Header Elements', 'digalu' ),
                'icon' 	=> 'fa fa-plug',
            ]
        );

	}

}

Digalu_Extension::instance();